package rm.android.poweroff;

import android.app.Activity;
import android.os.Bundle;
import android.os.PowerManager;

public class PowerOffActivity extends Activity
{
	//private 
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}
	
	@Override
	public void onResume()
	{
		super.onResume();
		
		Root.get();
		
		try
		{
			Thread.sleep(1000);
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		
		Root.Power.hotRestart();
	}
}
