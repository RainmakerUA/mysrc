#include <time.h>
#include <win.h>
#include <stdio.h>

#include "mainrc.h"

const char DAY1[]    = "����";
const char DAY234[]  = "���";
const char DAY5[]    = "����";

const char TimeFmt[] = "%3d %s, %02d:%02d:%02d";

char TimeStr[20];

const char *nouns_ru(int num, const char *s1, const char *s234, const char *s5)
{
	if (num % 100 >= 11 && num % 100 <= 14)
		return s5;
	if (num % 10 == 1)
		return s1;
	if (num % 10 >= 2 && num % 10 <= 4)
		return s234;
	return s5;
}

char *secs2str(time_t secs)
{
	int min = secs / 60;
	secs %= 60;
	int hr  = min / 60;
	min %= 60;
	int day = hr / 24;
	hr  %= 24;

	const char *ds = nouns_ru(day, DAY1, DAY234, DAY5);
	sprintf(TimeStr, TimeFmt, day, ds, hr, min, secs);
	return TimeStr;
}

time_t secs2ny(void)
{
	struct tm tm0 = {0, 0, 0, 1, 0, 9999, 0, 0, 0};
	struct tm *tm_now;

	time_t tnow = time(NULL);
    tm_now = localtime(&tnow);
    tm0.tm_year = tm_now->tm_year + 1;
    time_t tny = mktime(&tm0);
    return (tny - tnow);
}

#define TASKBAR_CLASS "Shell_TrayWnd"
#define STARTBTN_CLASS "Button"

#define START_W 155

HWND hStart = NULL;
HBITMAP hStBMP = NULL;

void CALLBACK UpdateText(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime)
{
	HWND hTB = FindWindow(TASKBAR_CLASS, NULL);
    hStart = FindWindowEx(hTB, 0, STARTBTN_CLASS, NULL);
	if (!hStart)
		return;
	SetWindowTextA(hStart, secs2str(secs2ny()));
    InvalidateRect(hStart, NULL, 0);
    UpdateWindow(hStart);
}

void CALLBACK UpdateSize(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime)
{
	RECT rc;
	if (!hStart)
		return;
	GetWindowRect(hStart, &rc);
    if (rc.right - rc.left < START_W)
	{
		SetWindowPos(hStart, 0, 0, 0, START_W, rc.bottom - rc.top,
                     SWP_NOMOVE | SWP_NOZORDER | SWP_NOCOPYBITS);
		if (hStBMP)
			SendMessage(hStart, BM_SETIMAGE, IMAGE_BITMAP, (LPARAM)(HANDLE)hStBMP);
	}
}

#define ID_UPTEXT 0xDEADBEAF
#define ID_UPSIZE (ID_UPTEXT + 1)

#define TEXT_TO 333
#define SIZE_TO 111

UINT hTextTmr, hSizeTmr;

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
		case WM_CREATE:
			hTextTmr = SetTimer(hWnd, ID_UPTEXT, TEXT_TO, UpdateText);
			hSizeTmr = SetTimer(hWnd, ID_UPSIZE, SIZE_TO, UpdateSize);
			break;

		case WM_DESTROY:
			KillTimer(hWnd, ID_UPTEXT);
			KillTimer(hWnd, ID_UPSIZE);
			PostQuitMessage(0);
			break;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

#define MAINCLASS "CoolStartApp"
#define MAINWNDTL "CoolStartApp [should not see me :-P]"

#define MW_W 235
#define MW_H 30

int main(void)
{
	WNDCLASSEXA wc;
	HWND hWnd;
	MSG Msg;
	HINSTANCE hInst = GetModuleHandle(0);
	ATOM AtomClass;

	hStBMP = LoadBitmap(hInst, MAKEINTRESOURCE(STARTBMP));

	ZeroMemory(&wc, sizeof(wc));

	wc.cbSize = sizeof(wc);
	wc.style  = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = WndProc;
	wc.hInstance = hInst;
	wc.hIcon = LoadIcon(hInst, MAKEINTRESOURCE(MAINICON));
	wc.hCursor = LoadCursor(NULL, IDC_CROSS);
	wc.hbrBackground = (HANDLE)(COLOR_APPWORKSPACE + 1);
	wc.lpszClassName = MAINCLASS;

	AtomClass = RegisterClassExA(&wc);
	if (!AtomClass)
		return(-1);

	hWnd = CreateWindowExA(WS_EX_TOOLWINDOW, MAINCLASS, MAINWNDTL,
			WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
			MW_W, MW_H, NULL, NULL, hInst, NULL);

	ShowWindow(hWnd, SW_HIDE /*SW_SHOWNORMAL*/);
	UpdateWindow(hWnd);

	while (GetMessageA(&Msg, NULL, 0, 0))
	{
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}
	return(Msg.wParam);
}
