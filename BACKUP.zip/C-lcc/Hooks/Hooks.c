#define UNICODE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

HINSTANCE hInst;
HHOOK hkMouseHook, hkKbdLLHook;
WCHAR wmsg[64];


LRESULT CALLBACK MouseProc( int nCode, WPARAM wParam, LPARAM lParam)
{
    if ((nCode == HC_ACTION) && (wParam == WM_LBUTTONDOWN) && (GetKeyState(VK_MENU) & 0x8000))
    {
        HWND hwin = ((PMOUSEHOOKSTRUCT)lParam)->hwnd;
		HWND hpar;
		while (hpar = GetParent(hwin))
		{
			if (GetLastError())
				break;
			hwin = hpar;
		}
    	ReleaseCapture();
		PostMessage(hwin, WM_SYSCOMMAND, SC_MOVE + HTCAPTION, 0);
        return 1;
    }
    return CallNextHookEx(hkMouseHook, nCode, wParam, lParam);
}

DWORD __stdcall ControlMouseHook(BYTE Set)
{
    if (Set)
    {
        return (DWORD)(hkMouseHook = SetWindowsHookEx(WH_MOUSE, MouseProc, hInst, 0));
    }
    else
    {
        return UnhookWindowsHookEx(hkMouseHook);
    }
}


LRESULT CALLBACK KbdProc( int nCode, WPARAM wParam, LPARAM lParam)
{
	if ((nCode == HC_ACTION) && (wParam == WM_KEYDOWN)
			&& (((LPKBDLLHOOKSTRUCT)lParam)->vkCode == VK_CAPITAL))
    {
		HWND hwin = GetForegroundWindow();
		PostMessage(hwin, WM_INPUTLANGCHANGEREQUEST, 0, HKL_NEXT);
        return 1;
    }
    return CallNextHookEx(hkKbdLLHook, nCode, wParam, lParam);
}

DWORD __stdcall ControlKbdHook(BYTE Set)
{
    if (Set)
    {
        return (DWORD)(hkKbdLLHook = SetWindowsHookEx(WH_KEYBOARD_LL, KbdProc, hInst, 0));
    }
    else
    {
        return UnhookWindowsHookEx(hkKbdLLHook);
    }
}

void __stdcall About(HWND hOwner)
{
	MessageBox(hOwner, L"First (& maybe last) hook by [RM]", L"About hook DLL", MB_ICONINFORMATION | MB_OK);
}

LPWSTR __stdcall HookName(int HookNum)
{
	wsprintf(wmsg, L"Hook func #%d", HookNum);
	return wmsg;
}

BOOL WINAPI LibMain(HINSTANCE hDLLInst, DWORD fdwReason, LPVOID lpvReserved)
{
    hInst = hDLLInst;
    return TRUE;
}

