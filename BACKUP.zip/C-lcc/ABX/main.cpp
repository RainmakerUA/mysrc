#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h>
//#include <shlobj.h>

// Control IDs
#define ED_FOLDER 101
#define BT_BROWSE 111
#define BT_START  112
#define BT_ABOUT  199
#define BT_CLOSE  113

//Macros
#define X_SCREENCENTER (GetSystemMetrics(SM_CXSCREEN) >> 1)
#define Y_SCREENCENTER (GetSystemMetrics(SM_CYSCREEN) >> 1)
// MainWnd Size
#define MAINWND_W 360
#define MAINWND_H 130

// ClassName
const char *szClassName  = "TABX_Class";
const char *szWndCaption = "AddressBook Extractor";

// Captions
const char *szBtBrowseCaption = "�����...";
const char *szBtStartCaption  = "�������";
const char *szBtAboutCaption  = "����";
const char *szBtCloseCaption  = "�����";

// Globals
WNDCLASSEX wclass;
ATOM classatom;
HINSTANCE hInst;
HWND hMainWnd, hEdFolder, hStProcess,
	hBtBrowse, hBtStart, hBtAbout, hBtClose;
HFONT hFont;
BOOL bFirstClick = TRUE;

BOOL OnCommand(WPARAM wParam, LPARAM lParam)
{
	switch (wParam)
	{
	case BT_ABOUT:
		ShellAbout(hMainWnd, szWndCaption,
				"\xA9 Rainmaker\nhypershadow@mail.zp.ua", wclass.hIcon);
		break;
	case ED_FOLDER:
		switch (HIWORD(wParam))
		{
		case EN_CHANGE:
			if (GetWindowTextLength(hEdFolder) > 0)
				EnableWindow(hBtStart, TRUE);
			else
				EnableWindow(hBtStart, FALSE);
		}
	case BT_CLOSE:
		return TRUE;
	}
	return FALSE;
}

BOOL OnCanClose()
{
	if (MessageBox(hMainWnd, "�� ������������� ������ �����?", szWndCaption,
				MB_ICONQUESTION | MB_YESNO) == IDYES)
		return TRUE;
	else
		return FALSE;
}
void OnDestroy()
{
	DeleteObject(hFont);
	PostQuitMessage(0);
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_SETCURSOR:
		if (wParam == (WPARAM) hEdFolder && bFirstClick)
		{
			SetWindowText(hEdFolder, NULL);
			SetFocus(hEdFolder);
			bFirstClick = FALSE;
		}
		break;
	case WM_COMMAND:
		if (OnCommand(wParam, lParam))
			if (OnCanClose())
				OnDestroy();
		break;
	case WM_KEYDOWN:
		if (wParam != VK_ESCAPE)
			break;
	case WM_CLOSE:
		if (!OnCanClose())
			return 0;
	case WM_QUIT:
	case WM_DESTROY:
		OnDestroy();
		return 0;
	case WM_SYSCOMMAND:
		if (wParam == SC_KEYMENU)
			return 0;
	}
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

BOOL InitClass(void)
{
	hInst = GetModuleHandle(NULL);
	memset(&wclass, 0, sizeof(wclass));
	wclass.cbSize = sizeof(WNDCLASSEX);
	wclass.style = CS_HREDRAW | CS_VREDRAW;
	wclass.lpfnWndProc = WndProc;
	wclass.hInstance = hInst;
	wclass.hbrBackground = /*(HBRUSH)*/ COLOR_APPWORKSPACE + 1;
	wclass.lpszClassName = szClassName;
	wclass.hIcon = LoadIcon(hInst, "MAINICON");
	wclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	InitCommonControls();
	classatom = RegisterClassEx(&wclass);
	return (classatom);
}

BOOL InitWindow(void)
{
	hMainWnd = CreateWindowEx(WS_EX_TOOLWINDOW, szClassName, szWndCaption, WS_SYSMENU | WS_VISIBLE,
			X_SCREENCENTER - MAINWND_W >> 1, Y_SCREENCENTER - MAINWND_H >> 1, MAINWND_W, MAINWND_H,
			NULL, NULL, hInst, NULL);
	if (!hMainWnd)
		return FALSE;
	hFont = CreateFont(-11, 0, 0, 0, 0, 0, 0, 0, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
			5, DEFAULT_PITCH | FF_DONTCARE, "Tahoma");
	hEdFolder = CreateWindowEx(WS_EX_STATICEDGE, "EDIT", "hEdFolder", WS_CHILD | WS_VISIBLE,
			13, 14, 234, 17, hMainWnd, (HMENU) ED_FOLDER, hInst, NULL);
	hStProcess = CreateWindowEx(0, "STATIC", "\xBB Ready", WS_CHILD | WS_VISIBLE | SS_NOTIFY | SS_LEFTNOWORDWRAP,
			70, 72, 177, 16, hMainWnd, NULL, hInst, NULL);
	hBtBrowse = CreateWindowEx(WS_EX_STATICEDGE, "BUTTON", szBtBrowseCaption, BS_FLAT | WS_CHILD | WS_VISIBLE,
			260, 11, 83, 24, hMainWnd, (HMENU) BT_BROWSE, hInst, NULL);
	hBtStart  = CreateWindowEx(WS_EX_STATICEDGE, "BUTTON", szBtStartCaption, BS_FLAT | BS_DEFPUSHBUTTON | WS_CHILD
			| WS_VISIBLE | WS_DISABLED, 260, 37, 83, 24, hMainWnd, (HMENU) BT_START, hInst, NULL);
	hBtClose  = CreateWindowEx(WS_EX_STATICEDGE, "BUTTON", szBtCloseCaption, BS_FLAT | WS_CHILD | WS_VISIBLE,
			260, 70, 83, 20, hMainWnd, (HMENU) BT_CLOSE, hInst, NULL);
	hBtAbout  = CreateWindowEx(WS_EX_STATICEDGE, "BUTTON", szBtAboutCaption, BS_FLAT | WS_CHILD | WS_VISIBLE,
			12, 70, 50, 20, hMainWnd, (HMENU) BT_ABOUT, hInst, NULL);

	SetWindowText(hEdFolder, "������� ��� ����� ��� ������� \"�����\"...");
	EnableWindow(hBtStart, FALSE);

	SendMessage(hEdFolder,  WM_SETFONT, (WPARAM) hFont, 0);
	SendMessage(hStProcess, WM_SETFONT, (WPARAM) hFont, 0);
	SendMessage(hBtBrowse,  WM_SETFONT, (WPARAM) hFont, 0);
	SendMessage(hBtStart,   WM_SETFONT, (WPARAM) hFont, 0);
	SendMessage(hBtClose,   WM_SETFONT, (WPARAM) hFont, 0);
	SendMessage(hBtAbout,   WM_SETFONT, (WPARAM) hFont, 0);

	UpdateWindow(hMainWnd);
	return TRUE;
}

int main (void)
{
	MSG Msg;
	if (!InitClass())
		return (-1);
	if (!InitWindow())
		return (-2);

	while (GetMessage(&Msg, NULL, 0, 0))
	{
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}

	ExitProcess(0);
	return 0;
}

