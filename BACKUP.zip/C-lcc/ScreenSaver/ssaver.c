#include <windows.h>
#include <ddraw.h>

#define SCR_WIDTH  320
#define SCR_HEIGHT 240
#define SCR_SIZE   {SCR_WIDTH * SCR_HEIGHT}
#define SCR_BPP    16

#define SCR_TYPE   unsignes short

#define VAL2RGB(v) (((v) << 11) | ((v) << 5) | (v))

//consts
const GUID IID_IDirectDraw7_ = {0x15e65ec0, 0x3b9c, 4562, {185, 47, 0, 96, 151, 151, 234, 91}};

//Global vars
HINSTANCE hInst;
IDirectDraw7 *pDD;
IDirectDrawSurface *pDDSFront, *pDDSBack;
DDSURFACEDESC2 ddsd;

int InitDirectDraw(HWND hWnd)
{
	//DDSCAPS2 ddscaps;
	if (DirectDrawCreateEx(NULL, &pDD, &IID_IDirectDraw7_, NULL) != DD_OK)
		return 0;
	/*
	if (IDirectDraw7->SetCooperativeLevel(pDD, hWnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN) != DD_OK)
		return 0;
	*/
	return 1;
}

int STDCALL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	if (InitDirectDraw(HWND_DESKTOP))
		MessageBox(HWND_DESKTOP, "Success!", "DDTest", MB_OK);
	else
		MessageBox(HWND_DESKTOP, "Failure!", "DDTest", MB_OK);
	return 0;
}
