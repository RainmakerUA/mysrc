#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <string.h>
#include "HooksClientRes.h"

#include "hooks.h"

HINSTANCE hInst;	// Instance handle
HWND hwndMain;		//Main window handle

LRESULT CALLBACK WndProc(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam);

static BOOL InitApplication(void)
{
	WNDCLASS wc;

	memset(&wc,0,sizeof(WNDCLASS));
	wc.style = CS_BYTEALIGNCLIENT | CS_HREDRAW | CS_VREDRAW ;
	wc.lpfnWndProc = (WNDPROC) WndProc;
	wc.hInstance = hInst;
	wc.hbrBackground = (HBRUSH) (COLOR_BTNFACE + 1);
	wc.lpszClassName = "HooksClientWndClass";
	wc.lpszMenuName = MAKEINTRESOURCE(IDMAINMENU);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	if (!RegisterClass(&wc))
		return 0;

	ControlMouseHook(1);
	ControlKbdHook(1);
	return 1;
}

HWND CreateHooksClientWndClassWnd(void)
{
	return CreateWindow("HooksClientWndClass","HooksClient",
		WS_VISIBLE | WS_CAPTION | WS_BORDER,
		186, 68, 304, 229,
		NULL,
		NULL,
		hInst,
		NULL);
}

void WndProc_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
	switch(id)
	{
	case IDM_EXIT:
		PostMessage(hwnd, WM_CLOSE, 0, 0);
		break;
	}
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{

	case WM_COMMAND:
		HANDLE_WM_COMMAND(hwnd, wParam, lParam, WndProc_OnCommand);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hwnd, msg, wParam, lParam);
	}

	return 0;
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, INT nCmdShow)
{
	MSG msg;

	hInst = hInstance;
	if (!InitApplication())
		return 0;
	if ((hwndMain = CreateHooksClientWndClassWnd()) == (HWND)0)
		return 0;
	ShowWindow(hwndMain,SW_SHOW);
	while (GetMessage(&msg,NULL,0,0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}
