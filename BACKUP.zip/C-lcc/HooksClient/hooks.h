#include <windows.h>

#ifdef DECLSPEC_IMPORT
#undef DECLSPEC_IMPORT
#define DECLSPEC_IMPORT __declspec(dllimport)
#endif

DWORD __stdcall DECLSPEC_IMPORT ControlMouseHook(BYTE Set);
DWORD __stdcall DECLSPEC_IMPORT ControlKbdHook(BYTE Set);

HHOOK __stdcall DECLSPEC_IMPORT GetMouseHook();
HHOOK __stdcall DECLSPEC_IMPORT GetKbdHook();

#pragma lib "hooks.lib"

