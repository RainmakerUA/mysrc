#include <stdio.h>
#include <win.h>

//typedef unsigned long int UINT;

UINT ms, sec, min, hr, day;

void ms2(UINT *mss, UINT *scs, UINT *mns, UINT *hrs, UINT *dys)
{
	*scs = *mss / 1000;
	*mss %= 1000;
	*mns = *scs / 60;
	*scs %= 60;
	*hrs = *mns / 60;
	*mns %= 60;
	*dys = *hrs / 24;
	*hrs %= 24;
}

int APIENTRY WinMain(HINSTANCE hinst, HINSTANCE hinstPrev, LPSTR lpCmdLine, int nCmdShow)
{
	ms = GetTickCount();
	ms2(&ms, &sec, &min, &hr, &day);
	char msg[32];
	sprintf(msg, "Uptime:\n%02d days, %02d:%02d:%02d.%03d", day, hr, min, sec, ms);
	/*
	HWND hTaskBar = FindWindowEx(0, 0, "Shell_TrayWnd", NULL);
	HWND hStart = FindWindowEx(hTaskBar, 0, "BUTTON", NULL);
	*/
	MessageBox(0, msg, "", MB_ICONINFORMATION);
	return 0;
}

