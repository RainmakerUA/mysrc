// OpenFolder.cpp : Defines the entry point for the application.
//
#define UNICODE
#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers
// Windows Header Files:
#include <windows.h>
//#include <shobjidl.h>
#include <shlobj.h>
#include <commctrl.h>

#define FILENAME L"e:\\Games\\Worms World Party\\wwp.exe"
//#define FILENAME L"c:\\FASM\\FASMW.EXE"

#define MB_TEXT L"To run Worms World Party you must\n\
close following applications:\n\
- AIMP2,\n\
- Opera,\n\
- QIP Infium,\n\
- The Bat,\n\
- Total Commander,\n\
- Windows Sidebar.\n\
After closing press \"OK\" then,\n\
in folder window doubleclick WWP.EXE"
#define MB_CAPT L"WWP Launcher"

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                     LPSTR lpCmdLine, int nCmdShow)
{
 	IShellFolder *sf;
    ULONG cch = 0, attr = 0;
    LPITEMIDLIST pidl;
	MSGBOXPARAMS mbp;

	InitCommonControls();

	memset(&mbp, 0, sizeof(mbp));
	mbp.cbSize = sizeof(mbp);
	mbp.hInstance = hInstance;
	mbp.lpszText = MB_TEXT;
	mbp.lpszCaption = MB_CAPT;
	mbp.dwStyle = MB_OKCANCEL | MB_USERICON;
	mbp.lpszIcon = MAKEINTRESOURCE(19);
    if (MessageBoxIndirect(&mbp) != IDOK)
        return 0;

    CoInitialize(NULL);
    SHGetDesktopFolder(&sf);
    sf->ParseDisplayName(NULL, NULL, FILENAME, &cch, &pidl, &attr);
    SHOpenFolderAndSelectItems(pidl, 0, NULL, 0);
    CoUninitialize();
    return 0;
}


