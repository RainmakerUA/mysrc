(function (win)
{
	var replaceLink = function (link)
	{
		var RE = /=(http[^&]+)(?:&|$)/;
		var href = link.href;
		var m = RE.exec(href);
		if (m)
		{
			var str = m[1];
			switch (str[4])
			{
				case ':':
					link.href = str;
					break;
				case '%':
					link.href = unescape(str);
					break;
				default:
					link.href = "javascript:void(0);";
					link.onclick = "alert('Not found!');return false;";
					break;
			}
			link.style.border = "1px dotted #000000";
		}
	};

	/*win.onload = function ()
	{
		var links = document.getElementsByTagName("A");
		for (var i = 0; i < links.length; i++)
		{
			replaceLink(links[i]);
		}
	}*/
})(window);