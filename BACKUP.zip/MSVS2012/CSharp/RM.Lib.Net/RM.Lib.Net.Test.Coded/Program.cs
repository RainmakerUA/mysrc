﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Xml.Serialization;
using RM.Lib.Net.Contracts.Serialization;

namespace RM.Lib.Net.Test.Coded
{
	[Binarizable]
	[Serializable]
	public class SerTest
	{
		public string Name { get; set; }
		//public AttributeTargets Target { get; set; }
		//public Guid ID { get; set; }
		//public TimeSpan Span { get; set; }
		//public DateTimeOffset DateTimeOffset { get; set; }

		//[NonBinarized]
		public HashSet<int> Ints { get; set; }
		public HashSet<string> Strings { get; set; }
	}

	internal static class Program
	{
		private const string msg = "Very secret message!";

		private static byte[] s2b(string s)
		{
			return Encoding.UTF8.GetBytes(s);
		}

		private static string b2s(byte[] b)
		{
			return Encoding.UTF8.GetString(b);
		}

		private static void Main(string[] args)
		{
			//var rsaPri = new RSACryptoServiceProvider();
			//var par = rsaPri.ToXmlString(false);
			//var rsaPub = new RSACryptoServiceProvider();
			//rsaPub.FromXmlString(par);

			//var data = rsaPub.Encrypt(s2b(msg), false);
			//var priMsg = b2s(rsaPri.Decrypt(data, false));

			//data = rsaPri.SignData(s2b(msg), new SHA1CryptoServiceProvider());
			//var isValid = rsaPub.VerifyData(s2b(msg), new SHA1CryptoServiceProvider(), data);

			var ints = new HashSet<int> { 1, 2, 3, 4, 5, 19 };
			var strings = new HashSet<string> { "test", "me", "now", "!!!11111oneoneon" };
			var test = new[]
			           	{
			           		new SerTest {Name = "Test1", Ints = ints, Strings = strings},
			           		new SerTest {Name = "Test2", Ints = ints, Strings = strings}
			           	};

			using (var fs = File.OpenWrite(@"D:\test.bin"))
			{
				fs.WriteBinary(test);
			}

			SerTest[] deserTest;
			using (var fs = File.OpenRead(@"D:\test.bin"))
			{
				deserTest = fs.ReadBinary<SerTest[]>();
			}
		}
	}
}
