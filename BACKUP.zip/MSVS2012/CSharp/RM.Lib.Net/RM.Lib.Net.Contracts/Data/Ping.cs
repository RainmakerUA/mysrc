﻿using System.Runtime.Serialization;
using RM.Lib.Net.Contracts.Serialization;

namespace RM.Lib.Net.Contracts.Data
{
	[Binarizable]
	public class Ping
	{
		public enum PingKind
		{
			Unknown = 0,
			Request,
			Response
		}

		public PingKind Kind;

		public byte[] ServerPublicKey;
	}
}
