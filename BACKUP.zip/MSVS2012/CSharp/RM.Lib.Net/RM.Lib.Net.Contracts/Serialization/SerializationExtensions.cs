﻿using System;
using System.IO;

namespace RM.Lib.Net.Contracts.Serialization
{
	public static class SerializationExtensions
	{
		public static byte[] Serialize(this object obj)
		{
			using (var memStr = new MemoryStream())
			{
				BinarySerializer.Serialize(memStr, obj);
				return memStr.ToArray();
			}
		}

		public static T Deserialize<T>(this byte[] data)
		{
			return BinarySerializer.Deserialize<T>(new MemoryStream(data));
		}

		public static void WriteBinary(this Stream stream, object obj)
		{
			BinarySerializer.Serialize(stream, obj);
		}

		public static T ReadBinary<T>(this Stream stream)
		{
			return BinarySerializer.Deserialize<T>(stream);
		}
	}
}
