﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RM.Lib.Net.Contracts.Serialization
{
	public interface IStructureConverter
	{
		byte[] ToBinary(ValueType struc);
		ValueType ToStruct(byte[] bytes);
	}
}
