using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace RM.Lib.Net.Contracts.Serialization.Internal
{
	internal sealed class ObjectEntry
	{
		private static readonly Type _binarizable = typeof(BinarizableAttribute);
		private static readonly Type _nonBinarized = typeof(NonBinarizedAttribute);

		private readonly EntryKind _kind;

		private ObjectEntry(EntryKind kind)
		{
			_kind = kind;
		}

		public EntryKind Kind
		{
			get { return _kind; }
		}

		public Type ElementType { get; private set; }

		public string[] MemberNames { get; private set; }

		public static ObjectEntry GetEntryDescription(Type type)
		{
			if (type == null)
			{
				return E(EntryKind.Null);
			}

			if (type == typeof(bool))
			{
				return E(EntryKind.Bool);
			}

			if (type == typeof(byte))
			{
				return E(EntryKind.Byte);
			}

			if (type == typeof(sbyte))
			{
				return E(EntryKind.SByte);
			}

			if (type == typeof(short))
			{
				return E(EntryKind.Short);
			}

			if (type == typeof(ushort))
			{
				return E(EntryKind.UShort);
			}

			if (type == typeof(int))
			{
				return E(EntryKind.Int);
			}

			if (type == typeof(uint))
			{
				return E(EntryKind.UInt);
			}

			if (type == typeof(long))
			{
				return E(EntryKind.Long);
			}

			if (type == typeof(ulong))
			{
				return E(EntryKind.ULong);
			}

			if (type == typeof(char))
			{
				return E(EntryKind.Char);
			}

			if (type == typeof(float))
			{
				return E(EntryKind.Float);
			}

			if (type == typeof(double))
			{
				return E(EntryKind.Double);
			}

			if (type == typeof(decimal))
			{
				return E(EntryKind.Decimal);
			}

			if (type == typeof(DateTime))
			{
				return E(EntryKind.DateTime);
			}

			if (type == typeof(TimeSpan))
			{
				return E(EntryKind.TimeSpan);
			}

			if (type == typeof(DateTimeOffset))
			{
				return E(EntryKind.DateTimeOffset);
			}

			if (type == typeof(Guid))
			{
				return E(EntryKind.Guid);
			}

			if (type == typeof(string))
			{
				return E(EntryKind.String);
			}

			if (type.IsEnum)
			{
				return GetEntryDescription(Enum.GetUnderlyingType(type));
			}

			if (type.IsArray)
			{
				if (type.GetArrayRank() > 1)
				{
					throw new NotSupportedException("Multidimensional arrays are not supported (yet)!");
				}

				return new ObjectEntry(EntryKind.Array) { ElementType = type.GetElementType() };
			}

			if (type.IsGenericType)
			{
				var genParams = type.GetGenericArguments();

				if (genParams.Length == 1)
				{
					var genParam = genParams[0];
					var ienumerable = typeof(IEnumerable<>).MakeGenericType(genParam);
					var defCtor = type.GetConstructor(new Type[0]);
					var add = type.GetMethod("Add", new[] { genParam });

					if (Array.IndexOf(type.GetInterfaces(), ienumerable) >= 0 && defCtor != null && add != null)
					{
						return new ObjectEntry(EntryKind.Collection) { ElementType = genParams[0] };
					}
				}
			}

			if (type.GetCustomAttributes(_binarizable, false).Length > 0
					&& type.GetConstructors(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public)
							.Any(ctor => ctor.GetParameters().Length == 0))
			{
				var fields = type.GetFields()
									.Where(f => !(f.IsStatic
													|| f.IsInitOnly
													|| f.GetCustomAttributes(_nonBinarized, false).Length > 0));
				var props = type.GetProperties()
									.Where(p => p.CanRead && p.CanWrite
												&& p.GetCustomAttributes(_nonBinarized, false).Length == 0);

				return new ObjectEntry(EntryKind.Object)
							{
								MemberNames = fields.Cast<MemberInfo>()
														.Concat<MemberInfo>(props.Cast<MemberInfo>())
														.Select(mi => mi.Name).ToArray()
							};
			}

			return E(EntryKind.Unknown);
		}

		private static ObjectEntry E(EntryKind kind)
		{
			return new ObjectEntry(kind);
		}
	}
}