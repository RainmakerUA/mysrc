﻿
namespace RM.Lib.Net.Contracts.Serialization.Internal
{
	internal enum EntryKind : byte
	{
		Unknown = 0,
		Null,
		Bool,
		Byte,
		SByte,
		Short,
		UShort,
		Int,
		UInt,
		Long,
		ULong,
		Char,
		Float,
		Double,
		Decimal,
		DateTime,
		TimeSpan,
		DateTimeOffset,
		Guid,
		String,
		Array,
		Collection,
		Object,
		ObjectRef,
		ObjectEnd = 254
	}
}
