﻿using System;
using System.Collections.Generic;

namespace RM.Lib.Net.Contracts.Serialization.Internal
{
	internal sealed class ObjectCache
	{
		private readonly bool _isInsertMode;
		private readonly Dictionary<int, object> _dict;
		private int _maxIndex;

		public ObjectCache(bool isInsertMode)
		{
			_isInsertMode = isInsertMode;
			_dict = new Dictionary<int, object>();
		}

		public int Add(object obj, bool throwIfContained = true)
		{
			if (_isInsertMode)
			{
				throw new InvalidOperationException("Cache is in Insert mode!");
			}

			int idx = IndexOf(obj);
			if (idx > -1)
			{
				if (!throwIfContained)
				{
					return idx;
				}

				throw new ArgumentException("Object already exists!");
			}

			_dict.Add(_maxIndex, obj);
			return _maxIndex++;
		}

		public void Insert(int index, object obj)
		{
			if (!_isInsertMode)
			{
				throw new InvalidOperationException("Cache is in Add mode!");
			}

			int idx = IndexOf(obj);
			if (idx > -1)
			{
				throw new ArgumentException("Object already exists!");
			}

			_dict.Add(index, obj);
		}

		public int IndexOf(object obj)
		{
			foreach (var idx in _dict.Keys)
			{
				if (ReferenceEquals(obj, _dict[idx]))
				{
					return idx;
				}
			}
			return -1;
		}

		public object this[int index]
		{
			get { return _dict[index]; }
		}
	}
}
