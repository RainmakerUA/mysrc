﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RM.Lib.Net.Contracts;

namespace RM.Lib.Net.Client
{
	public class NetClient : NetClientBase
	{
		
	}
}
