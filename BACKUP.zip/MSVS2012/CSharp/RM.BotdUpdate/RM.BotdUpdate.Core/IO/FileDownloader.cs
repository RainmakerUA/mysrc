﻿using System;
using System.IO;
using System.Net;

namespace RM.BotdUpdate.Core.IO
{
	internal sealed class FileDownloader
	{
		private readonly string _url;
		private readonly string _localPath;

		public FileDownloader(string url, string path)
		{
			_url = url;
			_localPath = GetLocalPath(path, url);
		}

		public string Url
		{
			get { return _url; }
		}

		public string LocalPath
		{
			get { return _localPath; }
		}

		public void Download()
		{
			var rq = WebRequest.Create(_url);
			var rp = rq.GetResponse();
			using (var rs = rp.GetResponseStream())
			{
				if (rs != null)
				{
					using (var fs = File.OpenWrite(_localPath))
					{
						rs.CopyTo(fs);
					}
				}
			}
		}

		private static string GetLocalPath(string path, string url)
		{
			var uriSegments = new Uri(url).Segments;
			var fileName = uriSegments[uriSegments.Length - 1];
			return Path.Combine(path, fileName);
		}
	}
}
