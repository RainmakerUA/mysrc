﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace RM.BotdUpdate.Core.IO
{
	internal class FileCleaner
	{
		private readonly string _directory;
		private readonly DateTime _lastDateTime;
		private readonly IEnumerable<string> _files;

		public FileCleaner(string directory, DateTime lastDateTime)
		{
			_directory = directory;
			_lastDateTime = lastDateTime;

			_files = Directory.EnumerateFiles(directory, "*", SearchOption.AllDirectories).Where(fn => File.GetCreationTime(fn) < _lastDateTime);
		}

		public void Clean()
		{
			Parallel.ForEach(_files, DeleteFile);
		}

		private static void DeleteFile(string file)
		{
			try
			{
				File.Delete(file);
			}
			catch (IOException)
			{
			}
			catch (UnauthorizedAccessException)
			{
			}
		}
	}
}
