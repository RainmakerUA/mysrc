﻿using System.Collections.Generic;

namespace RM.BotdUpdate.Core.Persistance
{
	public interface IKeyedStorage<TK, TV>
	{
		IEnumerable<TK> Keys { get; }

		TV this[TK key] { get; set; }
	}
}
