﻿using RM.BotdUpdate.Core.Persistance;

namespace RM.BotdUpdate.Core
{
	public interface ISettings
	{
		int DaysCount { get; set; }

		string ImageFolder { get; set; }

		IKeyedStorage<string, string> UrlFormats { get; }

		int DelayBeforeExit { get; set; }
	}
}