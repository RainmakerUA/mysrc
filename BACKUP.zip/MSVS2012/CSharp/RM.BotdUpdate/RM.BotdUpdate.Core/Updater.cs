﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using RM.BotdUpdate.Core.IO;

namespace RM.BotdUpdate.Core
{
	public sealed class Updater //: IDisposable
	{
		private readonly ISettings _settings;
		private readonly DateTime _startDateTime;

		public Updater(ISettings settings = null)
		{
			_startDateTime = DateTime.Now;
			_settings = settings ?? Settings.Default;
		}

		//#region Disposable

		//~Updater()
		//{
		//    Dispose(false);
		//}

		//private void Dispose(bool disposing)
		//{
		//    if (disposing)
		//    {
		//        // Dispose managed
		//    }

		//    // Dispose unmanaged
		//}

		//public void Dispose()
		//{
		//    Abort();
		//}

		//#endregion

		public void Update()
		{
			if (!Directory.Exists(_settings.ImageFolder))
			{
				Directory.CreateDirectory(_settings.ImageFolder);
			}

			Parallel.ForEach(_settings.UrlFormats.Keys, DownloadFiles);

			new FileCleaner(_settings.ImageFolder, _startDateTime.AddDays(-_settings.DaysCount)).Clean();
		}

		//public void Abort()
		//{
		//    Dispose(true);
		//    GC.SuppressFinalize(this);
		//}

		private void DownloadFiles(string key)
		{
			var days = _settings.DaysCount;
			var fmt = _settings.UrlFormats[key];
			var localDir = Path.Combine(_settings.ImageFolder, key);

			if (!Directory.Exists(localDir))
			{
				Directory.CreateDirectory(localDir);
			}

			for (int day = 0; day < days; day++)
			{
				var url = FormatFileUrl(fmt, _startDateTime.AddDays(-day));
				var dl = new FileDownloader(url, localDir);
				dl.Download();
			}
		}

		private static string FormatFileUrl(string format, DateTime date)
		{
			return String.Format(format, date.Day, date.Month, date.Year / 100, date.Year % 100);
		}

		private void OnFileProgressChanged(string fileName, int progress)
		{
			//var handler = FileProgressChanged;
			//if (handler != null)
			//{
			//    handler(this, new UpdaterEventArgs(fileName, progress));
			//}
		}

		//public event EventHandler<UpdaterEventArgs> FileProgressChanged;
	}

	//public sealed class UpdaterEventArgs : EventArgs
	//{
	//    private readonly string _fileName;
	//    private readonly int _progress;

	//    public UpdaterEventArgs(string fileName, int progress)
	//    {
	//        _fileName = fileName;
	//        _progress = progress;
	//    }

	//    public string FileName
	//    {
	//        get { return _fileName; }
	//    }

	//    public int Progress
	//    {
	//        get { return _progress; }
	//    }
	//}
}
