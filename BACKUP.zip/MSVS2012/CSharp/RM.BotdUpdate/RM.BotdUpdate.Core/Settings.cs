﻿using System;
using System.IO;
using System.Reflection;
using RM.BotdUpdate.Core.Persistance;

namespace RM.BotdUpdate.Core
{
	internal class Settings : ISettings
	{
		private const string _defaultName = "botd.ini";

		private const int _defaultDays = 1;
		private const string _defaultFolder = "botd";
		private const int _defaultDelay = 5;

		private static Settings _default;

		private readonly IniFile _ini;
		private readonly IKeyedStorage<string, string> _general;

		public Settings(string fileName)
		{
			_ini = new IniFile(fileName);
			_general = _ini["General"];
		}

		public int DaysCount
		{
			get { return StrToInt(_general["DaysCount"], _defaultDays); }
			set { _general["DaysCount"] = IntToStr(value); }
		}

		public string ImageFolder
		{
			get { return _general["ImageFolder"] ?? _defaultFolder; }
			set { _general["ImageFolder"] = value; }
		}

		public IKeyedStorage<string, string> UrlFormats
		{
			get { return _ini["UrlFormats"]; }
		}

		public int DelayBeforeExit
		{
			get { return StrToInt(_general["DelayBeforeExit"], _defaultDelay); }
			set { _general["DelayBeforeExit"] = IntToStr(value); }
		}

		public static Settings Default
		{
			get { return _default ?? (_default = GetDefaultSettings()); }
		}

		private static Settings GetDefaultSettings()
		{
			var appFolder = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
			var defFile = Path.Combine(appFolder ?? String.Empty, _defaultName);
			return new Settings(defFile);
		}

		private static int StrToInt(string s, int defaultValue)
		{
			int i;
			return Int32.TryParse(s, out i) ? i : defaultValue;
		}

		private static string IntToStr(int i)
		{
			return i.ToString("D");
		}
	}
}
