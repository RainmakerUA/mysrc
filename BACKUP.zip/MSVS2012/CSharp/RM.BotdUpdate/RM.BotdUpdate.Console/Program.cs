﻿using System;
using RM.BotdUpdate.Core;

namespace RM.BotdUpdate.Console
{
	internal static class Program
	{
		private static void Main(string[] args)
		{
			try
			{
				new Updater().Update();
			}
			catch (Exception e)
			{
				System.Console.WriteLine(e);
			}
		}
	}
}
