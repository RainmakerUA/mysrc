//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RMDesktops.rc
//


#define IDR_MAINFRAME			128

#define IDD_PREVIEWDIALOG		101
#define IDD_OPTIONS				102
#define IDD_ABOUTBOX			103

#define IDS_APP_TITLE			113

#define IDM_ABOUT				114
#define IDM_EXIT				115

#define IDM_OPTIONS				0x46Eu
#define IDM_SELECTDESKTOP		0x46Fu


#define IDI_RMDESKTOPS			120
// ... at least 3 more icons

#define IDI_SMALL				130

#define IDC_RMDESKTOPS			109
#define IDC_MYICON				2
#ifndef IDC_STATIC
#define IDC_STATIC				-1
#endif
// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NO_MFC					130
#define _APS_NEXT_RESOURCE_VALUE	129
#define _APS_NEXT_COMMAND_VALUE		32771
#define _APS_NEXT_CONTROL_VALUE		1000
#define _APS_NEXT_SYMED_VALUE		110
#endif
#endif
