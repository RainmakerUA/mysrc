#pragma once

#define _FALSE ((BOOLEAN) 0)
#define _TRUE ((BOOLEAN) 1)

#define NUM_DESKS 4