#pragma once

#include "stdafx.h"

#define UNCONST(lpctstr) const_cast<const LPTSTR>(lpctstr)

extern char appVersion[8];

extern LPCTSTR taskBarClass;

extern LPCTSTR settingsFileName;
extern LPCTSTR appName;
extern LPCTSTR mainClassName;
extern LPCTSTR optionsName;
extern LPCTSTR errorCantSetHotKeys;
extern LPCTSTR desktopNames[NUM_DESKS];

extern LPCTSTR eventName;
extern LPCTSTR accelName;

extern LPCTSTR desktopTipFmt;