#include "StdAfx.h"
#include "Defines.h"

#ifdef _DEBUG
LPCTSTR settingsFileName = L"D:\\desktopSettings.bin";
char appVersion[9] = "RMDDEBUG";
#else
LPCTSTR settingsFileName = L"%APPDATA%\\RMDesktops\\settings.dat";
char appVersion[9] = "RMDV0950";
#endif


LPCTSTR taskBarClass = L"Shell_TrayWnd";

LPCTSTR appName = L"[RM] Desktops";
LPCTSTR mainClassName = L"RMDesktopsClass";
LPCTSTR optionsName = L"DesktopsOptions";
LPCTSTR errorCantSetHotKeys = L"One or more of the specified hotkeys are in use.\nSelect different hotkeys.";
LPCTSTR desktopNames[NUM_DESKS] = { L"Default", L"RMDesk1", L"RMDesk2", L"RMDesk3" };

LPCTSTR eventName = L"Local\\RMDesktop";
LPCTSTR accelName = L"ACCELERATORS";
LPCTSTR desktopTipFmt = L"Desktop %d";
