#include "stdafx.h"
#include "Settings.h"
#include "GlobalConsts.h"

static Settings settings;

static auto persistent_size = sizeof(Persistent);
static auto settings_size = sizeof(Settings);

LPTSTR GetSettingsFile()
{
	unsigned int len = MAX_PATH * sizeof(TCHAR);
	LPTSTR s = static_cast<LPTSTR>(LocalAlloc(LPTR, len));
	ExpandEnvironmentStrings(settingsFileName, s, len);
	return s;
}

Settings* Settings::getSettings()
{
	return &settings;
}

Persistent* Settings::getPersistentSettings()
{
	return &settings.persistent;
}

void Settings::loadSettings()
{
	if(!settings.settingsFile)
	{
		settings.settingsFile = GetSettingsFile();
	}

	HANDLE file = CreateFile(settings.settingsFile, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(file != INVALID_HANDLE_VALUE)
	{
		Persistent *p = getPersistentSettings();
		LPVOID ptr = static_cast<LPVOID>(p);
		DWORD read;

		ReadFile(file, ptr, persistent_size, &read, NULL);
		CloseHandle(file);
		
		if(read != persistent_size || strncmp(p->version, appVersion, Persistent::versionLength) != 0)
		{
			memset(ptr, 0, persistent_size);
		}
	}
}

void Settings::saveSettings()
{
	if(!settings.settingsFile)
	{
		settings.settingsFile = GetSettingsFile();
	}

	HANDLE file = CreateFile(settings.settingsFile, GENERIC_WRITE, 0, NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if(file != INVALID_HANDLE_VALUE)
	{
		Persistent *p = getPersistentSettings();
		strncpy_s(p->version, appVersion, Persistent::versionLength);
		LPCVOID ptr = static_cast<LPCVOID>(p);
		DWORD written;

		WriteFile(file, ptr, persistent_size, &written, NULL);
		CloseHandle(file);
	}
}
