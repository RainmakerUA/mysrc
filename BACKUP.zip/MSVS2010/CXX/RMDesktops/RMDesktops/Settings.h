#pragma once

#include "Defines.h"

typedef BOOLEAN (WINAPI *WOW64ENABLEFSREDIRPROC)(BOOLEAN);

class Persistent
{
	friend class Settings;

	static const int versionLength = 8;
	char version[versionLength];

public:
	BOOLEAN isOptionsShown;
	BOOLEAN useFnKeys;
	DWORD hkModifiers;
};

class Settings
{
	Persistent persistent;
	LPTSTR settingsFile;
public:
	BOOLEAN isVistaOrHigher;
	HINSTANCE instance;
	WOW64ENABLEFSREDIRPROC lpfnWow64EnableFsRedir;
	BYTE currentDesktop;
	HDESK desktops[NUM_DESKS];
	HWND desktopListener[NUM_DESKS];
	
	static Persistent* getPersistentSettings();
	static Settings* getSettings();
	static void loadSettings();
	static void saveSettings();
};

