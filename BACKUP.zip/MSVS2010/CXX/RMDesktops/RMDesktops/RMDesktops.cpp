// RMDesktops.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "Resource.h"
#include "Defines.h"
#include "GlobalConsts.h"
#define private public
#include "Settings.h"

ATOM RegisterDesktopsClass(HINSTANCE, LPTSTR);
HWND CreateListenerWindow(HINSTANCE);
BOOLEAN SetHotKeys(HWND);
BOOL CreateNotifyIcon(HWND);

LRESULT CALLBACK ListenerWndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK OptionsDialogProc(HWND hwndDlg, UINT, WPARAM, LPARAM);
LRESULT CALLBACK KeyboardLLHookProc(int, WPARAM, LPARAM);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	HANDLE hEvent = CreateEvent(NULL, FALSE, FALSE, eventName);

	if (GetLastError() == ERROR_ALREADY_EXISTS)
	{
		HWND hMain = FindWindow(mainClassName, NULL);

		if(hMain)
		{
			PostMessage(hMain, WM_COMMAND, IDM_OPTIONS, 0);

			for(int i = 0; i < 20; ++i)
			{
				HWND hOptions = FindWindow(NULL, optionsName);
				Sleep(100);

				if(hOptions)
				{
					SetForegroundWindow(hOptions);
					return 0;
				}
			}

			/*if(hOptions)
			{
				SetForegroundWindow(hOptions);
				return 0;
			}*/

			return 0;
		}
	}
	else
	{
		/*
		Settings *settings = Settings::getSettings();
		
		HACCEL hAccel = LoadAccelerators(hInstance, accelName);
		HDESK mainDesk = OpenDesktop(desktopNames[0], 0, FALSE, GENERIC_ALL);

		settings->desktops[0] = mainDesk;
		settings->isVistaOrHigher = (BYTE)(GetVersion() & 0xFF) >= 6;
		settings->instance = hInstance;

		SwitchDesktop(mainDesk);
		SetThreadDesktop(mainDesk);

		RegisterDesktopsClass(hInstance, UNCONST(mainClassName));

		HWND mainListener = CreateListenerWindow(hInstance);

		settings->desktopListener[0] = mainListener;

		if (mainListener)
		{
			BOOLEAN hotkeysSet;

			Settings::loadSettings();
			Persistent *persistent = Settings::getPersistentSettings();

			if( !(persistent->isOptionsShown && (hotkeysSet = SetHotKeys(mainListener))))
			{
				if(persistent->isOptionsShown && !hotkeysSet)
				{
					MessageBox(0, errorCantSetHotKeys, appName, MB_ICONHAND | MB_OK);
				}

				DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_OPTIONS), NULL, OptionsDialogProc, 0);
			}

			HINSTANCE hKernel32 = LoadLibrary(L"kernel32.dll");
			settings->lpfnWow64EnableFsRedir = (WOW64ENABLEFSREDIRPROC) GetProcAddress(hKernel32, "Wow64EnableWow64FsRedirection");

			MSG msg;
			while(GetMessage(&msg, NULL, 0, 0))
			{
				if (!TranslateAcceleratorW(mainListener, hAccel, &msg))
				{
					TranslateMessage(&msg);
					DispatchMessageW(&msg);
				}
			}

			return msg.wParam;
		}
		*/

		Settings::saveSettings();
	}
	
	return 1;
}

ATOM RegisterDesktopsClass(HINSTANCE hInst, LPTSTR className)
{
	WNDCLASS wClass;

	wClass.style = 0;
	wClass.lpfnWndProc = ListenerWndProc;
	wClass.cbClsExtra = 0;
	wClass.cbWndExtra = 0;
	wClass.hInstance = hInst;
	wClass.hIcon = 0;
	wClass.hCursor = LoadCursorW(hInst, L"NULLCURSOR");
	wClass.hbrBackground = 0;
	wClass.lpszMenuName = 0;
	wClass.lpszClassName = L"DesktopsClass";
	return RegisterClassW(&wClass);
}

HWND CreateListenerWindow(HINSTANCE hInst)
{
	HWND result = CreateWindowExW(WS_EX_TOOLWINDOW, mainClassName, appName, WS_POPUP,
			0, 0, 0, 0, NULL, NULL, hInst, NULL
		);

	if(result)
	{
		ShowWindow(result, SW_HIDE);

		if(Settings::getSettings()->currentDesktop)
		{
			SetWindowsHookEx(WH_KEYBOARD_LL, KeyboardLLHookProc, hInst, 0);
		}

		CreateNotifyIcon(result);
	}

	return result;
}

BOOLEAN SetHotKeys(HWND hWindListener)
{
	BOOLEAN success = _TRUE;
	Persistent *pers = Settings::getPersistentSettings();

	for(int i = 0; i < NUM_DESKS; ++i)
	{
		if(!RegisterHotKey(hWindListener, i, pers->hkModifiers, (i + (pers->useFnKeys ? VK_F1 : '1'))))
		{
			success = _FALSE;
			break;
		}
	}

	if(!success)
	{
		for(char i = 0; i < NUM_DESKS; ++i)
		{
			UnregisterHotKey(hWindListener, i);
		}
	}
	
	return success;
}

BOOL CreateNotifyIcon(HWND hWnd)
{
	NOTIFYICONDATA data;
	Settings *s = Settings::getSettings();
	BYTE curr = s->currentDesktop;

	data.cbSize = sizeof(NOTIFYICONDATA);
	data.hWnd = hWnd;
	data.uID = 1;
	data.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
	data.uCallbackMessage = 0x464u;
	data.hIcon = LoadIcon(s->instance, MAKEINTRESOURCE(IDI_RMDESKTOPS + curr));
	swprintf_s(data.szTip, desktopTipFmt, curr + 1);
	//...

	return FALSE;
}

LRESULT CALLBACK ListenerWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	return DefWindowProc(hWnd, msg, wParam, lParam);
}

INT_PTR CALLBACK OptionsDialogProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	return 0;
}

LRESULT CALLBACK KeyboardLLHookProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if ( !nCode && wParam == WM_KEYFIRST && ((GetKeyState(VK_LWIN) & 0x8000) || (GetKeyState(VK_RWIN) & 0x8000)))
	{
		while(1)
		{
			throw 0;
		}
	}
		
	return CallNextHookEx(0, nCode, wParam, lParam);

}