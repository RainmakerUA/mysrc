﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Mount
{
	public partial class Default : System.Web.UI.Page
	{
		private const string _SELECT_FMT = "SELECT VDISK FILE=\"{0}\"";
		private const string _ATTACH = "ATTACH VDISK";
		private const string _DETACH = "DETACH VDISK";

		private void RunDiskpartCommands( string[] commands )
		{
			string scriptFile = Path.GetTempFileName();
			File.WriteAllLines( scriptFile , commands );

			var startInfo = new ProcessStartInfo
										 {
											 FileName = "diskpart" ,
											 Arguments = String.Format( "/s \"{0}\"" , scriptFile ) ,
											 CreateNoWindow = true ,
											 RedirectStandardOutput = true ,
											 StandardOutputEncoding = Encoding.GetEncoding( 866 ) ,
											 UseShellExecute = false
										 };

			var dp = Process.Start( startInfo );
			string output = dp.StandardOutput.ReadToEnd();
			dp.WaitForExit();

			TextBoxOutput.Text = output;

			File.Delete( scriptFile );
		}

		protected override void OnLoad( EventArgs e )
		{
			base.OnLoad( e );

			TextBoxVDisk.Text = @"T:\datax";
		}

		protected void ButtonMount_Click( object sender , EventArgs e )
		{
			RunDiskpartCommands( new string[] { String.Format( _SELECT_FMT , TextBoxVDisk.Text.Trim() ) , _ATTACH } );
		}

		protected void ButtonUnmount_Click( object sender , EventArgs e )
		{
			RunDiskpartCommands( new string[] { String.Format( _SELECT_FMT , TextBoxVDisk.Text.Trim() ) , _DETACH } );
		}
	}
}