﻿using System;

namespace RM.Brainfuck.Console.Model
{
	public enum Command
	{
		NoOp = 0,
		Inc,
		Dec,
		Fwd,
		Back,
		Loop,
		EndL,
		In,
		Out
	}
}
