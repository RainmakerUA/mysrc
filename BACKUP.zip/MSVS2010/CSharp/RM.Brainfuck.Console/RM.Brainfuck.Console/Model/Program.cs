﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace RM.Brainfuck.Console.Model
{
	public sealed class Program
	{
		private readonly string _name;
		private readonly ReadOnlyCollection<ComplexCommand> _commands;

		internal Program(string name, IList<ComplexCommand> commands)
		{
			_name = name;
			_commands = new ReadOnlyCollection<ComplexCommand>(commands);
		}

		public string Name
		{
			get { return _name; }
		}

		public IList<ComplexCommand> Commands
		{
			get { return _commands; }
		}
	}
}
