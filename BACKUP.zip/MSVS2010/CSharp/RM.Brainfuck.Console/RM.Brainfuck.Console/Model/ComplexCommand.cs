﻿using System;

namespace RM.Brainfuck.Console.Model
{
	public class ComplexCommand
	{
		private byte _count;
		private readonly Command _command;

		public ComplexCommand(Command command, byte count = 1)
		{
			_count = count;
			_command = command;
		}

		public byte Count {get { return _count; } }
		public Command Command { get { return _command; } }

		internal void IncCount()
		{
			_count++;
		}

		public override string ToString()
		{
			return String.Format(_count > 1 ? "{0}({1})" : "{0}", _command, _count );
		}
	}
}
