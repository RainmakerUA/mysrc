﻿using System;
using System.IO;
using System.Reflection.Emit;

namespace RM.Brainfuck.Console.Model
{
	public class CompiledAssembly
	{
		internal const string EXE = ".exe";

		private readonly string _asmName;
		private readonly AssemblyBuilder _asmBuilder;

		internal CompiledAssembly(string asmName, AssemblyBuilder asmBuilder)
		{
			if (asmName == null)
			{
				throw new ArgumentNullException("asmName");
			}

			if (asmBuilder == null)
			{
				throw new ArgumentNullException("asmBuilder");
			}


			_asmName = asmName;
			_asmBuilder = asmBuilder;
		}

		public string AssemblyName
		{
			get { return _asmName; }
		}

		public void Save(string directory = null)
		{
			var fileName = _asmName + EXE;

			_asmBuilder.Save(fileName);
			if (!String.IsNullOrEmpty(directory) && Directory.Exists(directory))
			{
				var srcPath = Path.GetFullPath(fileName);
				var targetPath = Path.Combine(directory, fileName);

				if (srcPath != targetPath)
				{
					if (File.Exists(targetPath))
					{
						File.Delete(targetPath);
					}

					File.Copy(srcPath, targetPath);
					File.Delete(srcPath);
				}
			}
		}
	}
}
