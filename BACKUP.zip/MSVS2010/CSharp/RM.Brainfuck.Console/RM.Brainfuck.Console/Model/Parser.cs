﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace RM.Brainfuck.Console.Model
{
	internal static class Parser
	{
		private static readonly Dictionary<char, Command> _commandMap = new Dictionary<char, Command>
		                                                               {
		                                                               		{ '+', Command.Inc},
																			{ '-', Command.Dec},
																			{ '>', Command.Fwd},
																			{ '<', Command.Back},
																			{ '[', Command.Loop},
																			{ ']', Command.EndL},
																			{ ',', Command.In},
																			{ '.', Command.Out}
		                                                               };

		private static readonly Command[] _stackableCommands = new[]
		                                                       {
		                                                       		Command.Inc,
																	Command.Dec,
																	Command.Fwd,
																	Command.Back
		                                                       };

		public static Program Parse(string program)
		{
			if (!IsValid(program))
			{
				throw new NotSupportedException("Program has inbalansed cycles!");
			}

			return new Program(
						ParseName(program),
						Optimize(ParseCommands(program))
					);
		}

		private static string ParseName(string program)
		{
			const string nameRegexFormat = @"^\s*""\s*(?'name'[^{0}]+)\s*""\s*";

			var skips = new List<char>(_commandMap.Keys).ConvertAll(EscapeCommandCharacter).ToArray();
			var re = new Regex(String.Format(nameRegexFormat, String.Concat(skips)));
			var match = re.Match(program);
			return match.Success ? match.Groups["name"].Value.Replace('_', '.') : null;
		}

		private static string EscapeCommandCharacter(char c)
		{
			return "\\" + c;
		}

		private static bool IsValid(string program)
		{
			const char loopS = '[';
			const char loopE = ']';

			var counts = new Dictionary<char, int>
			             {
			             		{loopS, 0},
			             		{loopE, 0}
			             };

			foreach (var cmd in program)
			{
				if (counts.ContainsKey(cmd))
				{
					if (cmd == loopE && counts[loopS] == 0)
					{
						return false;
					}

					counts[cmd]++;
				}
			}

			return counts[loopS] == counts[loopE];
		}

		private static IEnumerable<Command> ParseCommands(string program)
		{
			foreach (var opcode in program)
			{
				var cmd = ParseCommand(opcode);

				if (cmd != Command.NoOp)
				{
					yield return cmd;
				}
			}
		}

		private static Command ParseCommand(char opcode)
		{
			return _commandMap.ContainsKey(opcode) ? _commandMap[opcode] : Command.NoOp;
		}

		private static ComplexCommand[] Optimize(IEnumerable<Command> commands)
		{
			var res = new Stack<ComplexCommand>();

			foreach (var command in commands)
			{
				ComplexCommand cmd = null;

				if (res.Count > 0)
				{
					cmd = res.Peek();
				}

				if (cmd != null && command == cmd.Command && Array.IndexOf(_stackableCommands, command) >= 0)
				{
					cmd.IncCount();
				}
				else
				{
					res.Push(new ComplexCommand(command));
				}
			}

			var res2 = res.ToArray();
			Array.Reverse(res2);
			return res2;
		}
	}
}
