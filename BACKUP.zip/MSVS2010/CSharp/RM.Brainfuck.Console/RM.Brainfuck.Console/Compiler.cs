﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Reflection.Emit;
using RM.Brainfuck.Console.Model;

namespace RM.Brainfuck.Console
{
	internal static class Compiler
	{
		[DebuggerDisplay("S = #{Start.GetHashCode()}, E = #{End.GetHashCode()}")]
		private struct Labels
		{
			public readonly Label Start;
			public readonly Label End;

			public Labels(Label start, Label end)
			{
				Start = start;
				End = end;
			}
		}

		private const string _noname = "BFProgram";
		private const ushort MEM_SIZE = Int16.MaxValue + 1;
		private static readonly Type _byteType = typeof(byte);
		private static readonly MethodInfo _consoleRead = typeof(System.Console).GetMethod("Read", Type.EmptyTypes);
		private static readonly MethodInfo _consoleWrite = typeof(System.Console).GetMethod("Write", new[] { typeof(char) });

		public static CompiledAssembly Compile(string program, string programName = null)
		{
			MethodInfo @in, @out;

			var prg = Parser.Parse(program);
			var prgName = prg.Name ?? programName ?? _noname;

			var asm = AppDomain.CurrentDomain.DefineDynamicAssembly(
											new AssemblyName(prgName), AssemblyBuilderAccess.RunAndSave
										);
			var module = asm.DefineDynamicModule(prgName, prgName + CompiledAssembly.EXE);

			GenerateIOMethods(module, out @in, out @out);

			var main = module.DefineGlobalMethod(
					"Main",
					MethodAttributes.Private | MethodAttributes.Static | MethodAttributes.HideBySig,
					CallingConventions.Standard,
					typeof(void),
					new[] { typeof(string[]) }
				);

			var ilGen = main.GetILGenerator();

			ilGen.DeclareLocal(typeof(ushort));
			ilGen.DeclareLocal(typeof(byte[]));

			ilGen.Emit(OpCodes.Ldc_I4_0);
			ilGen.Emit(OpCodes.Stloc_0);
			ilGen.Emit(OpCodes.Ldc_I4, MEM_SIZE);
			ilGen.Emit(OpCodes.Newarr, _byteType);
			ilGen.Emit(OpCodes.Stloc_1);

			GenerateProgram(prg.Commands, ilGen, @in, @out);

			ilGen.Emit(OpCodes.Ret);

			module.CreateGlobalFunctions();
			asm.SetEntryPoint(main);
			return new CompiledAssembly(prgName, asm);
		}

		private static void GenerateIOMethods(ModuleBuilder module, out MethodInfo methodIn, out MethodInfo methodOut)
		{
			var @in = module.DefineGlobalMethod(
						"In",
						MethodAttributes.Private | MethodAttributes.Static | MethodAttributes.HideBySig,
						CallingConventions.Standard,
						typeof(byte),
						Type.EmptyTypes
					);

			var @out = module.DefineGlobalMethod(
						"Out",
						MethodAttributes.Private | MethodAttributes.Static | MethodAttributes.HideBySig,
						CallingConventions.Standard,
						typeof(void),
						new[] { typeof(byte) }
					);

			var ilGen = @in.GetILGenerator();
			var ret0 = ilGen.DefineLabel();
			ilGen.DeclareLocal(typeof(int));
			ilGen.Emit(OpCodes.Call, _consoleRead);
			ilGen.Emit(OpCodes.Stloc_0);
			ilGen.Emit(OpCodes.Ldloc_0);
			ilGen.Emit(OpCodes.Ldc_I4_M1);
			ilGen.Emit(OpCodes.Beq_S, ret0);
			ilGen.Emit(OpCodes.Ldloc_0);
			ilGen.Emit(OpCodes.Conv_U1);
			ilGen.Emit(OpCodes.Ret);
			ilGen.MarkLabel(ret0);
			ilGen.Emit(OpCodes.Ldc_I4_0);
			ilGen.Emit(OpCodes.Conv_U1);
			ilGen.Emit(OpCodes.Ret);

			ilGen = @out.GetILGenerator();
			ilGen.Emit(OpCodes.Ldarg_0);
			ilGen.Emit(OpCodes.Call, _consoleWrite);
			ilGen.Emit(OpCodes.Ret);

			methodIn = @in;
			methodOut = @out;
		}

		private static void GenerateProgram(IEnumerable<ComplexCommand> program, ILGenerator ilGen, MethodInfo inProc, MethodInfo outProc)
		{
			var loopStack = new Stack<Labels>();

			foreach (var cmd in program)
			{
				switch (cmd.Command)
				{
					case Command.Inc:
					case Command.Dec:
						ilGen.Emit(OpCodes.Ldloc_1);
						ilGen.Emit(OpCodes.Ldloc_0);
						ilGen.Emit(OpCodes.Ldelema, _byteType);
						ilGen.Emit(OpCodes.Dup);
						ilGen.Emit(OpCodes.Ldobj, _byteType);
						EmitInt(ilGen, cmd.Count);
						ilGen.Emit(cmd.Command == Command.Dec ? OpCodes.Sub : OpCodes.Add);
						ilGen.Emit(OpCodes.Conv_U1);
						ilGen.Emit(OpCodes.Stobj, _byteType);
						break;

					case Command.Fwd:
					case Command.Back:
						ilGen.Emit(OpCodes.Ldloc_0);
						EmitInt(ilGen, cmd.Count);
						ilGen.Emit(cmd.Command == Command.Back ? OpCodes.Sub : OpCodes.Add);
						ilGen.Emit(OpCodes.Stloc_0);
						break;

					case Command.Loop:
						var labels1 = new Labels(ilGen.DefineLabel(), ilGen.DefineLabel());
						loopStack.Push(labels1);
						ilGen.MarkLabel(labels1.Start);

						ilGen.Emit(OpCodes.Ldloc_1);
						ilGen.Emit(OpCodes.Ldloc_0);
						ilGen.Emit(OpCodes.Ldelema, _byteType);
						ilGen.Emit(OpCodes.Ldobj, _byteType);
						ilGen.Emit(OpCodes.Brfalse, labels1.End);
						break;

					case Command.EndL:
						var labels2 = loopStack.Pop();
						ilGen.Emit(OpCodes.Br, labels2.Start);
						ilGen.MarkLabel(labels2.End);
						break;

					case Command.In:
						ilGen.Emit(OpCodes.Ldloc_1);
						ilGen.Emit(OpCodes.Ldloc_0);
						ilGen.Emit(OpCodes.Call, inProc);
						ilGen.Emit(OpCodes.Stelem_I1);
						break;

					case Command.Out:
						ilGen.Emit(OpCodes.Ldloc_1);
						ilGen.Emit(OpCodes.Ldloc_0);
						ilGen.Emit(OpCodes.Ldelem_U1);
						ilGen.Emit(OpCodes.Call, outProc);
						break;

					default:
						throw new NotSupportedException("Unknown command (or NoOp)!");
				}
			}
		}

		private static void EmitInt(ILGenerator ilGen, int number)
		{
			switch (number)
			{
				case -1:
					ilGen.Emit(OpCodes.Ldc_I4_M1);
					break;
				case 0:
					ilGen.Emit(OpCodes.Ldc_I4_0);
					break;
				case 1:
					ilGen.Emit(OpCodes.Ldc_I4_1);
					break;
				case 2:
					ilGen.Emit(OpCodes.Ldc_I4_2);
					break;
				case 3:
					ilGen.Emit(OpCodes.Ldc_I4_3);
					break;
				case 4:
					ilGen.Emit(OpCodes.Ldc_I4_4);
					break;
				case 5:
					ilGen.Emit(OpCodes.Ldc_I4_5);
					break;
				case 6:
					ilGen.Emit(OpCodes.Ldc_I4_6);
					break;
				case 7:
					ilGen.Emit(OpCodes.Ldc_I4_7);
					break;
				case 8:
					ilGen.Emit(OpCodes.Ldc_I4_8);
					break;
				default:
					if (number > SByte.MinValue && number < SByte.MaxValue)
					{
						ilGen.Emit(OpCodes.Ldc_I4_S, number);
					}
					else
					{
						ilGen.Emit(OpCodes.Ldc_I4, number);
					}
					break;
			}
		}
	}
}
