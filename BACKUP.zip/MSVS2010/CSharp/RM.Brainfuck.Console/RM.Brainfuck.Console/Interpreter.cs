﻿using System;
using System.Collections.Generic;
using RM.Brainfuck.Console.Model;

namespace RM.Brainfuck.Console
{
	internal sealed class Interpreter
	{
		public delegate byte InMethod();
		public delegate void OutMethod(byte val);

		private int _ptr;
		private readonly byte[] _memory;
		private readonly IList<ComplexCommand> _program;

		private readonly InMethod _in;
		private readonly OutMethod _out;

		private int _pc;
		private readonly Dictionary<int, int> _loopEnds;

		public Interpreter(string program, InMethod inMethod = null, OutMethod outMethod = null)
		{
			_program = Parser.Parse(program).Commands;
			_in = inMethod ?? InImpl;
			_out = outMethod ?? OutImpl;

			_ptr = 0;
			_memory = new byte[Int16.MaxValue + 1];

			_pc = 0;
			_loopEnds = new Dictionary<int, int>();
		}

		public void Run()
		{
			while (_pc < _program.Count)
			{
				Step();
			}
		}

		private void Step()
		{
			var cmd = _program[_pc];

			switch (cmd.Command)
			{
				case Command.Inc:
					_memory[_ptr] += cmd.Count;
					break;

				case Command.Dec:
					_memory[_ptr] -= cmd.Count;
					break;

				case Command.Fwd:
					_ptr += cmd.Count;
					break;

				case Command.Back:
					_ptr -= cmd.Count;
					break;

				case Command.Loop:
					if (!_loopEnds.ContainsKey(_pc))
					{
						_loopEnds.Add(_pc, FindLoopEnd(_program, _pc));
					}

					if (_memory[_ptr] == 0)
					{
						_pc = _loopEnds[_pc] + 1;
					}
					else
					{
						_pc++;
					}
					break;

				case Command.EndL:
// ReSharper disable PossibleInvalidOperationException
					_pc = FindFirstKey(_loopEnds, _pc).Value;
// ReSharper restore PossibleInvalidOperationException
					break;

				case Command.In:
					_memory[_ptr] = _in();
					break;

				case Command.Out:
					_out(_memory[_ptr]);
					break;

				default:
					throw new NotSupportedException("Unsupported command!");
			}

			if (cmd.Command != Command.Loop && cmd.Command != Command.EndL)
			{
				_pc++;
			}
		}

		private static int FindLoopEnd(IList<ComplexCommand> prg, int startIndex)
		{
			var innerLoops = 0;

			for (int i = startIndex + 1; i < prg.Count; i++)
			{
				switch (prg[i].Command)
				{
					case Command.Loop:
						innerLoops++;
						break;

					case Command.EndL:
						if (innerLoops == 0)
						{
							return i;
						}

						innerLoops--;
						break;
				}
			}

			return -1;
		}

		private static K? FindFirstKey<K, V>(IDictionary<K, V> dict, V value) where K : struct
		{
			foreach (var pair in dict)
			{
				if (pair.Value.Equals(value))
				{
					return pair.Key;
				}
			}

			return null;
		}

		private static byte InImpl()
		{
			var inp = System.Console.Read();
			return (byte)(inp == -1 ? 0 : inp);
		}

		private static void OutImpl(byte chr)
		{
			System.Console.Write((char)chr);
		}
	}
}
