﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace RM.Brainfuck.Test
{
	internal static class IO
	{
		private const char _quote = '"';

		private static readonly string _inStr;
		private static readonly int _inLen;
		private static readonly List<byte> _outBytes = new List<byte>();

		private static int _inCurrent;

		static IO()
		{
			var cmdLine = Environment.CommandLine;
			var exeName = Assembly.GetEntryAssembly().Location;

			int exeLen = exeName.Length + 2 * (cmdLine[0] == _quote ? 1 : 0);
			cmdLine = cmdLine.Substring(exeLen).Trim();

			if (!String.IsNullOrEmpty(cmdLine))
			{
				_inStr = cmdLine;
				_inLen = _inStr.Length;
			}
		}

		public static byte In()
		{
			if (_inStr == null)
			{
				int num = Console.Read();
				if (num != -1)
				{
					return (byte)num;
				}
			}
			else
			{
				if (_inCurrent < _inLen)
				{
					return (byte)_inStr[_inCurrent++];
				}
			}

			return 0;
		}

		public static void Out(byte b)
		{
			if (_inStr == null)
			{
				Console.Write((char)b);
			}
			else
			{
				_outBytes.Add(b);
			}
		}

		public static void Flush()
		{
			foreach (var b in _outBytes)
			{
				Console.Write((char)b);
			}
		}
	}

	class ProgramOld
	{
		//static void Main(string[] args)
		//{
		//    ushort index = 0;
		//    byte[] buffer = new byte[0x8000];
		//    buffer[index] = IO.In();
		//    while (buffer[index] != 0)
		//    {
		//        while (true)
		//        {
		//            if (buffer[index] == 0)
		//            {
		//                break;
		//            }
		//            index = (ushort)(index + 1);
		//            buffer[index] = (byte)(buffer[index] + 1);
		//            index = (ushort)(index - 1);
		//            buffer[index] = (byte)(buffer[index] - 1);
		//        }
		//        index = (ushort)(index + 1);
		//        IO.Out(buffer[index]);
		//        index = (ushort)(index - 1);
		//        buffer[index] = IO.In();
		//    }

		//    IO.Flush();
		//}

		//private static byte In()
		//{
		//    int num = Console.Read();
		//    if (num != -1)
		//    {
		//        return (byte)num;
		//    }
		//    return (byte)0;
		//}

		//private static void Out(byte num1)
		//{
		//    Console.Write((char)num1);
		//}
	}
}
