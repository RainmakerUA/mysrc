﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace RM.Lib.Testing
{
	public class StringContainer : INotifyPropertyChanged
	{
		private string _value;

		public string Value
		{
			get
			{
				return _value;
			}
			set
			{
				_value = value;

				var handler = PropertyChanged;
				if ( handler != null )
				{
					handler( this , new PropertyChangedEventArgs( "Value" ) );
				}
			}
		}

		public override string ToString()
		{
			return Value ?? String.Empty;
		}

		#region Implementation of INotifyPropertyChanged

		public event PropertyChangedEventHandler PropertyChanged;

		#endregion
	}
}
