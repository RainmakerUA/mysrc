﻿namespace RM.Lib.Testing.Settings
{
	//[Serializable , SettingsData]
	public class TestingSettings
	{
		//public string Url { get; set; }

		//public int Number { get; set; }

		//[DefaultValue( "255.255.255.255" )]
		//public string TargetIp { get; set; }

		//[ReadOnlyProperty , DefaultValue( "http://ya.ru" )]
		//public string DefaultUrl { get; private set; }

		//[IgnoreProperty]
		//public IntPtr Dummy { get; set; }
	}

	//public class Provider<T> : BaseSettingsProvider<T> where T : class,new()
	//{
	//    public Provider()
	//    {
	//    }

	//    public Provider( T defData )
	//        : base( defData )
	//    {
	//    }

	//    protected override string GetSettingsLocation( System.Reflection.Assembly mainAssembly )
	//    {
	//        return String.Empty;
	//    }

	//    protected override Dictionary<string , object> LoadData( string location )
	//    {
	//        return new Dictionary<string , object>();
	//    }

	//    protected override void SaveData( string location , Dictionary<string , object> data )
	//    {
	//    }
	//}
}
