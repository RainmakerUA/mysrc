﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Input;
using RM.Lib.Localization;

namespace RM.Lib.Testing
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();

			PropertyLocalizer.Bind( GetType() , "TextBlockRT" , () => textBlockRT.Text );
			var helper = LocalizationManager.GetHelper(GetType());
			var tezt = helper.GetString("TextBlockRT");
		}

		protected override void OnMouseUp( MouseButtonEventArgs e )
		{
			base.OnMouseUp( e );
			LocalizationManager.CurrentUICulture = CultureInfo.CreateSpecificCulture( App.Locales[ new Random().Next( App.Locales.Length ) ] );
		}
	}
}
