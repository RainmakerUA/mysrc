﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using RM.Lib.Localization;
using RM.Lib.Localization.Providers;
using RM.Lib.Numerics;
using RM.Lib.Testing.Settings;

namespace RM.Lib.Testing
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
		internal static readonly string[] Locales = new[] { "en-US", "ru-RU", "uk-UA" };
		private static LocalizationHelper _locHelper;

		protected override void OnStartup(StartupEventArgs e)
		{
			base.OnStartup(e);

			XmlFileProvider.Initialize();
			//var prov = new XmlFileProvider<TestingSettings>();
			//prov.Load();
			//var s = prov.Settings;
			//var tpl = new Tuple<string , string>( s.Url , s.TargetIp );
			//s.Url = "http://119.161.80.12/adfree.php?zip=0&hostnamesonly=1";
			//s.TargetIp = "119.161.80.12";
			//prov.Save();
			//prov.Save( @"C:\Temp\!!S.cfg" );

			//var p = new Provider<TestingSettings>();
			//var s = p.Settings;

			//s.TargetIp = "192.168.0.1";
			//s.Number = -19;
			//s.Dummy = System.Reflection.MethodBase.GetCurrentMethod().MethodHandle.Value;
			//s.Url = s.DefaultUrl;

			//int t = Environment.TickCount;

			//for ( int i = 0 ; i < 10000 ; i++ )
			//{
			//    p.Save();
			//}

			//int dt = Environment.TickCount - t;

			var fr1 = Fraction.Parse("123/331");
			var fr2 = new Fraction(123.211);
			var fr3 = 124 - fr2;
			var fr4 = fr3 / fr1;
		}
	}
}
