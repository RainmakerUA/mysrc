﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Media;
using System.Xaml;
using System.Globalization;

namespace RM.Lib.Localization.Wpf
{
	/// <summary>
	/// XAML Markup extension for localizing properties.
	/// </summary>
	[MarkupExtensionReturnType( typeof( string ) )]
	public class LocalizeExtension : MarkupExtension
	{
		private class BindingData
		{
			private readonly string _key;
			private readonly object _object;
			private readonly object _property;
			private readonly LocalizationHelper _helper;

			public BindingData( string key , object obj , object property , Type rootType )
			{
				_key = key;
				_object = obj;
				_property = property;
				_helper = LocalizationManager.GetHelper( rootType );
			}

			public string Key { get { return _key; } }

			public object Object { get { return _object; } }

			public object Property { get { return _property; } }

			public LocalizationHelper Helper { get { return _helper; } }
		}

		private const string _WHITESPACE = "\x20";

		private static readonly List<BindingData> _targets = new List<BindingData>();

		private readonly string _key;

		static LocalizeExtension()
		{
			LocalizationManager.UICultureChanged += OnUICultureChanged;
		}

		/// <summary>
		/// Creates <see cref="LocalizeExtension"/> instance without specifying a key.
		/// There is no much use of it.
		/// </summary>
		public LocalizeExtension()
		{
			// Do nothing.
		}

		/// <summary>
		/// Creates <see cref="LocalizeExtension"/> instance with specified key in localization file/resource.
		/// </summary>
		/// <param name="key">Localization resource key.</param>
		public LocalizeExtension( string key )
			: this()
		{
			_key = key;
		}

		#region Overrides of MarkupExtension

		/// <summary>
		/// When implemented in a derived class, returns an object that is set as the value of the target property for this markup extension. 
		/// </summary>
		/// <returns>
		/// The object value to set on the property where the extension is applied. 
		/// </returns>
		/// <param name="serviceProvider">Object that can provide services for the markup extension.</param>
		public override object ProvideValue( IServiceProvider serviceProvider )
		{
			if ( String.IsNullOrEmpty( _key ) )
			{
				return _WHITESPACE;
			}

			object result = null;

			var targetProvider = serviceProvider.GetService( typeof( IProvideValueTarget ) ) as IProvideValueTarget;
			var rootProvider = serviceProvider.GetService( typeof( IRootObjectProvider ) ) as IRootObjectProvider;

			var targetObject = targetProvider != null ? targetProvider.TargetObject : null;

			if ( targetObject != null )
			{
				var targetProperty = targetProvider.TargetProperty;
				var dObj = targetObject as DependencyObject;
				var dProp = targetProperty as DependencyProperty;

				if ( dObj != null && DesignerProperties.GetIsInDesignMode( dObj ) )
				{
					result = _WHITESPACE;
				}
				else if ( dObj != null || dProp == null )
				{
					DependencyObject root = null;

					if ( rootProvider != null )
					{
						root = rootProvider.RootObject as DependencyObject;
					}
					else if ( dObj != null )
					{
						root = dObj;

						DependencyObject parent;
						while ((parent = VisualTreeHelper.GetParent(root))!=null)
						{
							root = parent;
						}
					}

					var rootType = root == null ? null : root.GetType();
					if ( rootType == null )
					{
						throw new InvalidOperationException( "Cannot find root object!" );
					}

					var data = new BindingData( _key , targetObject , targetProperty , rootType );
					_targets.Add( data );

					result = GetLocalization( data );
				}
				else
				{
					result = this;
				}
			}

			return result;
		}

		#endregion

		private static string GetLocalization( BindingData data )
		{
			return data.Helper.GetString( data.Key );
		}

		private static void UpdateTargets()
		{
			foreach ( var target in _targets )
			{
				if ( target.Property is DependencyProperty )
				{
					var depObject = target.Object as DependencyObject;
					if ( depObject != null )
					{
						depObject.SetValue( target.Property as DependencyProperty , GetLocalization( target ) );
					}
				}

				if ( target.Property is PropertyInfo )
				{
					( target.Property as PropertyInfo ).SetValue( target.Object , GetLocalization( target ) , null );
				}
			}

		}

		private static void OnUICultureChanged( CultureInfo culture )
		{
			UpdateTargets();
		}
	}
}
