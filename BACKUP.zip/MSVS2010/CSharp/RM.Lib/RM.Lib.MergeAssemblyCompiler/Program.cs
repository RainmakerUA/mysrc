﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Resources;
using Mono.Cecil;

namespace RM.Lib.MergeAssemblyCompiler
{
	internal static class Program
	{
		private static void PrintUsage()
		{
			Console.WriteLine(
					@"Usage: <program-file> <method> <source-dir> <target-dir>
where:
	<program-file> - this EXE-file,
	<method> - conversion method (available: null, gzip),
	<source> - directory with main assembly. All near-by *.dll files will be merged."
				);
		}

		private static void Merge( string mainAsm , IEnumerable<string> asms , string method )
		{
			Func<byte[] , byte[]> dataConverter;
			switch ( method )
			{
				case MergedAssemblyResolver.NullConvert.Method:
					dataConverter = MergedAssemblyResolver.NullConvert.Convert;
					break;

				case MergedAssemblyResolver.GZipConvert.Method:
					dataConverter = MergedAssemblyResolver.GZipConvert.Convert;
					break;

				default:
					dataConverter = null;
					break;
			}

			if ( dataConverter != null )
			{
				var mainAsmBak = Path.ChangeExtension( mainAsm , ".bak" );
				File.Delete( mainAsmBak );
				File.Move( mainAsm , mainAsmBak );

				var mainAsmDef = AssemblyDefinition.ReadAssembly( mainAsmBak );
				var resources = mainAsmDef.MainModule.Resources;

				using ( var ms = new MemoryStream() )
				{
					using ( var rw = new ResourceWriter( ms ) )
					{
						foreach ( var asmName in asms )
						{
							rw.AddResource(
									MergedAssemblyResolver.ConvertName( Assembly.ReflectionOnlyLoadFrom( asmName ).GetName().Name , method ) ,
									dataConverter( File.ReadAllBytes( asmName ) )
								);
						}

						rw.Generate();
						resources.Add( new EmbeddedResource( MergedAssemblyResolver.ResDir , ManifestResourceAttributes.Public , ms.ToArray() ) );
					}

				}

				mainAsmDef.Write( mainAsm );
			}
		}

		private static void Main( string[] args )
		{
			MergedAssemblyResolver.Initialize();

			if ( args.Length == 2 )
			{
				var source = Path.GetFullPath( args[ 1 ] );
				var dlls = Directory.GetFiles( Path.GetDirectoryName( source ) , "*.dll" );
				Merge( source , dlls , args[ 0 ] );
			}
			else
			{
				PrintUsage();
			}

			Console.WriteLine("Press any key...");
			Console.ReadKey( true );
		}
	}
}
