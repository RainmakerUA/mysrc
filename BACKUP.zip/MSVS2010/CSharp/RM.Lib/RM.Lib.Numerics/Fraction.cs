﻿using System;
using System.Globalization;

namespace RM.Lib.Numerics
{
	public struct Fraction : IEquatable<Fraction>, IComparable<Fraction>, IEquatable<double>, IComparable<double>,
								IEquatable<long>, IComparable<long>
	{
		#region Fields

		private readonly bool _neg;
		private readonly ulong _numerator;
		private readonly ulong _denominator;

		#endregion

		#region Constructors

		public Fraction(long num)
			: this(Convert.ToUInt64(num > 0 ? num : -num), 1UL, num < 0)
		{
		}

		public Fraction(long numerator, long denominator)
		{
			ReduceFraction(ref numerator, ref denominator);
			_numerator = numerator;
			_denominator = denominator;
		}

		private Fraction(ulong num, ulong denom, bool neg)
		{
			_numerator = num;
			_denominator = denom;
			_neg = neg;
		}

		public Fraction(double dbl)
		{
			this = ParseDouble(dbl);
		}

		#endregion

		#region Properties

		public long Numerator
		{
			get { return _numerator; }
		}

		public long Denominator
		{
			get { return _denominator; }
		}

		#endregion

		#region Override methods

		public override bool Equals(object obj)
		{
			return obj != null && obj is Fraction && Equals((Fraction)obj);
		}

		public override int GetHashCode()
		{
			return ((_numerator.GetHashCode() % 0x5f5e0fd) ^ _denominator.GetHashCode());
		}

		public override string ToString()
		{
			return _denominator == 1 ? _numerator.ToString() : String.Format("{0}/{1}", _numerator, _denominator);
		}

		#endregion

		#region Interface implementation

		public bool Equals(Fraction other)
		{
			return (_numerator == 0 && other._numerator == 0)
						|| (_numerator == other._numerator && _denominator == other._denominator);
		}

		public int CompareTo(Fraction other)
		{
			return Convert.ToInt32(Substract(other).Numerator);
		}

		public bool Equals(double other)
		{
			return Equals(ParseDouble(other));
		}

		public int CompareTo(double other)
		{
			return CompareTo(ParseDouble(other));
		}

		public bool Equals(long other)
		{
			return Equals(new Fraction(other));
		}

		public int CompareTo(long other)
		{
			return CompareTo(new Fraction(other));
		}

		#endregion

		#region Public instance methods

		public Fraction Clone()
		{
			return new Fraction(_numerator, _denominator);
		}

		public double ToDouble()
		{
			return ((double)_numerator) / _denominator;
		}

		public Fraction Negate()
		{
			return new Fraction(-_numerator, _denominator);
		}

		public Fraction Inverse()
		{
			if (_numerator == 0)
			{
				throw new FractionException("Operation not possible (Cannot inverse ZERO fraction)");
			}

			return new Fraction(_denominator, _numerator);
		}

		public Fraction Add(Fraction other)
		{
			try
			{
				checked
				{
					return new Fraction(
										_numerator * other._denominator + other._numerator * _denominator,
										_denominator * other._denominator
									);
				}
			}
			catch (OverflowException e)
			{
				throw new FractionException("Overflow occurred while performing arithemetic operation", e);
			}
			catch (Exception e)
			{
				throw new FractionException("An error occurred while performing arithemetic operation", e);
			}
		}

		public Fraction Substract(Fraction other)
		{
			return Add(other.Negate());
		}

		public Fraction Multiply(Fraction other)
		{
			try
			{
				checked
				{
					return new Fraction(
										_numerator * other._numerator,
										_denominator * other._denominator
									);
				}
			}
			catch (OverflowException e)
			{
				throw new FractionException("Overflow occurred while performing arithemetic operation", e);
			}
			catch (Exception e)
			{
				throw new FractionException("An error occurred while performing arithemetic operation", e);
			}
		}

		public Fraction Divide(Fraction other)
		{
			return Multiply(other.Inverse());
		}

		#endregion

		#region Operators

		#region Arithmetic

		public static Fraction operator -(Fraction frac1)
		{
			return frac1.Negate();
		}

		public static Fraction operator +(Fraction frac1, Fraction frac2)
		{
			return frac1.Add(frac2);
		}

		public static Fraction operator -(Fraction frac1, Fraction frac2)
		{
			return frac1.Substract(frac2);
		}

		public static Fraction operator *(Fraction frac1, Fraction frac2)
		{
			return frac1.Multiply(frac2);
		}

		public static Fraction operator /(Fraction frac1, Fraction frac2)
		{
			return frac1.Divide(frac2);
		}

		#endregion

		#region Comparison

		public static bool operator ==(Fraction frac1, Fraction frac2)
		{
			return frac1.Equals(frac2);
		}

		public static bool operator !=(Fraction frac1, Fraction frac2)
		{
			return !frac1.Equals(frac2);
		}

		public static bool operator ==(Fraction frac1, long num)
		{
			return frac1.Equals(new Fraction(num));
		}

		public static bool operator !=(Fraction frac1, long num)
		{
			return !frac1.Equals(num);
		}

		public static bool operator ==(Fraction frac1, double dbl)
		{
			return frac1.Equals(dbl);
		}

		public static bool operator !=(Fraction frac1, double dbl)
		{
			return !frac1.Equals(dbl);
		}

		public static bool operator <(Fraction frac1, Fraction frac2)
		{
			return frac1.CompareTo(frac2) < 0;
		}

		public static bool operator >(Fraction frac1, Fraction frac2)
		{
			return frac1.CompareTo(frac2) > 0;
		}

		public static bool operator >=(Fraction frac1, Fraction frac2)
		{
			return !(frac1 < frac2);
		}

		public static bool operator <=(Fraction frac1, Fraction frac2)
		{
			return !(frac1 > frac2);
		}

		#endregion

		#region Conversion

		public static implicit operator Fraction(long num)
		{
			return new Fraction(num);
		}

		public static implicit operator Fraction(double num)
		{
			return new Fraction(num);
		}

		public static explicit operator double(Fraction frac)
		{
			return frac.ToDouble();
		}

		#endregion

		#endregion Operators

		#region Public static methods

		public static Fraction Parse(string str)
		{
			if (String.IsNullOrEmpty(str))
			{
				return new Fraction(0);
			}

			var pos = str.IndexOf('/');
			if (pos == -1)
			{
				return ParseDouble(Double.Parse(str, CultureInfo.InvariantCulture));
			}

			return new Fraction(
									Int64.Parse(str.Substring(0, pos), CultureInfo.InvariantCulture),
									Int64.Parse(str.Substring(pos + 1), CultureInfo.InvariantCulture)
								);
		}

		#endregion

		#region Private methods

		private static Fraction ParseDouble(double dbl)
		{
			var bits = BitConverter.GetBytes(dbl);
			var expBits = new byte[2];
			Array.Copy(bits, 6, expBits, 0, 2);
			var exp = (BitConverter.ToUInt16(expBits, 0) & 0x3fff) >> 4;
			var neg = (bits[7] & 0x80) != 0;
			var frac1 = new Fraction(neg ? -1 : 1, 1L << (1023 - exp));

			return ParseDouble_(dbl);
		}

		private static Fraction ParseDouble_(double dValue)
		{
			try
			{
				checked
				{
					Fraction frac;
					if (dValue % 1 == 0)	// if whole number
					{
						frac = new Fraction(Convert.ToInt64(dValue));
					}
					else
					{
						double dTemp = dValue;
						long iMultiple = 1;
						string strTemp = dValue.ToString();
						while (strTemp.IndexOf("E") > 0)	// if in the form like 12E-9
						{
							dTemp *= 10;
							iMultiple *= 10;
							strTemp = dTemp.ToString();
						}
						int i = 0;
						while (strTemp[i] != '.')
							i++;
						int iDigitsAfterDecimal = strTemp.Length - i - 1;
						while (iDigitsAfterDecimal > 0)
						{
							dTemp *= 10;
							iMultiple *= 10;
							iDigitsAfterDecimal--;
						}
						frac = new Fraction((int)Math.Round(dTemp), iMultiple);
					}
					return frac;
				}
			}
			catch (OverflowException)
			{
				throw new FractionException("Conversion not possible due to overflow");
			}
			catch (Exception)
			{
				throw new FractionException("Conversion not possible");
			}
		}

		private static ulong GCD(ulong num1, ulong num2)
		{
			do
			{
				if (num1 < num2)
				{
					var tmp = num1;
					num1 = num2;
					num2 = tmp;
				}

				num1 = num1 % num2;
			}
			while (num1 != 0);

			return num2;
		}

		private static void ReduceFraction(ref ulong numerator, ref ulong denominator)
		{
			if (numerator == 0)
			{
				denominator = 1;
				return;
			}

			var gcd = GCD(numerator, denominator);
			numerator /= gcd;
			denominator /= gcd;
		}

		#endregion
	}

	public class FractionException : Exception
	{
		public FractionException()
		{
		}

		public FractionException(string message)
			: base(message)
		{
		}

		public FractionException(string message, Exception innerException)
			: base(message, innerException)
		{
		}
	}
}
