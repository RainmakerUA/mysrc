﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq.Expressions;
using System.Reflection;

namespace RM.Lib.Localization
{
	///<summary>
	/// Bind object properties to localization strings.
	///</summary>
	public sealed class PropertyLocalizer
	{
		private static readonly List<PropertyLocalizer> _propertyBindings = new List<PropertyLocalizer>();

		private readonly string _key;
		private readonly object _targetObject;
		private readonly MemberInfo _targetMember;
		private readonly LocalizationHelper _helper;

		static PropertyLocalizer()
		{
			LocalizationManager.UICultureChanged += OnUICultureChanged;
		}

		private PropertyLocalizer(object obj, MemberInfo member, Type type, string key)
		{
			CheckWritableMember(member);
			_targetObject = obj;
			_targetMember = member;
			_helper = LocalizationManager.GetHelper(type);
			_key = key;
		}

		private string GetLocalization()
		{
			return _helper.GetString(_key);
		}

		private void UpdateValue()
		{
			var value = GetLocalization();

			if (_targetMember is PropertyInfo)
			{
				var prop = _targetMember as PropertyInfo;
				prop.SetValue(_targetObject, value, null);
			}
			else if (_targetMember is FieldInfo)
			{
				var field = _targetMember as FieldInfo;
				field.SetValue(_targetObject, value);
			}
		}

		/// <summary>
		/// Binds object property to specified localization.
		/// Property value will updates when locale changes.
		/// </summary>
		/// <typeparam name="T">
		/// Property type. Only <see cref="T:System.String"/> and <see cref="T:System.Object"/> are supported.
		/// </typeparam>
		/// <param name="type">Type, localization strings are associated with.</param>
		/// <param name="key">Localization resources key.</param>
		/// <param name="property">Expression that specifies target property.</param>
		public static void Bind<T>(Type type, string key, Expression<Func<T>> property)
		{
			if (typeof(T) != typeof(string) && typeof(T) != typeof(object))
			{
				throw new ArgumentException("Property type must be System.String or System.Object");
			}

			if (type == null)
			{
				throw new ArgumentNullException("type");
			}

			if (String.IsNullOrEmpty(key))
			{
				throw new ArgumentException("Localization key cannot be empty!", "key");
			}

			if (property == null)
			{
				throw new ArgumentNullException("property");
			}

			if (!(property.Body is MemberExpression))
			{
				throw new ArgumentException("property expression must be MemberExpression!");
			}

			var propertyExpr = property.Body as MemberExpression;
			MemberExpression me = propertyExpr;
			var members = new Stack<MemberExpression>();

			while (me != null && !(me.Expression is ConstantExpression))
			{
				members.Push(me);
				me = me.Expression as MemberExpression;
			}

			if (me != null)
			{
				var ce = me.Expression as ConstantExpression;
				object obj = ce.Value;

				members.Push(me);
				var memberList = new List<MemberExpression>(members);

				for (int i = 0; i < memberList.Count - 1; ++i) // till Length -2
				{
					MemberInfo member = memberList[i].Member;

					if (member is PropertyInfo)
					{
						var prop = member as PropertyInfo;
						obj = prop.GetValue(obj, null);
					}
					else if (member is FieldInfo)
					{
						var field = member as FieldInfo;
						obj = field.GetValue(obj);
					}

					if (obj == null)
					{
						throw new ArgumentNullException(member.Name);
					}
				}

				var topMember = memberList[memberList.Count - 1].Member;
				var binding = new PropertyLocalizer(obj, topMember, type, key);
				binding.UpdateValue();
				_propertyBindings.Add(binding);
			}
		}

		/// <summary>
		/// Checks whether provided field/property is writeable.
		/// </summary>
		/// <param name="member">Field or Property info.</param>
		/// <exception cref="T:System.NotSupportedException">Thrown if specified member is read-only.</exception>
		/// <exception cref="T:System.ArgumentException">
		/// Thrown if provided member info is neither <see cref="T:System.Reflection.FieldInfo"/> nor <see cref="T:System.Reflection.PropertyInfo"/>.
		/// </exception>
		private static void CheckWritableMember(MemberInfo member)
		{
			if (member is PropertyInfo)
			{
				var prop = member as PropertyInfo;
				if (!prop.CanWrite)
				{
					ThrowReadonlyMember(prop.Name);
				}
			}
			else if (member is FieldInfo)
			{
				var field = member as FieldInfo;
				if (field.IsInitOnly || field.IsLiteral)
				{
					ThrowReadonlyMember(field.Name);
				}
			}
			else
			{
				throw new ArgumentException("Member must be one of PropertyInfo or FieldInfo", "member");
			}
		}

		private static void ThrowReadonlyMember(string name)
		{
			throw new NotSupportedException(String.Format("Cannot set '{0}', it is readonly!", name));
		}

		private static void OnUICultureChanged(CultureInfo obj)
		{
			foreach (var binding in _propertyBindings)
			{
				binding.UpdateValue();
			}
		}
	}
}
