﻿using System;
using System.Reflection;

namespace RM.Lib.Localization
{
	public class LocalizationHelper
	{
		private readonly string _typeName;
		private readonly Assembly _assembly;

		internal LocalizationHelper(string typeName, Assembly assembly)
		{
			if (String.IsNullOrEmpty(typeName))
			{
				throw new ArgumentException("typeName cannot be empty!", "typeName");
			}

			if (assembly == null)
			{
				throw new ArgumentNullException("assembly");
			}

			_typeName = typeName;
			_assembly = assembly;
		}

		public string GetString(string key)
		{
			return LocalizationManager.GetTypeString(_typeName, _assembly, key);
		}

		public string GetString(string key, params object[] args)
		{
			return LocalizationManager.GetTypeString(_typeName, _assembly, key, args);
		}
	}
}
