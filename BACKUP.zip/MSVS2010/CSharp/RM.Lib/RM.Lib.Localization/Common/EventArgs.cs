﻿using System;

namespace RM.Lib.Localization.Common
{
	/// <summary>
	/// Represents generic event data with one value.
	/// </summary>
	/// <typeparam name="T">Event value type.</typeparam>
	public class EventArgs<T> : EventArgs
	{
		private readonly T _arg;

		/// <summary>
		/// Creates an instance of EventArgs&lt;T&gt; class.
		/// </summary>
		/// <param name="arg">Event data value.</param>
		public EventArgs( T arg )
		{
			_arg = arg;
		}

		/// <summary>
		/// Gets event data.
		/// </summary>
		public T Arg
		{
			get { return _arg; }
		}
	}
}
