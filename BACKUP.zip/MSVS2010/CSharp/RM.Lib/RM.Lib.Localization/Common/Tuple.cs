﻿using System;
using System.Collections.Generic;

namespace RM.Lib.Localization.Common
{
	public class Tuple<T1, T2> : IComparable, IComparable<Tuple<T1, T2>>, IEquatable<Tuple<T1, T2>>
	{
		private readonly T1 _item1;
		private readonly T2 _item2;

		public Tuple(T1 item1, T2 item2)
		{
			_item1 = item1;
			_item2 = item2;
		}

		public T1 Item1 { get { return _item1; } }
		public T2 Item2 { get { return _item2; } }

		public int CompareTo(object obj)
		{
			if (obj == null)
			{
				return 1;
			}

			var tuple = obj as Tuple<T1, T2>;
			if (tuple == null)
			{
				throw new ArgumentException(String.Format("Invalid tuple type: {0}", GetType()), "obj");
			}

			return CompareTo(tuple);
		}

		public int CompareTo(Tuple<T1, T2> other)
		{
			if (other == null)
			{
				return 1;
			}

			var comparer1 = Comparer<T1>.Default;
			var comparer2 = Comparer<T2>.Default;

			int num = comparer1.Compare(_item1, other._item1);
			if (num != 0)
			{
				return num;
			}

			return comparer2.Compare(_item2, other._item2);
		}

		public bool Equals(Tuple<T1, T2> other)
		{
			return CompareTo(other) == 0;
		}
	}
}
