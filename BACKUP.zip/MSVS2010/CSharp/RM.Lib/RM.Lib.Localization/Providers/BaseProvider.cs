using System;
using System.Globalization;
using System.Reflection;

namespace RM.Lib.Localization.Providers
{
	/// <summary>
	/// Base class for localization providers.
	/// </summary>
	public abstract class BaseProvider : ILocalizationProvider
	{
		private const string _ERROR_PREFIX = "[?]";

		/// <summary>
		/// Finds localization string.
		/// </summary>
		/// <param name="assembly">Assembly as source for localization string.</param>
		/// <param name="culture">Localization culture.</param>
		/// <param name="key">Localization string key.</param>
		/// <returns>Localization string or null if not found.</returns>
		protected abstract string FindString(Assembly assembly, CultureInfo culture, string key);

		/// <summary>
		/// Gets localization string. Provides detailed fallback value if string not found.
		/// </summary>
		/// <param name="assembly">Assembly as source for localization string.</param>
		/// <param name="culture">Localization culture.</param>
		/// <param name="key">Localization string key.</param>
		/// <returns>Localization string.</returns>
		public string GetString(Assembly assembly, CultureInfo culture, string key)
		{
			return FindString(assembly, culture, key) ?? String.Format("{0}:[{1}]:'{2}'", _ERROR_PREFIX, GetAssemblyName(assembly), key);
		}

		private static string GetAssemblyName(Assembly assembly)
		{
			if (assembly == null)
			{
				throw new ArgumentNullException("assembly");
			}

			var longName = assembly.FullName;
			return longName.Substring(0, longName.IndexOf(','));
		}
	}
}