﻿using System.Globalization;
using System.Reflection;

namespace RM.Lib.Localization.Providers
{
	/// <summary>
	/// Represents localization strings provider.
	/// </summary>
	public interface ILocalizationProvider
	{
		/// <summary>
		/// Gets localization string.
		/// </summary>
		/// <param name="assembly">Assembly as source for localization string.</param>
		/// <param name="culture">Localization culture.</param>
		/// <param name="key">Localization string key.</param>
		/// <returns>Localization string.</returns>
		string GetString( Assembly assembly , CultureInfo culture , string key );
	}
}
