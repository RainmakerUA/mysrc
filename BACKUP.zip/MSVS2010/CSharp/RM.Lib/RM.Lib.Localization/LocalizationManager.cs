﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Threading;
using RM.Lib.Localization.Common;
using RM.Lib.Localization.Providers;

namespace RM.Lib.Localization
{
	public static class LocalizationManager
	{
		internal const char KeySeparator = '.';

		private static readonly List<Tuple<Thread, Action<CultureInfo>>> _handlers = new List<Tuple<Thread, Action<CultureInfo>>>();
		private static ILocalizationProvider _provider;

		public static CultureInfo CurrentUICulture
		{
			get
			{
				return Thread.CurrentThread.CurrentUICulture;
			}
			set
			{
				if (value == null)
				{
					throw new ArgumentNullException("value");
				}

				Thread.CurrentThread.CurrentUICulture = value;
				RaiseUICultureChanged(value);
			}
		}

		internal static void Initialize(ILocalizationProvider provider)
		{
			if (provider == null)
			{
				throw new ArgumentNullException("provider");
			}

			if (_provider != null)
			{
				throw new InvalidOperationException("Manager is already initialized!");
			}

			_provider = provider;
		}

		public static LocalizationHelper GetHelper(Type type)
		{
			//TODO: Caching
			return new LocalizationHelper(type.FullName, type.Assembly);
		}

		public static string GetTypeString(Type type, string typeKey)
		{
			return GetTypeString(type.FullName, type.Assembly, typeKey);
		}

		public static string GetTypeString(Type type, string typeKey, params string[] args)
		{
			return GetTypeString(type.FullName, type.Assembly, typeKey, args);
		}

		internal static string GetTypeString(string typeName, Assembly assembly, string typeKey)
		{
			CheckInitialized();
			return _provider.GetString(assembly, CurrentUICulture, GetFullKey(typeName, typeKey));
		}

		internal static string GetTypeString(string typeName, Assembly assembly, string typeKey, params object[] args)
		{
			return String.Format(GetTypeString(typeName, assembly, typeKey), args);
		}

		#region Private methods

		private static string GetFullKey(string typeName, string typeKey)
		{
			return String.Concat(typeName, KeySeparator, typeKey);
		}

		private static void CheckInitialized()
		{
			if (_provider == null)
			{
				throw new InvalidOperationException("Manager is not initialized!");
			}
		}

		private static void RaiseUICultureChanged(CultureInfo newCulture)
		{
			var thread = Thread.CurrentThread;
			foreach (var h in _handlers)
			{
				if (h.Item1 == thread && h.Item2 != null)
				{
					h.Item2.Invoke(newCulture);
				}
			}
		}

		#endregion

		public static event Action<CultureInfo> UICultureChanged
		{
			add
			{
				if (value == null)
				{
					throw new ArgumentNullException("value");
				}

				var thread = Thread.CurrentThread;
				var handler = value;

				if (!_handlers.Any(h => h.Item1 == thread && h.Item2 == handler))
				{
					_handlers.Add(new Tuple<Thread, Action<CultureInfo>>(thread, handler));
				}
			}
			remove
			{
				if (value == null)
				{
					throw new ArgumentNullException("value");
				}

				var thread = Thread.CurrentThread;
				var handler = value;

				var h = _handlers.FirstOrDefault(tuple => tuple.Item1 == thread && tuple.Item2 == handler);
				if (h != null)
				{
					_handlers.Remove(h);
				}
			}
		}
	}
}
