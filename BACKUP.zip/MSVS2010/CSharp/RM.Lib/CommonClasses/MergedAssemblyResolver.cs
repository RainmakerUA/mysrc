﻿using System;
using System.Collections;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Security.Cryptography;
using System.Text;
using ConvertFunc = System.Func<byte[] , byte[]>;

internal static class MergedAssemblyResolver
{
	#region Codecs

	public static class NullConvert
	{
		public const string Method = "null";

		public static byte[] Convert( byte[] data )
		{
			return data;
		}

		public static byte[] ConvertBack( byte[] data )
		{
			return data;
		}
	}

	public static class GZipConvert
	{
		public const string Method = "gzip";

		public static byte[] Convert( byte[] data )
		{
			byte[] res;
			using ( var ms = new MemoryStream() )
			{
				using ( var gs = new GZipStream( ms , CompressionMode.Compress , true ) )
				{
					gs.Write( data , 0 , data.Length );
				}
				res = ms.ToArray();
			}

			return res;
		}


		public static byte[] ConvertBack( byte[] data )
		{
			const int BS = 4096;
			var buffer = new byte[ BS ];
			byte[] res;
			using ( var ungs = new MemoryStream() )
			{
				using ( var ms = new MemoryStream( data ) )
				{
					using ( var gs = new GZipStream( ms , CompressionMode.Decompress , true ) )
					{
						int read;
						while ( ( read = gs.Read( buffer , 0 , buffer.Length ) ) > 0 )
						{
							ungs.Write( buffer , 0 , read );
						}
						res = ungs.ToArray();
					}
				}
			}

			return res;
		}
	}

	#endregion

	public const string ResDir = "RM.Merged.resources";
	private static string[] _keys;
	private static ResourceReader _reader;

	public static void Initialize()
	{
		var me = Assembly.GetEntryAssembly();
		if ( Array.IndexOf( me.GetManifestResourceNames() , ResDir ) > -1 )
		{
			var str = me.GetManifestResourceStream( ResDir );
			if ( str != null )
			{
				_reader = new ResourceReader( str );
				_keys = ( from DictionaryEntry res in _reader select res.Key as string ).ToArray();

				AppDomain.CurrentDomain.AssemblyResolve += OnAssemblyResolve;
			}
		}
	}

	public static string ConvertName( string name , string methodName )
	{
		return String.Format( "{0}.{1}" , EncryptAssemblyName( name ) , methodName );
	}

	private static string EncryptAssemblyName( string name )
	{
		byte[] fullNameBytes = Encoding.UTF8.GetBytes( name );
		var sha256 = SHA256.Create();
		var hash = sha256.ComputeHash( fullNameBytes );
		var sb = new StringBuilder();
		for ( int i = hash.Length - 1 ; i >= 0 ; --i )
		{
			sb.AppendFormat( "{0:X2}" , hash[ i ] );
		}

		return sb.ToString();
	}

	private static Assembly OnAssemblyResolve( object sender , ResolveEventArgs args )
	{
		var pos = args.Name.IndexOf( ',' );
		var name = args.Name.Substring( 0 , pos );
		var encName = EncryptAssemblyName( name );
		var key = _keys.FirstOrDefault( s => s.StartsWith( encName ) );
		if ( key != null )
		{
			var method = key.Substring( key.IndexOf( '.' ) + 1 );
			ConvertFunc converter;
			switch ( method )
			{
				case NullConvert.Method:
					converter = NullConvert.ConvertBack;
					break;

				case GZipConvert.Method:
					converter = GZipConvert.ConvertBack;
					break;

				default:
					converter = null;
					break;
			}

			byte[] data;
			string type;
			_reader.GetResourceData( key , out type , out data );

			if ( converter != null && data != null && data.Length > 0 )
			{
				var cutData = new byte[ data.Length - 4 ];
				Array.Copy( data , 4 , cutData , 0 , cutData.Length );
				return Assembly.Load( converter( cutData ) );
			}
		}

		return null;
	}
}