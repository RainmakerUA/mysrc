﻿using System;
using System.Collections.Specialized;
using System.Xml.Linq;

namespace RM.Lib.Localization.Providers
{
	/// <summary>
	/// Provides localization from XML files. This class cannot be inherited.
	/// </summary>
	public sealed class XmlFileProvider : BaseFileProvider
	{
		private static bool _isInitialized;

		private XmlFileProvider()
		{
		}

		/// <summary>
		/// Initializes localization provider.
		/// </summary>
		public static void Initialize()
		{
			if (!_isInitialized)
			{
				LocalizationManager.Initialize(new XmlFileProvider());
				_isInitialized = true;
			}
		}

		#region Overrides of BaseFileProvider

		protected override StringDictionary ReadFile(string filename)
		{
			var xdoc = XDocument.Load(filename);
			var dict = new StringDictionary();
			ParseElement(xdoc.Root, dict, String.Empty);
			return dict;
		}

		private static void ParseElement(XElement element, StringDictionary dict, string name)
		{
			if (element.Parent != null)
			{
				name = String.IsNullOrEmpty(name)
						? element.Name.LocalName
						: String.Concat(name, LocalizationManager.KeySeparator, element.Name.LocalName);
			}

			if (element.HasElements)
			{
				foreach (var subElement in element.Elements())
				{
					ParseElement(subElement, dict, name);
				}
			}
			else
			{
				dict.Add(String.Join(new String(LocalizationManager.KeySeparator, 1), name), element.Value);
			}
		}

		#endregion
	}
}
