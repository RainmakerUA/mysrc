﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Text;

namespace RM.Lib.Localization.Providers
{
	/// <summary>
	/// Provides localization from INI files. This class cannot be inherited.
	/// </summary>
	/// <remarks>
	/// Basic file line format (whitespaces around '=' are optional):
	/// Key = Value
	/// File may include section headers:
	/// [SectionName]
	/// Section names will be prepended to key values:
	/// [SuperKey]
	/// Key=Value
	/// is the same as:
	/// SuperKey.Key=Value
	/// Comments in file must have ';' as first character.
	/// </remarks>
	public sealed class IniFileProvider : BaseFileProvider
	{
		private const char _INI_SEPARATOR = '=';
		private const char _COMMENT = ';';
		private static readonly char[] _sectionChars = new[] { '[', ']' };
		private static readonly string[] _iniExtensions = new[] { ".ini" };
		private static bool _isInitialized;

		private IniFileProvider()
		{
		}

		public static void Initialize()
		{
			if (!_isInitialized)
			{
				LocalizationManager.Initialize(new IniFileProvider());
				_isInitialized = true;
			}
		}

		/// <summary>
		/// Gets valid file extensions for localization files.
		/// Adds '.ini' extension to default set.
		/// </summary>
		protected override IEnumerable<string> Extensions
		{
			get { return base.Extensions.Concat(_iniExtensions); }
		}

		/// <summary>
		/// Reads localization INI file content into key/value dictionary.
		/// </summary>
		/// <param name="filename">Name of file to read.</param>
		/// <returns>Localization key/value dictionary.</returns>
		protected override StringDictionary ReadFile(string filename)
		{
			var dict = new StringDictionary();
			string prefix = null;

			foreach (var line in File.ReadAllLines(filename))
			{
				string realLine = line.Trim();
				if (realLine.Length > 0 && realLine[0] != _COMMENT)
				{
					int pos = realLine.IndexOf(_INI_SEPARATOR);
					if (pos >= 0 && pos < realLine.Length)
					{
						var key = realLine.Substring(0, pos).Trim();

						if (!String.IsNullOrEmpty(prefix))
						{
							prefix = prefix.Trim(LocalizationManager.KeySeparator);
							key = key.Trim(LocalizationManager.KeySeparator);

							key = prefix + LocalizationManager.KeySeparator + key;
						}

						var value = realLine.Substring(pos + 1, realLine.Length - pos - 1).Trim();
						dict.Add(key, value);
					}
					else
					{
						var parts = line.Split(_sectionChars);
						if (parts.Length == 3 && String.IsNullOrEmpty(parts[0]) && String.IsNullOrEmpty(parts[2]))
						{
							prefix = parts[1];
						}
					}
				}
			}

			return dict;
		}
	}
}
