﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics.Contracts;
using System.Globalization;
using System.IO;
using System.Reflection;

namespace RM.Lib.Localization.Providers
{
	/// <summary>
	/// Base class for localization providers that use files as storage.
	/// Supports file names like 'AssemblyName.LC.ext', where:
	/// <list type="UL">
	/// <item>AssemblyName - assembly file name without extension.</item>
	/// <item>LC - culture or language name (e.g. en-US, es, ru).</item>
	/// <item>ext - one of possible extensions.</item>
	/// </list>
	/// </summary>
	[ContractClass( typeof( BaseFileProviderContracts ) )]
	public abstract class BaseFileProvider : BaseProvider
	{
		private static readonly string[] _defaultExt = new[] { ".lang" , ".lng" };
		private static readonly Assembly _mainAssembly = Assembly.GetEntryAssembly();

		private static readonly Dictionary<string , StringDictionary> _cache = new Dictionary<string , StringDictionary>();
		private static readonly Dictionary<string , DateTime> _cacheTimes = new Dictionary<string , DateTime>();

		/// <summary>
		/// Gets valid file extensions for localization files.
		/// </summary>
		protected virtual IEnumerable<string> Extensions { get { return _defaultExt; } }

		/// <summary>
		/// Finds localization string in files.
		/// </summary>
		/// <param name="assembly">Assembly as source for localization string.</param>
		/// <param name="culture">Localization culture.</param>
		/// <param name="key">Localization string key.</param>
		/// <returns>Localization string or null if not found.</returns>
		protected override string FindString( Assembly assembly , CultureInfo culture , string key )
		{
			var ini = GetDictionary( ResolveFileName( assembly , culture.Name ) );
			return ini != null && ini.ContainsKey( key ) ? ini[ key ] : null;
		}

		/// <summary>
		/// Finds localization file by generating and trying possible file names.
		/// </summary>
		/// <param name="assembly">Localization source assembly.</param>
		/// <param name="culture">Localization culture.</param>
		/// <returns>Localization file name or null if no one file is found.</returns>
		private string ResolveFileName( Assembly assembly , string culture )
		{
			var asmFile = assembly.Location;

			foreach ( var extension in Extensions )
			{
				var iniFile = Path.ChangeExtension( asmFile , String.Concat( extension[ 0 ] , culture , extension ) );
				if ( File.Exists( iniFile ) )
				{
					return iniFile;
				}
			}

			if ( culture.Length > 2 )
			{
				var shortFile = ResolveFileName( assembly , culture.Substring( 0 , 2 ) );
				if ( shortFile != null )
				{
					return shortFile;
				}
			}

			return assembly == _mainAssembly ? null : ResolveFileName( _mainAssembly , culture );
		}

		/// <summary>
		/// Gets localization key/value dictionary. Provides file content caching.
		/// </summary>
		/// <param name="filename">Name of file to read.</param>
		/// <returns>Localization key/value dictionary.</returns>
		private StringDictionary GetDictionary( string filename )
		{
			if ( filename == null || !File.Exists( filename ) )
			{
				return null;
			}

			bool isActual = false;
			if ( _cacheTimes.ContainsKey( filename ) )
			{
				DateTime cacheTime = _cacheTimes[ filename ];
				DateTime modTime = File.GetLastWriteTime( filename );
				isActual = modTime <= cacheTime;
			}

			if ( !isActual )
			{
				var contents = ReadFile( filename );
				_cache[ filename ] = contents;
				_cacheTimes[ filename ] = DateTime.Now;
			}

			return _cache[ filename ];
		}

		/// <summary>
		/// Reads localization file content into key/value dictionary.
		/// </summary>
		/// <param name="filename">Name of file to read.</param>
		/// <returns>Localization key/value dictionary.</returns>
		protected abstract StringDictionary ReadFile( string filename );
	}

	/// <summary>
	/// Contracts for BaseFileProvider.
	/// </summary>
	[ContractClassFor( typeof( BaseFileProvider ) )]
	internal abstract class BaseFileProviderContracts : BaseFileProvider
	{
		#region Overrides of BaseFileProvider

		protected override StringDictionary ReadFile( string filename )
		{
			Contract.Requires( !String.IsNullOrEmpty( filename ) );
			return null;
		}

		#endregion
	}
}
