﻿using System;
using System.Windows.Forms;
using RM.Lib.Service.AutoHost.Utility;

namespace RM.Service.Hosting
{
	internal class Logger : ILogger
	{
		private const int _maxTypeLength = 5;
		private const string _error = "ERROR";
		private const string _warn = "WARN";
		private const string _info = "INFO";

		private readonly TextBox _textBox;

		public Logger(TextBox textBox)
		{
			_textBox = textBox;
		}

		#region Implementation of ILogger

		public void Error(string message)
		{
			WriteMessage(_error, message);
		}

		public void Error(string format, params object[] args)
		{
			WriteMessage(_error, format, args);
		}

		public void Warn(string message)
		{
			WriteMessage(_warn, message);
		}

		public void Warn(string format, params object[] args)
		{
			WriteMessage(_warn, format, args);
		}

		public void Info(string message)
		{
			WriteMessage(_info, message);
		}

		public void Info(string format, params object[] args)
		{
			WriteMessage(_info, format, args);
		}

		#endregion

		private void WriteMessage(string type, string message)
		{
			switch (type.Length.CompareTo(_maxTypeLength))
			{
				case -1:
					type += new String('\x20', _maxTypeLength - type.Length);
					break;

				case 1:
					type = type.Substring(0, _maxTypeLength);
					break;

				default:
					break;
			}

			WriteLine(
					String.Format("[{0}] {1:yyyy-MM-dd hh:mm:ss.fff} {2}", type, DateTime.Now, message)
				);
		}

		private void WriteMessage(string type, string format, params object[] args)
		{
			WriteMessage(type, String.Format(format, args));
		}

		private void WriteLine(string str)
		{
			_textBox.Text += (str ?? String.Empty) + Environment.NewLine;
		}
	}
}
