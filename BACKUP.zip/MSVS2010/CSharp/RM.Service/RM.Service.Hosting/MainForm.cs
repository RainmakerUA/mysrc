﻿using System;
using System.Drawing;
using System.Windows.Forms;
using RM.Lib.Service.AutoHost;

namespace RM.Service.Hosting
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);

			ServiceManager.Instance.Initialize(new Logger(textBoxLog), @".\Services", "localhost:1999/Sample");
		}

		protected override void OnClosed(EventArgs e)
		{
			base.OnClosed(e);
		}

		protected override void OnShown(EventArgs e)
		{
			base.OnShown(e);

			Location = new Point(100, 100);
			//Hide();
		}
	}
}
