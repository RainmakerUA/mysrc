﻿using System;
using RM.Service.Sample.Contracts.DataContracts;

namespace RM.Service.Client
{
	internal static class Program
	{
		private static void Main(string[] args)
		{
			var svc = SampleClient.GetService();

			var res1 = svc.GetData(19);
			var res2 = svc.GetDataUsingDataContract(new CompositeType { BoolValue = true, StringValue = "True" });

			Console.ReadKey(true);
		}
	}
}
