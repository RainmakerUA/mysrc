﻿using System.ServiceModel;
using RM.Service.Sample.Contracts.ServiceContracts;

namespace RM.Service.Client
{
	internal static class SampleClient
	{
		private static ISampleService _channel;

		public static ISampleService GetService()
		{
			if (_channel == null)
			{
				var factory = new ChannelFactory<ISampleService>(
						new NetTcpBinding(),
						"net.tcp://localhost:9000/Sample"
					);
				_channel = factory.CreateChannel();
			}

			return _channel;
		}
	}
}
