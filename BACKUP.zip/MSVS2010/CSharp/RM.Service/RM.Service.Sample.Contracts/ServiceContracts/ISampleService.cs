﻿using System.ServiceModel;
using RM.Service.Sample.Contracts.DataContracts;

namespace RM.Service.Sample.Contracts.ServiceContracts
{
	[ServiceContract]
	public interface ISampleService
	{
		[OperationContract]
		string GetData(int value);

		[OperationContract]
		CompositeType GetDataUsingDataContract(CompositeType composite);

		// TODO: Add your service operations here
	}
}