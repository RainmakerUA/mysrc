﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Configuration;
using RM.Lib.Service.AutoHost.Utility;

namespace RM.Lib.Service.AutoHost
{
	internal class ServiceDomainHelper : MarshalByRefObject
	{
		private const char _COMMA = ',';
		private const string _DLL = ".dll";
		private static bool _existsInDomain;

		private AssemblyManager _asmManager;
		private Assembly _serviceAssembly;
		private ServiceModelSectionGroup _config;
		private ServiceHost[] _hosts;

		public ServiceDomainHelper()
		{
			if ( _existsInDomain )
			{
				throw new InvalidOperationException( "Only one ServiceDomainHelper allowed per AppDomain!" );
			}

			_existsInDomain = true;
		}

		public static string Str
		{
			get { return String.Empty; }
		}

		public void LoadServiceAssembly( AssemblyManager asmManager , string asmName )
		{
			if ( _serviceAssembly != null )
			{
				throw new InvalidOperationException( "Assembly is already loaded!" );
			}

			if ( asmManager == null )
			{
				throw new ArgumentNullException( "asmManager" );
			}

			_asmManager = asmManager;
			AppDomain.CurrentDomain.AssemblyResolve += OnAssemblyResolve;

			_serviceAssembly = LoadAssembly( _asmManager , asmName );

			foreach ( var type in _serviceAssembly.GetTypes() )
			{
				var ii = type.GetInterfaces();
			}
			//_config = LoadConfiguration( cfgPath );
			//_hosts = GetServiceConfigs( _config ).Select( element => CreateHost( _serviceAssembly , _config , element ) ).ToArray();
		}

		private Assembly OnAssemblyResolve( object sender , ResolveEventArgs e )
		{
			return LoadAssembly( _asmManager , e.Name );
		}

		private static Assembly LoadAssembly( AssemblyManager manager , string name )
		{
			var bytes = manager.GetAssemblyBytes( name );
			return bytes != null ? Assembly.Load( bytes ) : null;
		}

		private static ServiceModelSectionGroup LoadConfiguration( string cfgFileName )
		{
			if ( File.Exists( cfgFileName ) )
			{
				var map = new ExeConfigurationFileMap { ExeConfigFilename = cfgFileName };
				var config = ConfigurationManager.OpenMappedExeConfiguration( map , ConfigurationUserLevel.None );
				return ServiceModelSectionGroup.GetSectionGroup( config );
			}

			return null;
		}

		private static IEnumerable<ServiceElement> GetServiceConfigs( ServiceModelSectionGroup config )
		{
			if ( config != null )
			{
				var services = config.Services;
				if ( services != null && services.Services.Count > 0 )
				{
					var elements = new ServiceElement[ services.Services.Count ];
					services.Services.CopyTo( elements , 0 );

					return elements;
				}
			}

			return new ServiceElement[ 0 ];
		}

		private static ServiceHost CreateHost( Assembly assembly , ServiceModelSectionGroup config , ServiceElement element )
		{
			var type = assembly.GetType( element.Name );
			var host = new ServiceHost( type ,
										element.Host.BaseAddresses.Cast<BaseAddressElement>().Select(
											el => new Uri( el.BaseAddress )
											).ToArray()
									);
			foreach ( ServiceEndpointElement endpoint in element.Endpoints )
			{
				host.AddServiceEndpoint(
						endpoint.Contract ,
						BindingHelper.GetBinding( config.Bindings , endpoint.Binding ) ,
						endpoint.Address
					);
			}

			return host;
		}
	}
}
