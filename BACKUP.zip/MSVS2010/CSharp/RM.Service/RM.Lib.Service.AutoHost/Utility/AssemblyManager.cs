﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security;
using System.Text;

namespace RM.Lib.Service.AutoHost.Utility
{
	internal class AssemblyManager : MarshalByRefObject
	{
		#region Singleton

		private static class InstanceHolder
		{
			internal static readonly AssemblyManager ManagerInstance = new AssemblyManager();

			static InstanceHolder()
			{
			}
		}

		static AssemblyManager()
		{
		}

		private AssemblyManager()
		{
		}

		public static AssemblyManager Instance
		{
			get { return InstanceHolder.ManagerInstance; }
		}

		#endregion

		private const string _PATTERN = "*.dll";
		private const string _CONFIG = ".config";

		private readonly Dictionary<string , byte[]> _assemblies = new Dictionary<string , byte[]>();
		private readonly Dictionary<string , string> _asmFiles = new Dictionary<string , string>();

		public IEnumerable<string> AssemblyNames
		{
			get { return _assemblies.Keys; }
		}

		public void Initialize( string path )
		{
			foreach ( var assembly in GetAssemblies( path ) )
			{
				byte[] asmBytes = null;
				string name = null;

				try
				{
					asmBytes = File.ReadAllBytes( assembly );
					var asm = Assembly.ReflectionOnlyLoad( asmBytes );
					name = asm.FullName;
				}
				catch ( BadImageFormatException )
				{
				}
				catch ( IOException )
				{
				}
				catch ( SecurityException )
				{
				}

				if ( asmBytes != null && name != null )
				{
					_assemblies.Add( name , asmBytes );
					_asmFiles.Add( name , assembly );
				}
			}
		}

		public byte[] GetAssemblyBytes( string name )
		{
			return _assemblies.ContainsKey( name ) ? _assemblies[ name ] : null;
		}

		public string GetAssemblyPath( string name )
		{
			return _asmFiles.ContainsKey( name ) ? _asmFiles[ name ] : null;
		}

		public string GetAssemblyConfigPath( string name )
		{
			var configName = GetAssemblyPath( name ) + _CONFIG;
			return File.Exists( configName ) ? configName : null;
		}

		private static IEnumerable<string> GetAssemblies( string path )
		{
			var asms = new List<string>();

			if ( !Path.IsPathRooted( path ) )
			{
				path = Path.GetFullPath( path );
			}

			if ( Directory.Exists( path ) )
			{
				foreach ( var directory in Directory.GetDirectories( path ) )
				{
					asms.AddRange( GetAssemblies( directory ) );
				}

				asms.AddRange( Directory.GetFiles( path , _PATTERN ) );
			}

			return asms;
		}
	}
}
