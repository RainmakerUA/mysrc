﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Channels;
using System.ServiceModel.Configuration;
using System.Text;

namespace RM.Lib.Service.AutoHost.Utility
{
	internal static class BindingHelper
	{
		public static Binding GetBinding( BindingsSection section , string name )
		{
			Binding binding;

			switch ( name )
			{
				default:
					binding = null;
					break;
			}

			return binding;
		}
	}
}
