﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RM.Lib.Service.AutoHost.Utility
{
	public interface ILogger
	{
		void Error(string message);
		void Error(string format, params object[] args);

		void Warn(string message);
		void Warn(string format, params object[] args);

		void Info(string message);
		void Info(string format, params object[] args);
	}
}
