﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace RM.Lib.Service.AutoHost.Utility
{
	internal static class LogMgr
	{
		public static ILogger Logger { get; set; }

		public static void Error(string message)
		{
			if (Logger != null) Logger.Error(message);
		}

		public static void Error(string format, params object[] args)
		{
			if (Logger != null) Logger.Error(format, args);
		}

		public static void Warn(string message)
		{
			if (Logger != null) Logger.Warn(message);
		}

		public static void Warn(string format, params object[] args)
		{
			if (Logger != null) Logger.Warn(format, args);
		}

		[Conditional("DEBUG")]
		public static void Info(string message)
		{
			if (Logger != null) Logger.Info(message);
		}

		[Conditional("DEBUG")]
		public static void Info(string format, params object[] args)
		{
			if (Logger != null) Logger.Info(format, args);
		}
	}
}
