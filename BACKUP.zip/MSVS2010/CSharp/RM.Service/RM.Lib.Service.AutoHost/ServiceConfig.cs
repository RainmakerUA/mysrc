﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Channels;
using System.Text;

namespace RM.Lib.Service.AutoHost
{
	internal class ServiceConfig
	{
		private ServiceConfig(Type contract, Type implementation, Binding binding, string remoteAddress)
		{
			Contract = contract;
			Implementation = implementation;
			Binding = binding;
			RemoteAddress = remoteAddress;
		}

		public Type Contract { get; private set; }
		public Type Implementation { get; private set; }
		public Binding Binding { get; private set; }
		public string RemoteAddress { get; private set; }

		internal static IEnumerable<ServiceConfig> LoadServices(string path)
		{
			yield break;
		}
	}
}
