﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Configuration;
using RM.Lib.Service.AutoHost.Utility;

namespace RM.Lib.Service.AutoHost
{
	public class ServiceManager
	{
		#region Singleton

		private static class InstanceHolder
		{
			internal static readonly ServiceManager ManagerInstance = new ServiceManager();

			static InstanceHolder()
			{
			}
		}

		static ServiceManager()
		{
		}

		private ServiceManager()
		{
		}

		public static ServiceManager Instance
		{
			get { return InstanceHolder.ManagerInstance; }
		}

		#endregion

		private bool _isInitialized;
		private readonly Dictionary<string , ServiceController> _controllers = new Dictionary<string , ServiceController>();

		public void Initialize( ILogger logger , string path , string baseAddress )
		{
			LogMgr.Logger = logger;
			LogMgr.Info( "ServiceManager: Start initialization" );


			_controllers.Clear();

			try
			{
				var asmMgr = AssemblyManager.Instance;
				asmMgr.Initialize( path );
				//LogMgr.Info( "{0} assemblies found" , asmMgr.AssemblyNames.Count() );

				foreach ( var asm in asmMgr.AssemblyNames )
				{
					var ctrl = ServiceController.GetController( asm );
					if ( ctrl != null )
					{
						LogMgr.Info( "Loaded assembly: {0} - '{1}'" , asm , asmMgr.GetAssemblyPath( asm ) );
						_controllers.Add( asm , ctrl );
					}
				}
			}
			catch ( Exception e )
			{
				LogMgr.Error( "Exception ({0}): {1}" , e.GetType() , e.Message );
			}

			_isInitialized = true;
			LogMgr.Info( "ServiceManager: Finish initialization" );
		}

		private void CheckInitialized()
		{
			if ( !_isInitialized )
			{
				throw new InvalidOperationException( "ServiceManager is not initialized!" );
			}
		}
	}
}
