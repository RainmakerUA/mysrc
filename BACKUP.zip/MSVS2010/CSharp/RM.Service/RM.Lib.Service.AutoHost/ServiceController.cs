using System;
using System.IO;
using System.Reflection;
using RM.Lib.Service.AutoHost.Utility;

namespace RM.Lib.Service.AutoHost
{
	internal class ServiceController
	{
		private readonly AppDomain _serviceDomain;
		private readonly ServiceDomainHelper _proxy;

		private ServiceController( string asmName )
		{
			string appBase = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;

			_serviceDomain = CreateAppDomain( appBase , asmName );
			_proxy = LoadServiceAssembly( _serviceDomain , asmName );
		}

		public static ServiceController GetController( string serviceAssembly )
		{

			return AssemblyManager.Instance.GetAssemblyConfigPath( serviceAssembly ) == null
					? null : new ServiceController( serviceAssembly );
		}

		private static AppDomain CreateAppDomain( string appBase , string asmName )
		{
			var setup = new AppDomainSetup
							{
								ApplicationBase = appBase
							};

			var domain = AppDomain.CreateDomain( asmName , AppDomain.CurrentDomain.Evidence , setup );
			//domain.AssemblyResolve += AssemblyManager.Instance.OnResolveAssembly;

			return domain;
		}

		private static ServiceDomainHelper LoadServiceAssembly( AppDomain domain , string asmName )
		{
			var helper = ( ServiceDomainHelper ) domain.CreateInstanceAndUnwrap(
					Assembly.GetExecutingAssembly().FullName , typeof( ServiceDomainHelper ).FullName
				);

			helper.LoadServiceAssembly( AssemblyManager.Instance , asmName );

			return helper;
		}
	}
}

/*

/// <summary>
		/// Gets assembly names list from Suite bin directory.
		/// </summary>
		/// <returns>Assembly names array.</returns>
		private string[] GetAssemblies()
		{
			string[] files = Directory.GetFiles(PathHelper.BinFolder, "*.dll");
			string[] assemblies = new string[files.Length];

			for (int i = 0; i < files.Length; i++)
			{
				assemblies[i] = Path.GetFileNameWithoutExtension(files[i]);
			}

			return assemblies;
		}

		/// <summary>
		/// Gets provided assembly type names, that match conditions definrd by predicate.
		/// </summary>
		/// <param name="asmName">Assembly name to get types from.</param>
		/// <param name="filter">Predicate delegate, specifying conditions to filter types.</param>
		/// <returns>Array of type names from assembly.</returns>
		private string[] GetAssemblyTypes(string asmName, Predicate<Type> filter)
		{
			List<string> typeNames = new List<string>();
			if (!string.IsNullOrEmpty(asmName))
			{
				string asmFile = Path.Combine(PathHelper.BinFolder, asmName);
				if (!asmFile.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
					asmFile = asmFile + ".dll";
				Assembly asm = Assembly.LoadFrom(asmFile);

				typeNames.AddRange(
						Array.ConvertAll(Array.FindAll(asm.GetExportedTypes(), filter),
						new Converter<Type, string>(delegate(Type t) { return t.FullName; }))
					);

				typeNames.Sort();
			}

			return typeNames.ToArray();
		}

		/// <summary>
		/// Fills dropdown list items with assembly names.
		/// </summary>
		/// <param name="list">DropDownList control to be filled.</param>
		private void FillAssemblyList(DropDownList list)
		{
			if (_assemblies == null || _assemblies.Length == 0)
			{
				_assemblies = GetAssemblies();
			}

			list.Items.Clear();
			list.Items.Add(string.Empty);

			foreach (string asm in _assemblies)
			{
				list.Items.Add(asm);
			}
		}

		/// <summary>
		/// Fills contract type list with appropriate types from selected contract assembly.
		/// </summary>
		private void FillContractTypeList()
		{
			string[] types = GetAssemblyTypes(
					listContractAssembly.SelectedValue,
					new Predicate<Type>(delegate(Type t)
					{
						return t.IsInterface && t.GetCustomAttributes(typeof(ServiceContractAttribute), false).Length > 0;
					})
				);

			listContractType.Items.Clear();
			listContractType.Items.Add(string.Empty);

			foreach (string type in types)
			{
				listContractType.Items.Add(type);
			}
		}

		/// <summary>
		/// Fills contract type list with appropriate types from selected implementation assembly.
		/// </summary>
		private void FillImplementationTypeList()
		{
			string[] types = GetAssemblyTypes(
					listImplementationAssembly.SelectedValue,
					new Predicate<Type>(delegate(Type t)
					{
						return Array.FindIndex(t.GetInterfaces(),
								new Predicate<Type>(delegate(Type type)
								{
									return type.FullName == listContractType.SelectedValue;
								})
							) > -1;
					})
				);

			listImplementationType.Items.Clear();
			listImplementationType.Items.Add(string.Empty);

			foreach (string type in types)
			{
				listImplementationType.Items.Add(type);
			}
		}

*/