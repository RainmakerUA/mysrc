﻿using System;
using RM.Service.Sample.Contracts.ServiceContracts;

namespace RM.Service.Sample
{
	public class TestService : ITestService
	{
		public bool IsTestAvailable()
		{
			return true;
		}

		public Guid GetGuid()
		{
			return Guid.NewGuid();
		}
	}
}
