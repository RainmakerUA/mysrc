﻿using System.IO;
using Testing.Lib.Common.ObjectModel;
using Testing.Lib.Common.XmlZ;
using TestClass = Testing.Lib.Common.ObjectModel.Test;

namespace Testing.Test
{
	internal static class TestGen
	{
		private const string _AUTHOR = "Варнавська В. О.";

		private static byte[] F( string fname )
		{
			return File.ReadAllBytes( fname );
		}

		public static void GenAlco1()
		{
			var groups = new[]
						{
							new TestItemGroup("Оберіть одну правильну відповідь", 3),
							new TestItemGroup("Оберіть дві правильні відповіді", 4),
							new TestItemGroup("Вкажіть правильну відповідь", 6),
							new TestItemGroup("Високий рівень", 6)
						};

			var test = new TestClass(
					"Спирти і феноли. Варіант I" , _AUTHOR , 72 , F( "Alco.png" ) ,
					groups ,
					new TestItem(
							"Вкажіть загальну формулу насичених одноатомних спиртів" , F( "1.png" ) , groups[ 0 ] ,
							new TestItemOption( "а)" ) ,
							new TestItemOption( "б)" ) ,
							new TestItemOption( "в)" , true ) ,
							new TestItemOption( "г)" )
						) ,
					new TestItem(
							"Вкажіть формули ізомерів" , F( "2.png" ) , groups[ 0 ] ,
							new TestItemOption( "а, б" ) ,
							new TestItemOption( "б, в" ) ,
							new TestItemOption( "а, в" , true )
						) ,
					new TestItem(
							"Назвіть речовину, формулу якої зображено на рисунку" , F( "3.png" ) , groups[ 0 ] ,
							new TestItemOption( "2,2-диметилбутанол-3" ) ,
							new TestItemOption( "3,3-диметилбутанол-2" , true ) ,
							new TestItemOption( "2-метилбутанол-2" )
						) ,
					new TestItem(
							"Назвіть речовину, формулу якої зображено на рисунку" , F( "4.png" ) , groups[ 0 ] ,
							new TestItemOption( "тринітрогліцерин" , true ) ,
							new TestItemOption( "купрум (II) гліцерат" ) ,
							new TestItemOption( "гліцерин" )
						) ,
					new TestItem(
							"Як змінюються температури кипіння одноатомних спиртів із збільшенням їхньої молекулярної маси?" , null , groups[ 0 ] ,
							new TestItemOption( "істотно не змінюються" ) ,
							new TestItemOption( "значно збільшуються" , true ) ,
							new TestItemOption( "значно зменшуються" )
						) ,
					new TestItem(
							"Який із спиртів добре розчиняється у воді?" , null , groups[ 0 ] ,
							new TestItemOption( "етанол" , true ) ,
							new TestItemOption( "пентанол" ) ,
							new TestItemOption( "гексанол" )
						) ,
					new TestItem(
							"Позначте молекулярну формулу та назву гліцерину за міжнародною номенклатурою" , null , groups[ 1 ] ,
							new TestItemOption( "поліпропанол" ) ,
							new TestItemOption( "CH₂OH—CHOH—CH₂OH" , true ) ,
							new TestItemOption( "CH₃—CO—CH₂OH" ) ,
							new TestItemOption( "пропантриол-1,2,3" , true )
						) ,
					new TestItem(
							"Які речовини утворюються при горінні етанолу?" , null , groups[ 1 ] ,
							new TestItemOption( "CO₂" , true ) ,
							new TestItemOption( "H₂O" , true ) ,
							new TestItemOption( "CO" ) ,
							new TestItemOption( "H₂" )
						) ,
					new TestItem(
							"Назвіть способи добування етилового спирту у промисловості" , null , groups[ 1 ] ,
							new TestItemOption( "крекінг нафтопродуктів" ) ,
							new TestItemOption( "бродіння глюкози" , true ) ,
							new TestItemOption( "гідратація етилену" , true ) ,
							new TestItemOption( "коксування вугілля" )
						) ,
					new TestItem(
							"Назвіть галузі використання фенолу" , null , groups[ 1 ] ,
							new TestItemOption( "добування феноло-формальдегідних смол" , true ) ,
							new TestItemOption( "добування антифризів" ) ,
							new TestItemOption( "добування барвників" , true ) ,
							new TestItemOption( "добування нітрогліцерину" )
						) ,
					new TestItem(
							"З якими речовинами буде реагувати фенол?" , null , groups[ 1 ] ,
							new TestItemOption( "металічний натрій" , true ) ,
							new TestItemOption( "бром" , true ) ,
							new TestItemOption( "натрій хлорид" ) ,
							new TestItemOption( "етанол" )
						) ,
					new TestItem(
							"Які речовини необхідно взяти для проведення якісної реакції на багатоатомні спирти?" , null , groups[ 1 ] ,
							new TestItemOption( "натрій хлорид" ) ,
							new TestItemOption( "натрій гідрооксид" , true ) ,
							new TestItemOption( "мідний купорос" , true ) ,
							new TestItemOption( "оцтова кислота" )
						) ,
					new TestItem(
							"Визначте речовини A і D у реакції:\n"
							+ "2C₂H₅OH + 2A → 2C₂H₅ONa + D" , null , groups[ 2 ] ,
							new TestItemOption( "A — Cl₂, D — HCl" ) ,
							new TestItemOption( "A — Na, D — H₂" , true ) ,
							new TestItemOption( "A — NaOH, D — H₂O" )
						) ,
					new TestItem(
							"Визначити масу 0,4 моль етанолу" , null , groups[ 2 ] ,
							new TestItemOption( "23 г" ) ,
							new TestItemOption( "9,2 г" ) ,
							new TestItemOption( "18,4 г" , true )
						) ,
					new TestItem(
							"Який об'єм водню (н.у.) виділиться, якщо 138 г етанолу вступає в реакцію з металічним натрієм?" , null , groups[ 2 ] ,
							new TestItemOption( "33,6 л" , true ) ,
							new TestItemOption( "36,6 л" ) ,
							new TestItemOption( "3,36 л" )
						) ,
					new TestItem(
							"Вкажіть суму всіх коефіцієнтів у рівнянні реакції горіння пропанолу" , null , groups[ 3 ] ,
							new TestItemOption( "15" ) ,
							new TestItemOption( "25" , true ) ,
							new TestItemOption( "18" )
						) ,
					new TestItem(
							"При взаємодії 18,8 г фенолу 3 надлишком бромної води утворилося 50 г осаду. "
							+ "Обчисліть вихід продукту реакції ( у % ) від теоретично можливого" , null , groups[ 3 ] ,
							new TestItemOption( "45%" ) ,
							new TestItemOption( "85,5%" ) ,
							new TestItemOption( "75,5%" , true )
						)
				);

			test.Serialize( "alco1.test" );
		}

		public static void GenAlco2()
		{
			var groups = new[]
						{
							new TestItemGroup("Оберіть одну правильну відповідь", 3),
							new TestItemGroup("Оберіть дві правильні відповіді", 4),
							new TestItemGroup("Вкажіть правильну відповідь", 6),
							new TestItemGroup("Високий рівень", 6)
						};

			var test = new TestClass(
					"Спирти і феноли. Варіант II" , _AUTHOR , 72 , F( "Alco.png" ) ,
					groups ,
					new TestItem( // 1
							"Вкажіть формулу гліцерину" , F( "1.png" ) , groups[ 0 ] ,
							new TestItemOption( "а)" ) ,
							new TestItemOption( "б)" , true ) ,
							new TestItemOption( "в)" ) ,
							new TestItemOption( "г)" )
						) ,
					new TestItem( // 2
							"Вкажіть формули ізомерів" , F( "2.png" ) , groups[ 0 ] ,
							new TestItemOption( "а, б" , true ) ,
							new TestItemOption( "б, в" ) ,
							new TestItemOption( "а, в" )
						) ,
					new TestItem( // 3
							"Назвіть речовину, формулу якої зображено на рисунку" , F( "3.png" ) , groups[ 0 ] ,
							new TestItemOption( "3-метилпентанол-2" , true ) ,
							new TestItemOption( "3-метилпентанол-4" ) ,
							new TestItemOption( "пентанол-2" )
						) ,
					new TestItem( // 4
							"Назвіть речовину, формула якої CH₃—CH₂—ONa" , null , groups[ 0 ] ,
							new TestItemOption( "нітрогліцерин" ) ,
							new TestItemOption( "натрій етилат" , true ) ,
							new TestItemOption( "натрій ацетат" )
						) ,
					new TestItem( // 5
							"Як змінюється розчинніть спиртів у воді із збільшенням їхньої молекулярної маси?" , null , groups[ 0 ] ,
							new TestItemOption( "істотно не змінюється" ) ,
							new TestItemOption( "значно збільшується" ) ,
							new TestItemOption( "значно зменшується" , true )
						) ,
					new TestItem( // 6
							"При взаємодії гліцерину з купрум (II) гідрооксидом утворюється" , null , groups[ 0 ] ,
							new TestItemOption( "яскраво-синій розчин" , true ) ,
							new TestItemOption( "червоний осад" ) ,
							new TestItemOption( "фіолетовий розчин" )
						) ,
					new TestItem( // 7
							"Позначити молекулярну формулу та назву етиленгликолю за міжнародної номенклатурою" , null , groups[ 1 ] ,
							new TestItemOption( "CH₃—CHOH—CH₂OH" ) ,
							new TestItemOption( "CH₂OH—CH₂OH" , true ) ,
							new TestItemOption( "етандіол" , true ) ,
							new TestItemOption( "етанол" )
						) ,
					new TestItem( // 8
							"Які речовини утворюються при взаємодії фенолу з гідрооксидом натрію?" , null , groups[ 1 ] ,
							new TestItemOption( "фенолят натрію" , true ) ,
							new TestItemOption( "етилат натрію" ) ,
							new TestItemOption( "водень" ) ,
							new TestItemOption( "вода" , true )
						) ,
					new TestItem( // 9
							"Назвіть галузі використання етанолу" , null , groups[ 1 ] ,
							new TestItemOption( "медицина" , true ) ,
							new TestItemOption( "добування синтетичних каучуків" , true ) ,
							new TestItemOption( "добування фенолоформальдегідних смол" ) ,
							new TestItemOption( "добування нітрогліцерину" )
						) ,
					new TestItem( // 10
							"Які хімічні реакції характерні для етилового спирту і гліцерину?" , null , groups[ 1 ] ,
							new TestItemOption( "взаємодія з металічним натрієм" , true ) ,
							new TestItemOption( "взаємодія з купрум (II) гідрооксидом" ) ,
							new TestItemOption( "взаємодія з хлороводнем" , true ) ,
							new TestItemOption( "взаємодія з бромом" )
						) ,
					new TestItem( // 11
							"З якими речовинами буде реагувати гліцерин?" , null , groups[ 1 ] ,
							new TestItemOption( "купрум (II) гідрооксид" , true ) ,
							new TestItemOption( "натрій гідрооксид" ) ,
							new TestItemOption( "купрум (II) оксид" ) ,
							new TestItemOption( "нітратна кислота" , true )
						) ,
					new TestItem(
							"Вкажіть формули гомологів етанолу" , null , groups[ 1 ] ,
							new TestItemOption( "CH₃OH" , true ) ,
							new TestItemOption( "C₆H₅OH" ) ,
							new TestItemOption( "CH₃—CH₂—CH₂—CH₂—OH" , true ) ,
							new TestItemOption( "CH₂OH—CH₂OH" )
						) ,
					new TestItem(
							"Визначте речовини A і D у реакції:\n"
							+ "C₂H₅OH + 3A → 2D + 3H₂O" , null , groups[ 2 ] ,
							new TestItemOption( "A - Na, D - C₂H₅ONa" ) ,
							new TestItemOption( "A - HCl, D - C₂H₅Cl" ) ,
							new TestItemOption( "A - O₂, D - CO₂" , true )
						) ,
					new TestItem(
							"Визначити масу 0,2 моль фенолу" , null , groups[ 2 ] ,
							new TestItemOption( "188 г" ) ,
							new TestItemOption( "18,8 г" , true ) ,
							new TestItemOption( "9,4 г" )
						) ,
					new TestItem(
							"Обчислити масу етанолу, який вступає в реакцію з металічним натрієм, "
							+ "якщо при цьюму виділяється 67,2 л водню (н.у.)" , null , groups[ 2 ] ,
							new TestItemOption( "138 г" ) ,
							new TestItemOption( "276 г" , true ) ,
							new TestItemOption( "27,6 г" )
						) ,
					new TestItem(
							"Вкажіть суму всіх коефіцієнтів у рівнянні реакції горіння бутанолу" , null , groups[ 3 ] ,
							new TestItemOption( "18" ) ,
							new TestItemOption( "12" ) ,
							new TestItemOption( "16" , true )
						) ,
					new TestItem(
							"Обчисліть, який об'єм водню (н.у.) виділиться під час "
							+ "взаємодії 2,3 г натрію з 34 г фенолу" , null , groups[ 3 ] ,
							new TestItemOption( "11,2 л" ) ,
							new TestItemOption( "1,12 л" ) ,
							new TestItemOption( "2,24 л" , true )
						)
				);

			test.Serialize( "alco2.test" );
		}

		public static void GenEther1()
		{
			var groups = new[]
						{
							new TestItemGroup("Оберіть одну правильну відповідь", 3),
							new TestItemGroup("Оберіть дві правильні відповіді", 4),
							new TestItemGroup("Вкажіть правильну відповідь", 6),
							new TestItemGroup("Високий рівень", 6)
						};

			var test = new TestClass(
					"Альдегіди. Карбонові кислоти. Естери. Жири. Варіант I" , _AUTHOR , 72 , F( "Ether.png" ) ,
					groups ,
					new TestItem( // 1
							"Вкажіть загальну формулу складних ефірів (естерів)" , F( "1.png" ) , groups[ 0 ] ,
							new TestItemOption( "а)" ) ,
							new TestItemOption( "б)" ) ,
							new TestItemOption( "в)" , true ) ,
							new TestItemOption( "г)" )
						) ,
					new TestItem( // 2
							"Назві 2,3-диметилбутанова кислота відповідає формула" , F( "2.png" ) , groups[ 0 ] ,
							new TestItemOption( "а)" ) ,
							new TestItemOption( "б)" ) ,
							new TestItemOption( "в)" , true )
						) ,
					new TestItem( // 3
							"Який з наведених альдегідів за звичайних умов є газом?" , null , groups[ 0 ] ,
							new TestItemOption( "мурашиний" , true ) ,
							new TestItemOption( "оцтовий" ) ,
							new TestItemOption( "пропіоновий" ) ,
							new TestItemOption( "масляний" )
						) ,
					new TestItem( // 4
							"Назвіть формулу стеаринової кислоти" , null , groups[ 0 ] ,
							new TestItemOption( "C₁₅H₃₁COOH" ) ,
							new TestItemOption( "C₁₇H₃₃COOH" ) ,
							new TestItemOption( "C₁₇H₃₅COOH" , true ) ,
							new TestItemOption( "C₁₇H₃₁COOH" )
						) ,
					new TestItem( // 5
							"Як змінюється ступінь дисоціації карбонових кислот із збільшенням їхньої молекулярної маси?" , null , groups[ 0 ] ,
							new TestItemOption( "збільшується" ) ,
							new TestItemOption( "істотно не змінюється" ) ,
							new TestItemOption( "зменшується" , true )
						) ,
					new TestItem( // 6
							"Чому не можна стверджувати, що мурашина кислота є амфотерною сполукою?" , null , groups[ 0 ] ,
							new TestItemOption( "має функціональну карбоксильну групу" ) ,
							new TestItemOption( "реагує з основами, але не реагує з кислотами" , true ) ,
							new TestItemOption( "проявляє властивості як кислоти, так і альдегіду" ) ,
							new TestItemOption( "у молекулі замість радикалу — атом Гідрогену" )
						) ,
					new TestItem( // 7
							"Вкажіть формули гомологів оцтового альдегіду" , F( "7.png" ) , groups[ 1 ] ,
							new TestItemOption( "а)" ) ,
							new TestItemOption( "б)" , true ) ,
							new TestItemOption( "в)" ) ,
							new TestItemOption( "г)" , true ) ,
							new TestItemOption( "д)" )
						) ,
					new TestItem( // 8
							"Вкажіть формули ізомерів бутанової кислоти" , F( "8.png" ) , groups[ 1 ] ,
							new TestItemOption( "а)" ) ,
							new TestItemOption( "б)" , true ) ,
							new TestItemOption( "в)" , true ) ,
							new TestItemOption( "г)" )
						) ,
					new TestItem( // 9
							"З якими з вказаних речовин буде взаємодіяти оцтовий альдегід?" , null , groups[ 1 ] ,
							new TestItemOption( "з воднем" , true ) ,
							new TestItemOption( "з натрієм гідрооксидом" ) ,
							new TestItemOption( "з метаном" ) ,
							new TestItemOption( "з амоніачним розчином аргентум (I) оксиду" , true )
						) ,
					new TestItem( // 10
							"Вкажіть формули складних ефірів" , null , groups[ 1 ] ,
							new TestItemOption( "HCOOC₃H₇" , true ) ,
							new TestItemOption( "(CH₃CH₂COO)₂Ca" ) ,
							new TestItemOption( "CH₃—CH₂—CH₂—COOCH₃" , true ) ,
							new TestItemOption( "C₁₅H₃₁COONa" )
						) ,
					new TestItem( // 11
							"Позначте речовини, завдяки яким можна відрізнити мурашину кислоту від оцтової" , null , groups[ 1 ] ,
							new TestItemOption( "калій карбонат" ) ,
							new TestItemOption( "Купрум (II) гідрооксид" , true ) ,
							new TestItemOption( "амоніачний розчин аргентум (I) оксиду" , true ) ,
							new TestItemOption( "натрій гідрооксид" )
						) ,
					new TestItem(
							"До складу жирів можуть входити залишки карбонових кислот" , null , groups[ 1 ] ,
							new TestItemOption( "CH₃COOH" ) ,
							new TestItemOption( "C₁₇H₃₅COOH" , true ) ,
							new TestItemOption( "C₁₇H₃₁COOH" , true ) ,
							new TestItemOption( "C₂H₅COOH" )
						) ,
					new TestItem(
							"Закінчити рівняння реакції, вказати суму всіх коефіцієнтів у цьому рівнянні"
							+ "\nCH₃COOH + Ba(OH)₂ →" , null , groups[ 2 ] ,
							new TestItemOption( "4" ) ,
							new TestItemOption( "6" , true ) ,
							new TestItemOption( "5" )
						) ,
					new TestItem(
							"Визначити масу 0,3 моль метаналю" , null , groups[ 2 ] ,
							new TestItemOption( "9 г" , true ) ,
							new TestItemOption( "18 г" ) ,
							new TestItemOption( "12 г" )
						) ,
					new TestItem(
							"Який об'єм водню (н.у.) можна добути, якщо подіяти оцтовою кислотою"
							+ " на 1,2 г магнію?" , null , groups[ 2 ] ,
							new TestItemOption( "2,24 л" ) ,
							new TestItemOption( "11,2 л" ) ,
							new TestItemOption( "1,12 л" , true )
						) ,
					new TestItem(
							"Вкажіть кількість складних ефірів (естерів) — ізомерів бутанової кислоти" , null , groups[ 3 ] ,
							new TestItemOption( "2" ) ,
							new TestItemOption( "3" , true ) ,
							new TestItemOption( "4" )
						) ,
					new TestItem(
							"Внаслідок взаємодії надлишку оцтової кислоти з 60 г вапняку,"
							+ " масова частка домішок в якому — 10%, утворився вуглекислий газ."
							+ " Обчисліть його об'єм (н.у.), якщо вихід від теоретично можливого — 75%" , null , groups[ 3 ] ,
							new TestItemOption( "9,072 л" , true ) ,
							new TestItemOption( "18,14 л" ) ,
							new TestItemOption( "12,1 л" )
						)
				);

			test.Serialize( "ether1.test" );
		}

		public static void GenEther2()
		{
			var groups = new[]
						{
							new TestItemGroup("Оберіть одну правильну відповідь", 3),
							new TestItemGroup("Оберіть дві правильні відповіді", 4),
							new TestItemGroup("Вкажіть правильну відповідь", 6),
							new TestItemGroup("Високий рівень", 6)
						};

			var test = new TestClass(
					"Альдегіди. Карбонові кислоти. Естери. Жири. Варіант II" , _AUTHOR , 72 , F( "Ether.png" ) ,
					groups ,
					new TestItem( // 1
							"Жири належать до" , null , groups[ 0 ] ,
							new TestItemOption( "альдегідів" ) ,
							new TestItemOption( "етерів" ) ,
							new TestItemOption( "естерів" , true ) ,
							new TestItemOption( "солей" )
						) ,
					new TestItem( // 2
							"Назвіть речовину, формулу якої зображено на малюнку" , F( "2.png" ) , groups[ 0 ] ,
							new TestItemOption( "3-метил-3-пропілбутаналь" ) ,
							new TestItemOption( "3,3-диметилгексаналь" , true ) ,
							new TestItemOption( "4,4-диметилгексаналь" )
						) ,
					new TestItem( // 3
							"Вкажіть функціональну групу карбонових кислот" , F( "3.png" ) , groups[ 0 ] ,
							new TestItemOption( "а)" ) ,
							new TestItemOption( "б)" ) ,
							new TestItemOption( "в)" , true ) ,
							new TestItemOption( "г)" )
						) ,
					new TestItem( // 4
							"Назвіть формулу олеїнової кислоти" , null , groups[ 0 ] ,
							new TestItemOption( "C₁₅H₃₁COOH" ) ,
							new TestItemOption( "C₁₇H₃₃COOH" , true ) ,
							new TestItemOption( "C₁₇H₃₅COOH" ) ,
							new TestItemOption( "C₁₇H₃₁COOH" )
						) ,
					new TestItem( // 5
							"Як змінюється розчинність альдегідів із збільшенням їхньої молекулярної маси?" , null , groups[ 0 ] ,
							new TestItemOption( "істотно не змінюється" ) ,
							new TestItemOption( "значно зростає" ) ,
							new TestItemOption( "зменшується" , true )
						) ,
					new TestItem( // 6
							"Високу температуру кипіння карбонових кислот у порівнянні з алканами,"
							+ " що мають близьку до них молекулярну масу, можна пояснити" , null , groups[ 0 ] ,
							new TestItemOption( "різної просторовою будовою молекул" ) ,
							new TestItemOption( "утворенням водневого зв'язку" , true ) ,
							new TestItemOption( "наявністю атомів Оксигену" ) ,
							new TestItemOption( "різним впіввідношенням атомів Гідрогену і Карбону" )
						) ,
					new TestItem( // 7
							"Вкажіть формули гомологів оцтової кислоти" , null , groups[ 1 ] ,
							new TestItemOption( "HCOOH" , true ) ,
							new TestItemOption( "CH₃—COOCH₃" ) ,
							new TestItemOption( "CH₃—CH₂—CH₂—CH₂—COOH" , true ) ,
							new TestItemOption( "CH₃COH" ) ,
							new TestItemOption( "CH₃COONa" )
						) ,
					new TestItem( // 8
							"Вкажіть формули ізомерів пентаналю" , F( "8.png" ) , groups[ 1 ] ,
							new TestItemOption( "а)" , true ) ,
							new TestItemOption( "б)" ) ,
							new TestItemOption( "в)" , true ) ,
							new TestItemOption( "г)" )
						) ,
					new TestItem( // 9
							"Чим відрізняється за хімічними властивостями мурашина кислота від її гомологів?" , null , groups[ 1 ] ,
							new TestItemOption( "є електролитом середньої сили" , true ) ,
							new TestItemOption( "вступає в реакцію з амоніачним розчином аргентум (I) оксиду" , true ) ,
							new TestItemOption( "вступає в реакцію естеріфікації" ) ,
							new TestItemOption( "взаємодіє з лугами з утворенням солей" )
						) ,
					new TestItem( // 10
							"З якими із зазначених речовин реагуватиме оцтова кислота?" , null , groups[ 1 ] ,
							new TestItemOption( "метан" ) ,
							new TestItemOption( "етанол" , true ) ,
							new TestItemOption( "гашене вапно" , true ) ,
							new TestItemOption( "срібло" )
						) ,
					new TestItem( // 11
							"Позначте речовини, завдяки яким можна відрізнити оцтовий альдегід від етанолу" , null , groups[ 1 ] ,
							new TestItemOption( "натрій гідрооксид" ) ,
							new TestItemOption( "амоніачний розчин аргентум (I) оксиду" , true ) ,
							new TestItemOption( "фенолфталеїн" ) ,
							new TestItemOption( "Купрум (II) гідрооксид" , true )
						) ,
					new TestItem(
							"До складу жирів можуть входити залишки карбонових кислот" , null , groups[ 1 ] ,
							new TestItemOption( "C₁₅H₃₁COOH" , true ) ,
							new TestItemOption( "HCOOH" ) ,
							new TestItemOption( "CH₃—CH₂—COOH" ) ,
							new TestItemOption( "C₁₇H₃₃COOH" , true )
						) ,
					new TestItem(
							"Закінчити рівняння реакції, вказати суму всіх коефіцієнтів у цьому рівнянні"
							+ "\nHCOOH + K₂CO₃ →" , null , groups[ 2 ] ,
							new TestItemOption( "4" ) ,
							new TestItemOption( "6" ) ,
							new TestItemOption( "7" , true )
						) ,
					new TestItem(
							"Визначити масу 0,01 моль масляної кислоти" , null , groups[ 2 ] ,
							new TestItemOption( "1,76 г" ) ,
							new TestItemOption( "0,88 г" , true ) ,
							new TestItemOption( "8,8 г" )
						) ,
					new TestItem(
							"Яка маса оцтового альдегіду вступає в реакцію з аргентум (I) оксиду,"
							+ " якщо при цьому виділяється 53,9 г аргентуму?" , null , groups[ 2 ] ,
							new TestItemOption( "11 г" , true ) ,
							new TestItemOption( "22 г" ) ,
							new TestItemOption( "1,1 г" )
						) ,
					new TestItem(
							"Вкажіть кількість складних ефірів (естерів) — ізомерів пропанової кислоти" , null , groups[ 3 ] ,
							new TestItemOption( "2" , true ) ,
							new TestItemOption( "3" ) ,
							new TestItemOption( "4" )
						) ,
					new TestItem(
							"У промисловості етаналь добувають за способом Кучерова. Яку масу етаналю можна добути"
							+ " з технічного кальцій карбіду масою 500 кг, масова частка домішок у якому становить 10,4%?"
							+ " Вихід етаналю становить 75% від теоретично можливого" , null , groups[ 3 ] ,
							new TestItemOption( "213 кг" ) ,
							new TestItemOption( "231 кг" , true ) ,
							new TestItemOption( "321 кг" )
						)
				);

			test.Serialize( "ether2.test" );
		}

		public static void GenNonMetals1()
		{
			var groups = new[]
						{
							new TestItemGroup("Оберіть одну правильну відповідь", 3),
							new TestItemGroup("Оберіть дві правильні відповіді", 4),
							new TestItemGroup("Вкажіть правильну відповідь", 6),
							new TestItemGroup("Високий рівень", 6)
						};

			var test = new TestClass(
					"Неметалічні елементи та їхні сполуки. Варіант I" , _AUTHOR , 72 , null ,
					groups , //⁰¹²³⁴⁵⁶⁷⁸⁹⁺‾¯ ₀₁₂₃₄₅₆₇₈₉₊₋
					new TestItem( // 1
							"Вкажіть електронну формулу атома Хлору" , null , groups[ 0 ] ,
							new TestItemOption( "1s²2s²2p⁶3s²3p³" ) ,
							new TestItemOption( "1s²2s²2p⁶3s²3p⁵" , true ) ,
							new TestItemOption( "1s²2s²2p⁵" )
						) ,
					new TestItem( // 2
							"У сполуках із металами Сульфур виявляє ступінь окиснення" , null , groups[ 0 ] ,
							new TestItemOption( "+4" ) ,
							new TestItemOption( "+6" ) ,
							new TestItemOption( "-2" , true ) ,
							new TestItemOption( "+2" )
						) ,
					new TestItem( // 3
							"Яка речовина є дуже отруйною, тому що блокує здатність гемоглобіну зв’язувати кисень?" , null , groups[ 0 ] ,
							new TestItemOption( "CO" , true ) ,
							new TestItemOption( "CO₂" ) ,
							new TestItemOption( "CH₄" ) ,
							new TestItemOption( "SiH₄" )
						) ,
					new TestItem( // 4
							"Яка сіль належить до солей амонію?" , null , groups[ 0 ] ,
							new TestItemOption( "KNO₃" ) ,
							new TestItemOption( "NH₄NO₃" , true ) ,
							new TestItemOption( "Ca(NO)₂" ) ,
							new TestItemOption( "Na₃PO₄" )
						) ,
					new TestItem( // 5
							"Який неметал при звичайних умовах є рідиною?" , null , groups[ 0 ] ,
							new TestItemOption( "фтор" ) ,
							new TestItemOption( "білий фосфор" ) ,
							new TestItemOption( "азот" ) ,
							new TestItemOption( "бром" , true )
						) ,
					new TestItem( // 6
							"Алотропними видозмінами сірки є" , null , groups[ 0 ] ,
							new TestItemOption( "червона і чорна сірки" ) ,
							new TestItemOption( "жовта і коричнева сірки" ) ,
							new TestItemOption( "кристалічна і пластична сірки" , true )
						) ,
					new TestItem( // 7
							"Вкажіть назву і формулу солі сульфатної кислоти" , null , groups[ 1 ] ,
							new TestItemOption( "барій хлорид" ) ,
							new TestItemOption( "амоній сульфат" , true ) ,
							new TestItemOption( "калій нітрат" ) ,
							new TestItemOption( "KNO₃" ) ,
							new TestItemOption( "BaCl₂" ) ,
							new TestItemOption( "Na₃PO₄" ) ,
							new TestItemOption( "(NH₄)₂SO₄" , true )
						) ,
					new TestItem( // 8
							"Які іони знаходяться у водному розчині хлоридної кислоти?" , null , groups[ 1 ] ,
							new TestItemOption( "H⁺" , true ) ,
							new TestItemOption( "Na⁺" ) ,
							new TestItemOption( "Cl¯" , true ) ,
							new TestItemOption( "NO₃¯" )
						) ,
					new TestItem( // 9
							"Вкажіть вищий та нижчий ступені окисненя Сульфуру" , null , groups[ 1 ] ,
							new TestItemOption( "-3" ) ,
							new TestItemOption( "-2" , true ) ,
							new TestItemOption( "0" ) ,
							new TestItemOption( "+4" ) ,
							new TestItemOption( "+6" , true )
						) ,
					new TestItem( // 10
							"Чим відрізняється атоми Сульфуру і Хлору?" , null , groups[ 1 ] ,
							new TestItemOption( "мають різну кількість енергетичних рівнів" ) ,
							new TestItemOption( "мають різну кількість електронів на зовнішньому енергетичному рівні" , true ) ,
							new TestItemOption( "мають різну кількість неспарених електронів на зовнішньому енергетичному рівні" , true ) ,
							new TestItemOption( "в атомі Сульфуру на зовнішньому енергетичному рівні є вільні d-орбіталі, а в атомі Хлору вільних орбіталей немає" )
						) ,
					new TestItem( // 11
							"Для добування аргентум хлориду необхідно взяти такі речовини" , null , groups[ 1 ] ,
							new TestItemOption( "натрій нітрат" ) ,
							new TestItemOption( "аргентум нітрат" , true ) ,
							new TestItemOption( "кальцій хлорид" , true ) ,
							new TestItemOption( "хлор" )
						) ,
					new TestItem( // 12
							"Які фізичні властивості характерні для амоніаку?" , null , groups[ 1 ] ,
							new TestItemOption( "має різкий запах" , true ) ,
							new TestItemOption( "без запаху" ) ,
							new TestItemOption( "добре розчиняється у воді" , true ) ,
							new TestItemOption( "має жовто-зелений колір" )
						) ,
					new TestItem( // 13
							"Закінчити рівняння реакції, вказати суму всіх коефіцієнтів у цьому рівнянні:"
							+ "\nN₂ + H₂ →" , null , groups[ 2 ] ,
							new TestItemOption( "3" ) ,
							new TestItemOption( "4" ) ,
							new TestItemOption( "6" , true )
						) ,
					new TestItem( // 14
							"Визначити масу 0,2 моль Сульфуру (VI) оксиду (сірчаного ангідриду)" , null , groups[ 2 ] ,
							new TestItemOption( "16 г" , true ) ,
							new TestItemOption( "24 г" ) ,
							new TestItemOption( "16,8 г" )
						) ,
					new TestItem( // 15
							"Визначити невідому речовину у рівнянні реакції:"
							+ "\n(NH₄)₂CO₃ → CO₂ + H₂O + …" , null , groups[ 2 ] ,
							new TestItemOption( "N₂" ) ,
							new TestItemOption( "NH₃" , true ) ,
							new TestItemOption( "NO" )
						) ,
					new TestItem( // 16
							"У процесі розкладання амоній хлориду масою 107 г одержали амоніак об’ємом 38 л (н. у.)."
								+ " Обчисліть об’ємну частку виходу амоніаку" , null , groups[ 3 ] ,
							new TestItemOption( "85%" , true ) ,
							new TestItemOption( "80%" ) ,
							new TestItemOption( "75%" )
						) ,
					new TestItem( // 17
							"Визначити загальне число електронів відданих атомами Цинку у рівнянні окисно-відновної реакції:"
							+ "\nZn + H₂SO₄ (конц.) → … + S + …" , null , groups[ 3 ] ,
							new TestItemOption( "2" ) ,
							new TestItemOption( "4" ) ,
							new TestItemOption( "6" , true )
						)
				);

			test.Serialize( "nonmet1.test" );
		}

		public static void GenNonMetals2()
		{
			var groups = new[]
						{
							new TestItemGroup("Оберіть одну правильну відповідь", 3),
							new TestItemGroup("Оберіть дві правильні відповіді", 4),
							new TestItemGroup("Вкажіть правильну відповідь", 6),
							new TestItemGroup("Високий рівень", 6)
						};

			var test = new TestClass(
					"Неметалічні елементи та їхні сполуки. Варіант II" , _AUTHOR , 72 , null ,
					groups , //⁰¹²³⁴⁵⁶⁷⁸⁹⁺‾¯ ₀₁₂₃₄₅₆₇₈₉₊₋
					new TestItem( // 1
							"Вкажіть електронну формулу атома Фосфору" , null , groups[ 0 ] ,
							new TestItemOption( "1s²2s²2p⁶3s²3p³" , true ) ,
							new TestItemOption( "1s²2s²2p³" ) ,
							new TestItemOption( "1s²2s²2p⁶3s²3p⁵" )
						) ,
					new TestItem( // 2
							"Якій найвищий ступінь окиснення виявляє у сполуках атом Карбону?" , null , groups[ 0 ] ,
							new TestItemOption( "+2" ) ,
							new TestItemOption( "+3" ) ,
							new TestItemOption( "+4" , true ) ,
							new TestItemOption( "+6" )
						) ,
					new TestItem( // 3
							"Силіцій (IV) оксид — це …" , null , groups[ 0 ] ,
							new TestItemOption( "м’яка кристалічна речовина, що розчиняється у воді" ) ,
							new TestItemOption( "тверда кристалічна безбарвна тугоплавка нерозчинна у воді речовина" , true ) ,
							new TestItemOption( "забарвлена тверда кристалічна речовина, що розчиняється у воді" ) ,
							new TestItemOption( "тверда кристалічна безбарвна легкоплавка нерозчинна у воді речовина" )
						) ,
					new TestItem( // 4
							"Як змінюються властивості галогенів як окисників із збільшенням порядкового номера (від Флуору до Астату)?" , null , groups[ 0 ] ,
							new TestItemOption( "зменшуються" , true ) ,
							new TestItemOption( "не змінюються" ) ,
							new TestItemOption( "збільшуються" )
						) ,
					new TestItem( // 5
							"Сульфур у природі поширений" , null , groups[ 0 ] ,
							new TestItemOption( "лише у вільному стані (у вигляді простої речовини)" ) ,
							new TestItemOption( "лише у зв’язаному стані (у складі сполук)" ) ,
							new TestItemOption( "у вільному і зв’язаному станах" , true )
						) ,
					new TestItem( // 6
							"Кількість зв’язків між атомами Нітрогену в молекулі азоту дорівнює" , null , groups[ 0 ] ,
							new TestItemOption( "1" ) ,
							new TestItemOption( "2" ) ,
							new TestItemOption( "3" , true )
						) ,
					new TestItem( // 7
							"Вкажіть вищий та нижчий ступені окиснення Фосфору" , null , groups[ 1 ] ,
							new TestItemOption( "-3" , true ) ,
							new TestItemOption( "-1" ) ,
							new TestItemOption( "+3" ) ,
							new TestItemOption( "+5" , true )
						) ,
					new TestItem( // 8
							"Вкажіть назву і формулу солі амонію" , null , groups[ 1 ] ,
							new TestItemOption( "амоній хлорид" , true ) ,
							new TestItemOption( "натрій нітрат" ) ,
							new TestItemOption( "алюміній сульфат" ) ,
							new TestItemOption( "NH₄OH" ) ,
							new TestItemOption( "NH₄Cl" , true ) ,
							new TestItemOption( "Na₃PO₄" )
						) ,
					new TestItem( // 9
							"Які іони знаходяться у водному розчині сульфатної кислоти" , null , groups[ 1 ] ,
							new TestItemOption( "H⁺" , true ) ,
							new TestItemOption( "Na⁺" ) ,
							new TestItemOption( "SO₃¯" ) ,
							new TestItemOption( "SO₄¯" , true )
						) ,
					new TestItem( // 10
							"Чим відрізняються атоми Нітрогену і Фосфору?" , null , groups[ 1 ] ,
							new TestItemOption( "мають однакову кількість енергетичних рівнів" ) ,
							new TestItemOption( "мають різну кількість енергетичних рівнів" , true ) ,
							new TestItemOption( "мають різну кількість електронів на зовнішньому енергетичному рівні" ) ,
							new TestItemOption( "в атому Фосфору на зовнішньому енергетичному рівні є вільні d-орбіталі, а в атомі Нітрогену вільних орбіталей немає" , true )
						) ,
					new TestItem( // 11
							"Для добування амоніаку контактним способом необхідно взяти такі речовини" , null , groups[ 1 ] ,
							new TestItemOption( "водень" , true ) ,
							new TestItemOption( "хлор" ) ,
							new TestItemOption( "азот" , true ) ,
							new TestItemOption( "кисень" )
						) ,
					new TestItem( // 12
							"Алотропними видозмінами елемента Карбону є" , null , groups[ 1 ] ,
							new TestItemOption( "кварц" ) ,
							new TestItemOption( "графіт" , true ) ,
							new TestItemOption( "сажа" ) ,
							new TestItemOption( "алмаз" , true )
						) ,
					new TestItem( // 13
							"Закінчити рівняння реакції, вказати суму всіх коефіцієнтів у цьому рівнянні:"
							+ "\nMg + P →" , null , groups[ 2 ] ,
							new TestItemOption( "6" , true ) ,
							new TestItemOption( "4" ) ,
							new TestItemOption( "3" )
						) ,
					new TestItem( // 14
							"Визначити масу 0,01 моль Карбону (IV) оксиду (вуглекислого газу)" , null , groups[ 2 ] ,
							new TestItemOption( "0,88 г" , true ) ,
							new TestItemOption( "4,4 г" ) ,
							new TestItemOption( "0,44 г" )
						) ,
					new TestItem( // 15
							"Визначити невідому речовину у рівнянні реакції:"
							+ "\nNH₃ + O₂ → … + H₂O" , null , groups[ 2 ] ,
							new TestItemOption( "N₂" , true ) ,
							new TestItemOption( "NO" ) ,
							new TestItemOption( "NO₂" )
						) ,
					new TestItem( // 16
							"У процесі нагрівання 42 г амоній хлориду з надлишком кальцій гідрооксиду, одержали амоніак об’ємом 11,6 л (н. у.)."
								+ " Обчисліть об’ємну частку виходу амоніаку." , null , groups[ 3 ] ,
							new TestItemOption( "65,9%" , true ) ,
							new TestItemOption( "59,6%" ) ,
							new TestItemOption( "85,5%" )
						) ,
					new TestItem( // 17
							"Визначити загальне число електронів відданих атомами Цинку у рівнянні окисно-відновної реакції:"
							+ "\nMg + H₂SO₄ (конц.) → … + H₂S + …" , null , groups[ 3 ] ,
							new TestItemOption( "4" ) ,
							new TestItemOption( "6" ) ,
							new TestItemOption( "8" , true ) ,
							new TestItemOption( "2" )
						)
				);

			test.Serialize( "nonmet2.test" );
		}
	}
}
