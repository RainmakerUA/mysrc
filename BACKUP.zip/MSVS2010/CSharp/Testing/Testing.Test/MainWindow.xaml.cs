﻿using System;
using System.Windows;
using System.Xaml;
using Testing.Lib.Common.ObjectModel;
using Testing.Lib.Common.XmlZ;


namespace Testing.Test
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
			/*
			var txt = "<TextBlock xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\">"
					+ "<Run FontSize=\"14\">CH</Run>"
					+ "<Run BaselineAlignment=\"Subscript\" FontSize=\"8\">4</Run>"
					+ "</TextBlock>";
			object node = XamlServices.Parse( txt );
			btn.Content = node;
			*/

			OnDoIt( this , new RoutedEventArgs() );
		}

		private void OnDoIt( object sender , RoutedEventArgs e )
		{
			Environment.CurrentDirectory = @"e:\Work\Rainmaker\Workspace\Programming\rm-space\MSVS2010\CSharp\Testing\Tests\Alco1\";
			TestGen.GenAlco1();

			Environment.CurrentDirectory = @"e:\Work\Rainmaker\Workspace\Programming\rm-space\MSVS2010\CSharp\Testing\Tests\Alco2\";
			TestGen.GenAlco2();

			Environment.CurrentDirectory = @"e:\Work\Rainmaker\Workspace\Programming\rm-space\MSVS2010\CSharp\Testing\Tests\Ether1\";
			TestGen.GenEther1();

			Environment.CurrentDirectory = @"e:\Work\Rainmaker\Workspace\Programming\rm-space\MSVS2010\CSharp\Testing\Tests\Ether2\";
			TestGen.GenEther2();

			Environment.CurrentDirectory = @"e:\Work\Rainmaker\Workspace\Programming\rm-space\MSVS2010\CSharp\Testing\Tests\NonMetal";
			TestGen.GenNonMetals1();
			TestGen.GenNonMetals2();
			
			/*
			var newTest = TestXmlZ.Deserialize( "alco1.test" );
			var win = new TestWindow();
			win.DataContext = newTest;
			win.ShowDialog();
			*/
		}
	}
}
