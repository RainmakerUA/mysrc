﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using Testing.Lib.Common.ObjectModel;
using Testing.Presenter.Controls;

namespace Testing.Presenter.Converters
{
	internal class TestItemAnswerConverter : IValueConverter
	{
		#region IValueConverter Members

		private static ToggleButton CreateButton( TestItemOption item , bool isCheck , string groupName )
		{
			ToggleButton btn;

			if ( isCheck )
			{
				btn = new CheckBox();
			}
			else
			{
				btn = new UnCheckRadioButton();
				( btn as UnCheckRadioButton ).GroupName = groupName;
			}

			btn.DataContext = item;
			btn.SetValue( FrameworkElement.StyleProperty , btn.FindResource( "AnswerItem" ) );
			btn.SetBinding( ToggleButton.IsCheckedProperty , "IsChecked" );

			return btn;
		}

		object IValueConverter.Convert( object value , Type targetType , object parameter , CultureInfo culture )
		{
			IEnumerable result = null;
			var items = value as ICollection<TestItemOption>;

			if ( items != null && targetType == typeof( IEnumerable ) )
			{
				bool isCheck = items.Count( item => item.IsCorrect ) > 1;
				string group = Guid.NewGuid().ToString( "N" );
				result = items.Select( item => CreateButton( item , isCheck , group ) );
			}

			return result;
		}

		object IValueConverter.ConvertBack( object value , Type targetType , object parameter , CultureInfo culture )
		{
			throw new NotImplementedException();
		}

		#endregion
	}
}
