﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Testing.Lib.Common.ObjectModel;
using Testing.Presenter.ContentControls;
using Testing.Presenter.Controls;

namespace Testing.Presenter
{
	/// <summary>
	/// Логика взаимодействия для MainWindow.xaml
	/// </summary>
	internal partial class MainWindow : ContentWindow
	{
		public MainWindow()
		{
			InitializeComponent();
			OpenTestSelection();
		}

		private void OpenTestSelection()
		{
			OpenContent( new TestSelection() );
		}

		private void OpenTest( Test test )
		{
			if ( test != null )
			{
				test.ClearAnswerChecks();
				OpenContent( new TestPresenter { Test = test } );
			}
		}

		private void OpenTestResults( Test test )
		{
			if ( test != null )
			{
				OpenContent( new TestResult { Test = test } );
			}
		}

		private void OpenAbout()
		{
			OpenContent( new AboutControl() );
		}

		protected override void CloseContent( object arg = null )
		{
			var content = Content;
			base.CloseContent( arg );

			if ( content is TestSelection )
			{
				if ( arg is int && ( ( int ) arg ) == 19 )
				{
					OpenAbout();
				}

				Test test = arg as Test;
				OpenTest( test );
			}
			else if ( content is TestPresenter )
			{
				Test test = arg as Test;
				base.CloseContent();

				if ( test == null )
				{
					OpenTestSelection();
				}
				else
				{
					OpenTestResults( test );
				}
			}
			else if ( content is TestResult )
			{
				Test test = arg as Test;

				if ( test == null )
				{
					OpenTestSelection();
				}
				else
				{
					OpenTest( test );
				}
			}
			else
			{
				OpenTestSelection();
			}
		}
	}
}
