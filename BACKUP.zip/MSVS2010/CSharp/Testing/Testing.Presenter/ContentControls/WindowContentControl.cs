﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Testing.Presenter.ContentControls
{
	internal class WindowContentControl : UserControl
	{
		protected WindowContentControl()
		{
			Background = new SolidColorBrush( Colors.Transparent );
			Padding = new Thickness( 5 );
		}

		protected void OnCloseRequest( object arg )
		{
			if ( CloseRequest != null )
			{
				CloseRequest( this , new CloseRequestArgs( arg ) );
			}
		}

		protected void Close( object arg = null )
		{
			OnCloseRequest( arg );
		}

		public virtual void Initialize()
		{
		}

		public virtual void Deinitialize()
		{
		}

		public event EventHandler<CloseRequestArgs> CloseRequest;
	}

	internal class CloseRequestArgs : EventArgs
	{
		public CloseRequestArgs( object arg = null )
		{
			Argument = arg;
		}

		public object Argument { get; private set; }
	}
}
