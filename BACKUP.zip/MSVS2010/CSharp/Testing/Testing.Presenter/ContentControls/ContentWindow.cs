﻿using System;
using System.ComponentModel;
using System.Windows;

namespace Testing.Presenter.ContentControls
{
	internal class ContentWindow : Window
	{
		public new WindowContentControl Content
		{
			get
			{
				return base.Content as WindowContentControl;
			}
			protected set
			{
				base.Content = value;
			}

		}

		private void OnContentCloseRequest( object sender , CloseRequestArgs e )
		{
			if ( CanCloseContent( e.Argument ) )
			{
				CloseContent( e.Argument );
			}
		}

		protected virtual bool CanCloseContent( object arg )
		{
			return true;
		}

		protected virtual void OpenContent( WindowContentControl content )
		{
			if ( Content != null )
			{
				CloseContent();
			}

			content.CloseRequest += OnContentCloseRequest;
			content.Initialize();
			Content = content;
		}

		protected virtual void CloseContent( object arg = null )
		{
			if ( Content != null )
			{
				Content.Deinitialize();
				Content.CloseRequest -= OnContentCloseRequest;
				Content = null;
			}
		}

		protected override void OnClosing( CancelEventArgs e )
		{
			if ( e != null )
			{
				e.Cancel = Content != null;
			}
			base.OnClosing( e );
		}
	}
}
