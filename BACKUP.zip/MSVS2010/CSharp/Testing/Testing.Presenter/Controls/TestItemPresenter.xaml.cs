﻿using System.Windows.Controls;

namespace Testing.Presenter.Controls
{
	/// <summary>
	/// Interaction logic for TestItemPresenter.xaml
	/// </summary>
	public partial class TestItemPresenter : UserControl
	{
		public TestItemPresenter()
		{
			InitializeComponent();
		}
	}
}
