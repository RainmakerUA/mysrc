﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using Testing.Lib.Common.ObjectModel;
using Testing.Presenter.ContentControls;
using System.ComponentModel;

namespace Testing.Presenter.Controls
{
	/// <summary>
	/// Interaction logic for TestResult.xaml
	/// </summary>
	internal partial class AboutControl : WindowContentControl
	{
		public AboutControl()
		{
			InitializeComponent();
		}

		private void OnClose( object sender , RoutedEventArgs e )
		{
			OnCloseRequest( null );
		}
	}
}
