﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using Testing.Lib.Common.ObjectModel;
using Testing.Presenter.ContentControls;
using System.ComponentModel;

namespace Testing.Presenter.Controls
{
	/// <summary>
	/// Interaction logic for TestResult.xaml
	/// </summary>
	internal partial class TestResult : WindowContentControl
	{
		private sealed class TestResultData : INotifyPropertyChanged
		{
			private const int _MIN_MARK = 1;
			private const int _MAX_MARK = 12;
			private const string _POINTS_FMT = "{0}/{1}";

			//private static readonly Color _minColor = Color.FromArgb( 0xFF , 0xFF , 0 , 0 );
			//private static readonly Color _maxColor = Color.FromArgb( 0xFF , 0 , 0xFF , 0 );

			private int _points;
			private int _maxPoints;
			private int _mark;
			private Color _markColor;

			public int Points
			{
				get
				{
					return _points;
				}
				set
				{
					_points = value;
					ReCalculate();
					RaisePropertyChanged( "Points" );
					RaisePropertyChanged( "PointsString" );
				}
			}

			public int MaxPoints
			{
				get
				{
					return _maxPoints;
				}
				set
				{
					_maxPoints = value;
					ReCalculate();
					RaisePropertyChanged( "MaxPoints" );
					RaisePropertyChanged( "PointsString" );
				}
			}

			public string PointsString
			{
				get
				{
					return String.Format( _POINTS_FMT , _points , _maxPoints );
				}
			}

			public int Mark
			{
				get
				{
					return _mark;
				}
			}

			public SolidColorBrush MarkColor
			{
				get
				{
					return new SolidColorBrush( _markColor );
				}
			}

			private void ReCalculate()
			{
				if ( _points == 0 || _maxPoints == 0 )
				{
					_mark = _MIN_MARK;
					_markColor = Colors.Red;
				}
				else
				{
					float q = ( float ) _points / _maxPoints;

					_mark = _MIN_MARK + ( int ) Math.Round( q * ( _MAX_MARK - _MIN_MARK ) );
					_markColor = Color.FromRgb(
							( byte ) Math.Round( 0xFF * ( 1 - q ) ) ,
							( byte ) Math.Round( 0xFF * q ) ,
							0
						);
				}

				RaisePropertyChanged( "Mark" );
				RaisePropertyChanged( "Color" );
			}

			private void RaisePropertyChanged( string name )
			{
				if ( PropertyChanged != null )
				{
					PropertyChanged( this , new PropertyChangedEventArgs( name ) );
				}
			}

			#region INotifyPropertyChanged Members

			public event PropertyChangedEventHandler PropertyChanged;

			#endregion
		}

		private Test _test;

		public TestResult()
		{
			InitializeComponent();
		}

		public Test Test
		{
			get
			{
				return _test;
			}
			set
			{
				_test = value;
				if ( _test != null )
				{
					ReCalculate();
				}
			}
		}

		private void ReCalculate()
		{
			int points = ( int ) Math.Round( _test.Questions.Sum( new Func<TestItem , double>( TestObjectsHelper.GetPoints ) ) );
			DataContext = new TestResultData { Points = points > 0 ? points : 0 , MaxPoints = _test.MaxPoints };
		}

		private void OnClose( object sender , RoutedEventArgs e )
		{
			Close();
		}

		private void OnRetry( object sender , RoutedEventArgs e )
		{
			Close( Test );
		}
	}
}
