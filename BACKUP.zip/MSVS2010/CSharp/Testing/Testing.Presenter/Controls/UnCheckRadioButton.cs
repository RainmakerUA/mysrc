﻿using System.Windows.Controls;

namespace Testing.Presenter.Controls
{
	internal class UnCheckRadioButton : RadioButton
	{
		protected override void OnClick()
		{
			if ( ( bool ) GetValue( IsCheckedProperty ) )
			{
				SetValue( IsCheckedProperty , false );
			}
			else
			{
				base.OnClick();
			}
		}
	}
}
