﻿using System;
using System.Windows;
using Testing.Lib.Common.ObjectModel;
using Testing.Presenter.ContentControls;
using Testing.Presenter.Helpers;

namespace Testing.Presenter.Controls
{
	/// <summary>
	/// Interaction logic for TestSelection.xaml
	/// </summary>
	internal partial class TestSelection : WindowContentControl
	{
		public TestSelection()
		{
			InitializeComponent();
		}

		public override void Initialize()
		{
			base.Initialize();

			listBoxTests.DataContext = TestFinder.Tests;
		}

		private void OnClose( object sender , RoutedEventArgs e )
		{
			Application.Current.Shutdown();
		}

		private void OnStart( object sender , RoutedEventArgs e )
		{
			OnCloseRequest( listBoxTests.SelectedItem as Test );
		}

		private void OnShowAbout( object sender , RoutedEventArgs e )
		{
			OnCloseRequest( 19 );
		}
	}
}
