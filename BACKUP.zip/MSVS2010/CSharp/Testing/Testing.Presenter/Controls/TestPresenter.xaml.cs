﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Windows;
using Testing.Lib.Common.ObjectModel;
using Testing.Presenter.ContentControls;

namespace Testing.Presenter.Controls
{
	/// <summary>
	/// Interaction logic for TestPresenter.xaml
	/// </summary>
	internal partial class TestPresenter : WindowContentControl , INotifyPropertyChanged
	{
		private LinkedList<TestItem> _itemList;
		private LinkedListNode<TestItem> _currentItem;

		public TestPresenter()
		{
			InitializeComponent();
			gridItem.DataContext = this;
		}

		public Test Test
		{
			get
			{
				return GetValue( DataContextProperty ) as Test;
			}
			set
			{
				SetValue( DataContextProperty , value );
				if ( value != null )
				{
					FillItemList( value.Questions );
				}
			}
		}

		public TestItem CurrentTestItem
		{
			get
			{
				return _currentItem.Value;
			}
		}

		private void FillItemList( IEnumerable<TestItem> items )
		{
			if ( _itemList != null && _itemList.Count > 0 )
			{
				_itemList.Clear();
			}

			_itemList = new LinkedList<TestItem>( items );
			_currentItem = _itemList.First;
			RaisePropertyChanged( "CurrentTestItem" );
			UpdateNextPrevButtons();
		}

		private void UpdateNextPrevButtons()
		{
			buttonPrev.IsEnabled = _currentItem != null && _currentItem.Previous != null;
			buttonNext.IsEnabled = _currentItem != null && _currentItem.Next != null;
		}

		private void RaisePropertyChanged( string propertyName )
		{
			if ( PropertyChanged != null )
			{
				PropertyChanged( this , new PropertyChangedEventArgs( propertyName ) );
			}
		}

		private void OnCancel( object sender , RoutedEventArgs e )
		{
			Close();
		}

		private void OnNext( object sender , RoutedEventArgs e )
		{
			if ( _currentItem.Next != null )
			{
				_currentItem = _currentItem.Next;
				RaisePropertyChanged( "CurrentTestItem" );
			}
			UpdateNextPrevButtons();
		}

		private void OnPrev( object sender , RoutedEventArgs e )
		{
			if ( _currentItem.Previous != null )
			{
				_currentItem = _currentItem.Previous;
				RaisePropertyChanged( "CurrentTestItem" );
			}
			UpdateNextPrevButtons();
		}

		private void OnFinish( object sender , RoutedEventArgs e )
		{
			Close( Test );
		}

		#region INotifyPropertyChanged Members

		public event PropertyChangedEventHandler PropertyChanged;

		#endregion
	}
}
