﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Reflection;
using Testing.Lib.Common.ObjectModel;
using Testing.Lib.Common.XmlZ;

namespace Testing.Presenter.Helpers
{
	internal static class TestFinder
	{
		private const string _TEST_DIR_NAME = "Tests";
		private const string _TEST_SEARCH_MASK = "*.test";

		private static readonly string[] _testDirectories = GetTestDirectories();
		private static List<Test> _tests;

		public static ReadOnlyCollection<Test> Tests
		{
			get
			{
				if ( _tests == null || _tests.Count == 0 )
				{
					_tests = GetTests( SortTestQuestionsByGroup );
				}

				return new ReadOnlyCollection<Test>( _tests );
			}
		}

		private static string[] GetTestDirectories()
		{
			var dirs = new List<string>
			           {
							// .\Tests - causes test duplicates despite .Distinct()
			           		//Path.Combine( Directory.GetCurrentDirectory() , _TEST_DIR_NAME ) ,
							//%EXE_PATH%\Tests
							Path.Combine( Path.GetDirectoryName( Assembly.GetEntryAssembly().Location ) , _TEST_DIR_NAME ) ,
							// %MyDocuments%\Tests
							//Path.Combine( Environment.GetFolderPath( Environment.SpecialFolder.MyDocuments ) , _TEST_DIR_NAME ) ,
							// %CommonDocuments%\Tests
							//Path.Combine( Environment.GetFolderPath( Environment.SpecialFolder.CommonDocuments ) , _TEST_DIR_NAME )
			           };
			return dirs.Where( Directory.Exists ).Distinct().ToArray();
		}

		private static void SortTestQuestionsByGroup( Test test )
		{
			if ( test == null )
			{
				return;
			}

			var groups = test.Groups;
			var questions = test.Questions;

			if ( test.Groups == null || test.Groups.Count == 0 || test.Questions == null || test.Questions.Count == 0 )
			{
				return;
			}

			var list = new List<TestItem>( questions );
			list.Sort( ( q1 , q2 ) => groups.IndexOf( q1.Group ).CompareTo( groups.IndexOf( q2.Group ) ) );

			test.Questions = new ObservableCollection<TestItem>( list );
		}

		private static Test DeserializeTestSilent( string filename )
		{
			return TestXmlZ.Deserialize( filename , true );
		}

		private static List<Test> GetTests( Action<Test> processing = null )
		{
			var tests = ( from dir in _testDirectories
			              from file in Directory.EnumerateFiles( dir , _TEST_SEARCH_MASK , SearchOption.AllDirectories )
			              select DeserializeTestSilent( file ) ).Where( test => test != null );

			if ( processing != null )
			{
				foreach ( var test in tests )
				{
					processing( test );
				}
			}

			return tests.ToList();
		}
	}
}
