﻿using System;
using System.Windows;
using System.Windows.Data;

namespace Testing.Lib.Presentation.Converters
{
	public class NullToVisibilityConverter : IValueConverter
	{
		object IValueConverter.Convert( object value , Type targetType , object parameter , System.Globalization.CultureInfo culture )
		{
			return targetType == typeof ( Visibility )
			       	? ( object ) ( value == null ? Visibility.Collapsed : Visibility.Visible )
			       	: null;
		}

		object IValueConverter.ConvertBack( object value , Type targetType , object parameter , System.Globalization.CultureInfo culture )
		{
			throw new NotImplementedException();
		}
	}
}
