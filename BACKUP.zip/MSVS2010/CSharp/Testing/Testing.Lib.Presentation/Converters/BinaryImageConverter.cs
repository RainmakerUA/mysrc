﻿using System;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace Testing.Lib.Presentation.Converters
{
	public sealed class BinaryImageConverter : IValueConverter
	{
		#region IValueConverter Members

		object IValueConverter.Convert( object value , Type targetType , object parameter , CultureInfo culture )
		{
			Stream ms;
			var val = value as byte[];

			if ( val != null )
			{
				ms = new MemoryStream( val );
			}
			else
			{
				// ReSharper disable PossibleNullReferenceException
				ms = Application.GetResourceStream( new Uri( String.Format(
						"{0};component/Resources/NoImage.png" , Assembly.GetExecutingAssembly().GetName().Name
					) , UriKind.Relative ) ).Stream;
				// ReSharper restore PossibleNullReferenceException
			}

			var bmImg = new BitmapImage();
			bmImg.BeginInit();
			bmImg.StreamSource = ms;
			bmImg.EndInit();
			return bmImg;
		}

		object IValueConverter.ConvertBack( object value , Type targetType , object parameter , CultureInfo culture )
		{
			throw new NotImplementedException();
		}

		#endregion
	}
}
