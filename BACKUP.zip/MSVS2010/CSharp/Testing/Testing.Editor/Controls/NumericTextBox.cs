using System;
using System.Media;
using System.Windows.Controls;
using System.Windows;

namespace Testing.Editor.Controls
{
    internal class NumericTextBox : TextBox
    {
        public static readonly DependencyProperty AllowNegativeProperty
                = DependencyProperty.Register( "AllowNegative", typeof( bool ), typeof( NumericTextBox ) );

		protected override void OnPreviewTextInput( System.Windows.Input.TextCompositionEventArgs e )
		{
			int num;
			base.OnPreviewTextInput( e );
			if ( !Int32.TryParse( e.Text , out num ) )
			{
				SystemSounds.Beep.Play();
				e.Handled = true;
			}
			
		}

        public bool AllowNegative
        {
            get
            {
                return (bool) GetValue( AllowNegativeProperty );
            }
            set
            {
                SetValue( AllowNegativeProperty, value );
            }
        }
    }
}