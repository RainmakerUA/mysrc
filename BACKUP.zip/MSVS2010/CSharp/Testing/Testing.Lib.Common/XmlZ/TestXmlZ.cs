﻿using System;
using System.IO;
using System.Xml.Serialization;
using Testing.Lib.Common.BZip2;
using Testing.Lib.Common.ObjectModel;

namespace Testing.Lib.Common.XmlZ
{
	public static class TestXmlZ
	{
		private static readonly Type _testType = typeof( Test );

		public static void Serialize( this Test test , string filename , bool overwrite = true )
		{
			using ( var cs = new BZip2OutputStream(
				File.Open(
					filename ,
					overwrite ? FileMode.Create : FileMode.CreateNew ,
					FileAccess.Write , FileShare.Read
				) ) )
			{
				var xser = new XmlSerializer( _testType );
				xser.Serialize( cs , test );
			}
		}

		public static Test Deserialize( string filename , bool silentErrors = false )
		{
			Test test = null;

			try
			{
				using ( var cs = new BZip2InputStream(
					File.Open( filename , FileMode.Open , FileAccess.Read , FileShare.Read )
					) )
				{
					var xser = new XmlSerializer( _testType );
					test = (Test) xser.Deserialize( cs );
				}
			}
			catch ( Exception )
			{
				if ( !silentErrors )
				{
					throw;
				}
			}

			return test;
		}
	}
}
