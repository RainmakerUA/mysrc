﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Testing.Lib.Common.ObjectModel
{
	[Serializable]
	public sealed class Test : BaseTestObject
	{
		private byte[] _image;
		private int _maxPoints;
		private ObservableCollection<TestItemGroup> _groups;
		private ObservableCollection<TestItem> _questions;
		private string _title;
		private string _author;

		public Test()
		{
			// Do nothing.
		}

		public Test( string title , string author , int maxPoints , byte[] image , IEnumerable<TestItemGroup> groups , IEnumerable<TestItem> questions )
		{
			_title = title;
			_author = author;
			_maxPoints = maxPoints;
			_image = image;
			_groups = new ObservableCollection<TestItemGroup>( groups );
			_questions = new ObservableCollection<TestItem>( questions );
		}

		public Test( string title , string author , int maxPoints , byte[] image , IEnumerable<TestItemGroup> groups , params TestItem[] questions )
			: this( title , author , maxPoints , image , groups , questions as IEnumerable<TestItem> )
		{
			// Do nothing.
		}

		public string Title
		{
			get
			{
				return _title;
			}
			set
			{
				_title = value;
				RaisePropertyChanged( "Title" );
			}
		}

		public string Author
		{
			get { return _author; }
			set
			{
				_author = value;
				RaisePropertyChanged( "Author" );
			}
		}

		public byte[] Image
		{
			get
			{
				return _image;
			}
			set
			{
				_image = value;
			}
		}

		public int MaxPoints
		{
			get
			{
				return _maxPoints;
			}
			set
			{
				_maxPoints = value;
				RaisePropertyChanged( "Time" );
			}
		}

		public ObservableCollection<TestItemGroup> Groups
		{
			get
			{
				return _groups;
			}
			set
			{
				_groups = value;
				RaisePropertyChanged( "Groups" );
			}
		}

		public ObservableCollection<TestItem> Questions
		{
			get
			{
				return _questions;
			}
			set
			{
				_questions = value;
				RaisePropertyChanged( "Questions" );
			}
		}

		public override string ToString()
		{
			return String.Format( "Test \"{0}\" ({1} questions, {2} max points)" , _title , _questions.Count , _maxPoints );
		}
	}
}
