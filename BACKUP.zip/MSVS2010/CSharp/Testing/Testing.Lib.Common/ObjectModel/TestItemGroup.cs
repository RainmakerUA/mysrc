﻿using System;

namespace Testing.Lib.Common.ObjectModel
{
	[Serializable]
	public sealed class TestItemGroup : BaseTestObject
	{
		private Guid _id;
		private int _points;
		private string _title;

		public TestItemGroup()
		{
		}

		public TestItemGroup( string title , int points )
		{
			_id = Guid.NewGuid();
			_title = title;
			_points = points;
		}

		public TestItemGroup( Guid id , string title , int points )
		{
			_id = id;
			_title = title;
			_points = points;
		}

		public Guid Id
		{
			get
			{
				return _id;
			}
			set
			{
				_id = value;
				RaisePropertyChanged( "Id" );
			}
		}

		public int Points
		{
			get
			{
				return _points;
			}
			set
			{
				_points = value;
				RaisePropertyChanged( "Points" );
			}
		}

		public string Title
		{
			get
			{
				return _title;
			}
			set
			{
				_title = value;
				RaisePropertyChanged( "Title" );
			}
		}

		public override string ToString()
		{
			return String.Format( "Group: {0}. {1} points per question." , _title , _points );
		}
	}
}
