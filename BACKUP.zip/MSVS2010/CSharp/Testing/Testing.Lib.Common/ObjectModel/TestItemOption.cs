﻿using System;
using System.Xml.Serialization;

namespace Testing.Lib.Common.ObjectModel
{
	[Serializable]
	public sealed class TestItemOption : BaseTestObject
	{
		private string _answer;
		private bool _isCorrect;

		private bool _isChecked;

		public TestItemOption()
		{
			// Do nothing.
		}

		public TestItemOption( string answer , bool isCorrect = false )
		{
			_answer = answer;
			_isCorrect = isCorrect;
		}

		public string Answer
		{
			get
			{
				return _answer;
			}
			set
			{
				_answer = value;
				RaisePropertyChanged( "IsCorrect" );
			}
		}

		public bool IsCorrect
		{
			get
			{
				return _isCorrect;
			}
			set
			{
				_isCorrect = value;
				RaisePropertyChanged( "IsCorrect" );
			}
		}

		[XmlIgnore]
		public bool IsChecked
		{
			get
			{
				return _isChecked;
			}
			set
			{
				_isChecked = value;
				RaisePropertyChanged( "IsChecked" );
			}
		}

		public override string ToString()
		{
			return String.Format( " Test answer \"{0}\" [{1}]" , _answer , _isCorrect ? 'v' : 'x' );
		}
	}
}
