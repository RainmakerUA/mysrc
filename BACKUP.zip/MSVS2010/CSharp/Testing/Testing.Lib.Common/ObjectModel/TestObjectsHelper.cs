﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Testing.Lib.Common.ObjectModel
{
	public static class TestObjectsHelper
	{
		public static void ClearAnswerChecks( this Test test )
		{
			if ( test == null )
			{
				return;
			}

			foreach ( var testItem in test.Questions )
			{
				foreach ( var option in testItem.Answers )
				{
					option.IsChecked = false;
				}
			}
		}

		public static double GetPoints( this TestItem testItem )
		{
			double points = 0.0;

			if ( testItem != null && testItem.Group != null )
			{
				int total = testItem.Group.Points;
				int numCorrect = testItem.Answers.Count( answer => answer.IsCorrect );

				if ( numCorrect > 0 && total > 0 )
				{
					double perCorrect = ( double ) total / numCorrect;
					double perIncorrect = ( double ) total / ( testItem.Answers.Count - numCorrect );

					foreach ( var option in testItem.Answers )
					{
						if ( option.IsChecked && option.IsCorrect )
						{
							points += perCorrect;
						}
						else if ( option.IsChecked && numCorrect > 1 )
						{
							points -= perIncorrect;
						}
					}
				}
			}

			return points;
		}
	}
}
