﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Testing.Lib.Common.ObjectModel
{
	[Serializable]
	public sealed class TestItem : BaseTestObject
	{
		private ObservableCollection< TestItemOption > _answers;
		private byte[] _image;
		private TestItemGroup _group;

		private string _question;

		public TestItem()
		{
			// Do nothing.
		}

		public TestItem( string question , byte[] image , TestItemGroup group , params TestItemOption[] answers )
			: this( question , image , group , answers as IEnumerable<TestItemOption> )
		{
			// Do nothing.
		}

		public TestItem( string question , byte[] image , TestItemGroup group , IEnumerable<TestItemOption> answers )
		{
			_question = question;
			_answers = new ObservableCollection< TestItemOption >( answers );
			_image = image;
			_group = group;
		}

		public string Question
		{
			get
			{
				return _question;
			}
			set
			{
				_question = value;
				RaisePropertyChanged( "Question" );
			}
		}

		public ObservableCollection< TestItemOption > Answers
		{
			get
			{
				return _answers;
			}
			set
			{
				_answers = value;
				RaisePropertyChanged( "Answers" );
			}
		}

		public byte[] Image
		{
			get
			{
				return _image;
			}
			set
			{
				_image = value;
				RaisePropertyChanged( "Image" );
			}
		}

		public TestItemGroup Group
		{
			get
			{
				return _group;
			}
			set
			{
				_group = value;
				RaisePropertyChanged( "Group" );
			}
		}

		public override string ToString()
		{
			return String.Format( "Test question \"{0}\" ({1} answers)" , _question , _answers.Count );
		}
	}
}
