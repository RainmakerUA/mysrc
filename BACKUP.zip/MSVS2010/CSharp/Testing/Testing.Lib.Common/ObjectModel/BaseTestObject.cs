﻿using System;
using System.ComponentModel;

namespace Testing.Lib.Common.ObjectModel
{
	public abstract class BaseTestObject : INotifyPropertyChanged
	{
		protected void RaisePropertyChanged( string name )
		{
			if ( PropertyChanged != null && !String.IsNullOrEmpty( name ) )
			{
				PropertyChanged( this , new PropertyChangedEventArgs( name ) );
			}
		}

		#region Члены INotifyPropertyChanged

		public event PropertyChangedEventHandler PropertyChanged;

		#endregion
	}
}
