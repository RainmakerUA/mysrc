﻿using System;
using Testing.Lib.Common.ObjectModel;

namespace Testing.Lib.Common.Interfaces
{
	public interface ITestEditor
	{
		string CurrentFileName { get; }
		bool IsChanged { get; }
		Test Current { get; }

		bool Create();
		bool Open( string fileName );
		bool Save();
		bool SaveAs( string fileName );

		event EventHandler Changed;
	}
}
