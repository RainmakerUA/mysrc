using System;
using System.IO;

namespace Testing.Lib.Common.BZip2
{
	/// <summary>
	/// A helper class to simplify compressing and decompressing streams.
	/// </summary>
	public static class BZip2
	{
		/// <summary>
		/// Decompress <paramref name="inStream">input</paramref> writing 
		/// decompressed data to the <paramref name="outStream">output stream</paramref>
		/// </summary>
		/// <param name="inStream">The stream containing data to decompress.</param>
		/// <param name="outStream">The stream to write decompressed data to.</param>
		/// <remarks>Both streams are closed on completion</remarks>
		public static void Decompress( Stream inStream , Stream outStream )
		{
			if ( inStream == null )
			{
				throw new ArgumentNullException( "inStream" );
			}

			if ( outStream == null )
			{
				throw new ArgumentNullException( "outStream" );
			}

			using ( outStream )
			{
				using ( BZip2InputStream bzis = new BZip2InputStream( inStream ) )
				{
					int ch = bzis.ReadByte();
					while ( ch != -1 )
					{
						outStream.WriteByte( ( byte ) ch );
						ch = bzis.ReadByte();
					}
				}
			}
		}

		/// <summary>
		/// Compress <paramref name="inStream">input stream</paramref> sending 
		/// result to <paramref name="outStream">output stream</paramref>
		/// </summary>
		/// <param name="inStream">The stream to compress.</param>
		/// <param name="outStream">The stream to write compressed data to.</param>
		/// <param name="blockSize">The block size to use.</param>
		/// <remarks>Both streams are closed on completion</remarks>
		public static void Compress( Stream inStream , Stream outStream , int blockSize )
		{
			if ( inStream == null )
			{
				throw new ArgumentNullException( "inStream" );
			}

			if ( outStream == null )
			{
				throw new ArgumentNullException( "outStream" );
			}

			using ( inStream )
			{
				using ( BZip2OutputStream bzos = new BZip2OutputStream( outStream , blockSize ) )
				{
					int ch = inStream.ReadByte();
					while ( ch != -1 )
					{
						bzos.WriteByte( ( byte ) ch );
						ch = inStream.ReadByte();
					}
				}
			}
		}
	}
}
