﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpTest
{
	internal static class Program
	{
		static void Main( string[] args )
		{
			StringHash.Test();

			Console.WriteLine( "Press any key to exit..." );
			Console.ReadKey( true );
		}
	}
}
