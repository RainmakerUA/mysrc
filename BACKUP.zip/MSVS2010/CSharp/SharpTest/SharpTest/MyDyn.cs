﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Numerics;
using System.Text;
using System.Dynamic;

namespace SharpTest
{
	internal class MyDyn : DynamicObject
	{
		private BigInteger _bigInt;

		public MyDyn()
		{
			_bigInt = new BigInteger();
		}

		public MyDyn( int num )
		{
			_bigInt = new BigInteger( num );
		}

		public override bool TryConvert( ConvertBinder binder , out object result )
		{
			bool success = false;
			result = null;

			if ( binder.Explicit )
			{
				if ( binder.Type == typeof( int ) )
				{
					success = true;
					result = (int) _bigInt;
				}
			}
			else
			{
				success = binder.Type == typeof( BigInteger );
				if ( success )
				{
					result = _bigInt;
				}
			}


			return success;
		}

		public override bool TryUnaryOperation( UnaryOperationBinder binder , out object result )
		{
			bool success;

			switch ( binder.Operation )
			{
				case ExpressionType.Increment:
					_bigInt++;
					success = true;
					break;

				case ExpressionType.Decrement:
					_bigInt--;
					success = true;
					break;

				default:
					success = false;
					break;
			}

			result = this;
			return success;
		}

		public static void Test()
		{
			dynamic d = new MyDyn( 19 );
			int num = ( int ) d++;
		}
	}
}
