﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SharpTest
{
	static class RegexMagicTester
	{
		private const string _MAGIC_PATTERN = @"^1?$|^(11+?)\1+$";

		private static bool IsPrime( int number )
		{
			var re = new Regex( _MAGIC_PATTERN );
			var str = new String( '1' , number );
			return !re.IsMatch( str );
		}

		public static void TestRegexPrime()
		{
			Console.WriteLine( "Prime number testing" );
			foreach ( int i in new[] { 1 , 3 , 5 , 12 , 13 , 19 , 100 } )
			{
				Console.WriteLine( "{0} is{1} prime" , i , IsPrime( i ) ? String.Empty : " not" );
			}
		}
	}
}
