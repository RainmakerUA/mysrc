﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml.Linq;

namespace SharpTest
{
	internal static class AppDomainTester
	{
		public static void TestAd()
		{
			string asmName = Assembly.GetExecutingAssembly().FullName;
			string typeName = typeof( Marshalled ).FullName;

			var ad = AppDomain.CreateDomain( "AD2" );

			var m = ( Marshalled ) ad.CreateInstanceAndUnwrap( asmName , typeName );
			m.Name = "Marshalled1";

			Console.WriteLine( "m.Name = {0}" , m.Name );
			Console.WriteLine( "Marshalled.Count = {0}" , Marshalled.Count );
			Console.WriteLine( m.GetInfo() );

			var mLocal = new Marshalled();
			Console.WriteLine( "mLocal.Name = {0}" , mLocal.Name );
			Console.WriteLine( "Marshalled.Count = {0}" , Marshalled.Count );
			Console.WriteLine( mLocal.GetInfo() );
		}
	}

	[Serializable]
	internal sealed class Marshalled //: MarshalByRefObject
	{
		public Marshalled()
		{
			Count++;
		}

		~Marshalled()
		{
			Count--;
		}

		public string Name { get; set; }
		public static int Count { get; private set; }

		public string GetInfo()
		{
			return String.Format(
					"AppDomain: {0}{1}Type: {2}{1}Count: {3}" ,
					AppDomain.CurrentDomain.FriendlyName ,
					Environment.NewLine ,
					GetType().FullName ,
					Count
				);
		}
	}
}
