﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SharpTest
{
	static class TaskTest
	{
		private const int _NUM_DAYS = 5;
		private const string _URL_FORMAT = "http://www.rock103.com/pages/bod/z/{0:D2}{1:D2}{2:D2}.jpg";

		private static readonly StringBuilder _sb = new StringBuilder();

		private static Func<byte[]> GetDownloader( string url )
		{
			return () =>
				   {
					   var dt1 = DateTime.Now;
					   lock ( _sb )
					   {
						   _sb.AppendFormat( "Started DL: {0} @ {1}\n" , url , dt1 );
					   }

					   var res = new WebClient().DownloadData( url );

					   var dt2 = DateTime.Now;

					   lock ( _sb )
					   {
						   _sb.AppendFormat( "Finished DL: {0} @ {1}\tElapsed: {2}\n" , url , dt2 , dt2 - dt1 );
					   }

					   return res;
				   };
		}

		public static void TestTasks()
		{
			var tokenSrc = new CancellationTokenSource();
			var token = tokenSrc.Token;

			var f = new TaskFactory<byte[]>( token );
			var tasks = new Task<byte[]>[ _NUM_DAYS ];

			_sb.Clear();

			for ( int i = 0 ; i < _NUM_DAYS ; i++ )
			{
				var today = DateTime.Today.AddDays( -_NUM_DAYS + i + 1 );
				tasks[ i ] = f.StartNew( GetDownloader( String.Format( _URL_FORMAT , today.Month , today.Day , today.Year % 100 ) ) );
			}

			Task.WaitAll( tasks , token );

			for ( int i = 0 ; i < tasks.Length ; i++ )
			{
				var t = tasks[ i ];
				switch ( t.Status )
				{
					case TaskStatus.RanToCompletion:
						File.WriteAllBytes( i.ToString() , tasks[ i ].Result );
						break;

					case TaskStatus.Faulted:
						File.WriteAllBytes( String.Format( "{0} - failed" , i ) , new byte[ 0 ] );
						break;

					default:
						break;
				}
			}

			string s = _sb.ToString();
			File.WriteAllText( "dl.log" , s );
		}
	}
}
