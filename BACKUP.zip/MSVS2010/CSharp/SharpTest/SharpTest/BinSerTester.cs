﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace SharpTest
{
	internal static class BinSerTester
	{
		[Serializable]
		public class Data
		{
			private readonly int _intData;
			private readonly string _strData;
			private readonly object _someData;

			public Data( int iData , string sData , object someData )
			{
				_intData = iData;
				_strData = sData;
				_someData = someData;
			}

			public Data( int iData , string sData , params object[] someData )
				: this( iData , sData , someData as object )
			{
			}

			public int Int { get { return _intData; } }
			public string String { get { return _strData; } }
			public object Object { get { return _someData; } }

			public byte[] ToBinary()
			{
				using ( var ms = new MemoryStream() )
				{
					new BinaryFormatter().Serialize( ms , this );
					return ms.ToArray();
				}
			}

			public static Data FromBinary( byte[] data )
			{
				using ( var ms = new MemoryStream( data ) )
				{
					return ( Data ) new BinaryFormatter().Deserialize( ms );
				}
			}
		}

		public static void Test()
		{
			Data data = new Data( 19 , "Something" , new Action(Test) );
			byte[] bin = data.ToBinary();
			File.WriteAllBytes( @"C:\Temp\!data.bin" , bin );
			Data data2 = Data.FromBinary( bin );
			Data data3 = new Data( 42 , new string( 'Ы' , 200 ) , data , data2 , new Tuple<bool , bool>( false , true ) );
			byte[] bin2 = data3.ToBinary();
			File.WriteAllBytes( @"C:\Temp\!data2.bin" , bin2 );
			Data data4 = Data.FromBinary( bin2 );
		}
	}
}
