﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Globalization;
using System.Linq;
using System.Text;

namespace SharpTest
{
	internal struct ComplexContracter
	{
		private readonly double _real;
		private readonly double _img;

		public ComplexContracter( double real , double img )
		{
			_real = real;
			_img = img;
		}

		public double Real
		{
			get
			{
				return _real;
			}
		}

		public double Imaginary
		{
			get
			{
				return _img;
			}
		}

		public double Radius
		{
			get
			{
				return Abs( this );
			}
		}

		public double Angle
		{
			get
			{
				Contract.Requires( _real != 0.0 || _img != 0.0 );
				return Math.Atan2( _img , _real );
			}
		}

		[ContractInvariantMethod]
		private void Invariant()
		{
			Contract.Invariant( !Double.IsInfinity( _real ) && !Double.IsNaN( _real ) );
			Contract.Invariant( !Double.IsInfinity( _img ) && !Double.IsNaN( _img ) );
		}


		public static double Abs( ComplexContracter complex )
		{
			return Math.Sqrt( complex._real * complex._real + complex._img * complex._img );
		}

		public static ComplexContracter Divide( ComplexContracter c1 , ComplexContracter c2 )
		{
			Contract.Requires( c2.Radius != 0.0 );

			double a = c1.Real;
			double b = c1.Imaginary;
			double c = c2.Real;
			double d = c2.Imaginary;

			double bottom = ( c * c + d * d );

			double x = ( a * c + b * d ) / bottom;
			double y = ( b * c - a * d ) / bottom;

			return new ComplexContracter( x , y );
		}

		public override string ToString()
		{
			return string.Format( CultureInfo.CurrentCulture , "({0}, {1})" , new object[] { this._real , this._img } );
		}

		public static ComplexContracter operator /( ComplexContracter c1 , ComplexContracter c2 )
		{
			return Divide( c1 , c2 );
		}

		public static void Test()
		{
			var cplx1 = new ComplexContracter( 1.0 , 2.0 );
			var cplx2 = new ComplexContracter( 3.0 , 1.0 );
			var cplx3 = new ComplexContracter();

			var cplx = cplx1 / cplx2;
			Console.WriteLine( cplx );

			cplx = cplx1 / cplx3;
			Console.WriteLine( cplx );
		}
	}
}
