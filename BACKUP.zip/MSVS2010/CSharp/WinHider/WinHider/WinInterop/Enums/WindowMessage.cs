﻿
namespace WinHider.WinInterop.Enums
{
	internal enum WindowMessage
	{
		WM_HOTKEY = 0x0312
	}
}
