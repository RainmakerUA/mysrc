﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using WinHider.WinInterop.Enums;

namespace WinHider.WinInterop
{
	internal sealed class NativeWindow : INotifyPropertyChanged
	{
		private readonly IntPtr _handle;

		private NativeWindow( IntPtr handle )
		{
			_handle = handle;
		}

		public IntPtr Hanlde { get { return _handle; } }

		public NativeWindow Parent
		{
			get
			{
				IntPtr parent = NativeMethods.GetParent( _handle );
				return parent != IntPtr.Zero ? new NativeWindow( parent ) : null;
			}
		}

		public string Text
		{
			get
			{
				int textLength = NativeMethods.GetWindowTextLength( _handle );
				var sb = new StringBuilder( textLength + 1 );
				int res = NativeMethods.GetWindowText( _handle , sb , textLength + 1 );
				return sb.ToString();
			}
		}

		public string ClassName
		{
			get
			{
				var sb = new StringBuilder( 256 );
				int res = NativeMethods.GetClassName( _handle , sb , sb.Capacity );
				return sb.ToString();
			}
		}

		public ICollection<NativeWindow> Children
		{
			get
			{
				var children = new List<NativeWindow>();
				NativeMethods.EnumChildWindows( _handle ,
						( hWnd , lParam ) =>
						{
							var win = new NativeWindow( hWnd );
							if ( Equals( win.Parent ) )
							{
								children.Add( win );
							}
							return true;
						} , IntPtr.Zero
					);

				return children;
			}
		}

		public bool IsEnabled
		{
			get { return !Style.HasFlag( WindowStyles.WS_DISABLED ); }
			set { NativeMethods.EnableWindow( _handle , value ); }
		}

		public bool IsVisible
		{
			get { return Style.HasFlag( WindowStyles.WS_VISIBLE ); }
			set
			{
				if ( value != NativeMethods.ShowWindow( _handle , ( int ) ( value ? ShowWindow.SW_SHOWNA : ShowWindow.SW_HIDE ) ) )
				{
					RaisePropertyChanged( "IsVisible" );
				}
			}
		}

		public WindowStyles Style
		{
			get
			{
				return ( WindowStyles ) NativeMethods.GetWindowLong( _handle , ( int ) WindowLong.GWL_STYLE );
			}
		}

		public WindowStylesEx ExStyle
		{
			get
			{
				return ( WindowStylesEx ) NativeMethods.GetWindowLong( _handle , ( int ) WindowLong.GWL_EXSTYLE );
			}
		}

		public static NativeWindow DesktopWindow
		{
			get
			{
				return new NativeWindow( NativeMethods.GetDesktopWindow() );
			}
		}

		public static IEnumerable<NativeWindow> EnumWindows( Predicate<NativeWindow> predicate = null )
		{
			var windows = new List<NativeWindow>();

			NativeMethods.EnumWindows( ( hWnd , lParam ) =>
				{
					var win = new NativeWindow( hWnd );
					if ( predicate == null || predicate( win ) )
					{
						windows.Add( win );
					}
					return true;
				} ,
			IntPtr.Zero );

			return windows;
		}

		#region Overrides

		public bool Equals( NativeWindow window )
		{
			return window != null && _handle == window._handle;
		}

		public override bool Equals( object obj )
		{
			return Equals( obj as NativeWindow );
		}

		public override int GetHashCode()
		{
			return _handle.GetHashCode();
		}

		public override string ToString()
		{
			return String.Format( "Window (0x{0:X8})[{1}]: '{2}'" , _handle.ToInt64() , ClassName , Text );
		}

		#endregion

		private void RaisePropertyChanged( string name )
		{
			var handler = PropertyChanged;
			if ( handler != null )
			{
				handler( this , new PropertyChangedEventArgs( name ) );
			}
		}

		#region Implementation of INotifyPropertyChanged

		public event PropertyChangedEventHandler PropertyChanged;

		#endregion
	}
}
