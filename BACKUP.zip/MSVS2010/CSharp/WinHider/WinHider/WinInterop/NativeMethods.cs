﻿using System;
using System.Runtime.InteropServices;
using System.Text;
using WinHider.WinInterop.Enums;

namespace WinHider.WinInterop
{
	internal static class NativeMethods
	{
		[DllImport( "user32.dll" , SetLastError = true )]
		public static extern bool RegisterHotKey( IntPtr hWnd , int id , KeyModifiers fsModifiers , int vk );

		[DllImport( "user32.dll" , SetLastError = true )]
		public static extern bool UnregisterHotKey( IntPtr hWnd , int id );


		[DllImport( "user32.dll" )]
		public static extern bool EnableWindow( IntPtr hWnd , bool bEnable );

		[DllImport( "user32.dll" )]
		[return: MarshalAs( UnmanagedType.Bool )]
		public static extern bool EnumChildWindows( IntPtr hwndParent , EnumWindowsProc lpEnumFunc , IntPtr lParam );

		[DllImport( "user32.dll" )]
		[return: MarshalAs( UnmanagedType.Bool )]
		public static extern bool EnumWindows( EnumWindowsProc lpEnumFunc , IntPtr lParam );

		[DllImport( "user32.dll" , SetLastError = true , CharSet = CharSet.Unicode )]
		public static extern int GetClassName( IntPtr hWnd , StringBuilder lpClassName , int nMaxCount );

		[DllImport( "user32.dll" , SetLastError = false )]
		public static extern IntPtr GetDesktopWindow();

		[DllImport( "user32.dll" , ExactSpelling = true , CharSet = CharSet.Auto )]
		public static extern IntPtr GetParent( IntPtr hWnd );

		[DllImport( "user32.dll" , SetLastError = true )]
		public static extern int GetWindowLong( IntPtr hWnd , int nIndex );

		[DllImport( "user32.dll" , CharSet = CharSet.Unicode , SetLastError = true )]
		public static extern int GetWindowText( IntPtr hWnd , StringBuilder lpString , int nMaxCount );

		[DllImport( "user32.dll" , SetLastError = true , CharSet = CharSet.Unicode )]
		public static extern int GetWindowTextLength( IntPtr hWnd );

		[DllImport( "user32.dll" )]
		public static extern bool ShowWindow( IntPtr hWnd , int nCmdShow );

		public delegate bool EnumWindowsProc( IntPtr hWnd , IntPtr lParam );
	}
}
