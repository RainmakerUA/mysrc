﻿using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using Hardcodet.Wpf.TaskbarNotification;
using WinHider.Windows;
using WinHider.WinInterop;
using WinHider.WinInterop.Enums;

namespace WinHider
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
		private TaskbarIcon _taskBarIcon;
		private HotKey _hotkey;
		private PopupWindow _popup;

		protected override void OnStartup( StartupEventArgs e )
		{
			base.OnStartup( e );
			
			var msgWin = new MessageWindow();
			msgWin.Show();

			_taskBarIcon = ( TaskbarIcon ) Resources[ "trayIcon" ];
			_hotkey = new HotKey( ModifierKeys.Windows , VirtualKey.VK_OEM_3 , msgWin );
			_popup = new PopupWindow();
			OnRefreshWindows( this , new RoutedEventArgs() );
			_hotkey.HotKeyPressed += _popup.ShowPopup;
		}

		private void OnRefreshWindows( object sender , RoutedEventArgs e )
		{
			if ( _popup != null )
			{
				var handle = new WindowInteropHelper( _popup ).EnsureHandle();
				_popup.DataContext = NativeWindow.EnumWindows( DefaultFilter );
			}
		}

		//private void OnSettings( object sender , RoutedEventArgs e )
		//{
		//    SettingsWindow.Show( 0 );
		//}

		private void OnAbout( object sender , RoutedEventArgs e )
		{
			MessageBox.Show( "[RM®] Window Hider" , "About..." , MessageBoxButton.OK , MessageBoxImage.Information );
		}

		private void OnExit( object sender , RoutedEventArgs e )
		{
			Shutdown();
		}

		private static bool DefaultFilter( NativeWindow win )
		{
			return win.IsVisible && win.Parent == null && win.Text.Length > 0 && !win.ClassName.Equals( "BasicWindow" );
		}
	}
}
