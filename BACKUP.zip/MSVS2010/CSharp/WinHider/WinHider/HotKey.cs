﻿using System;
using System.Diagnostics.Contracts;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using WinHider.WinInterop;
using WinHider.WinInterop.Enums;

namespace WinHider
{
	internal sealed class HotKey : IDisposable
	{
		private readonly int _id;
		private readonly IntPtr _handle;
		private readonly VirtualKey _key;
		private readonly ModifierKeys _keyModifier;

		private bool _isKeyRegistered;
		private bool _isDisposed = false;

		public HotKey( ModifierKeys modifierKeys , VirtualKey key , Window window )
			: this( modifierKeys , key , new WindowInteropHelper( window ) )
		{
			Contract.Requires( window != null );
		}

		private HotKey( ModifierKeys modifierKeys , VirtualKey key , WindowInteropHelper window )
			: this( modifierKeys , key , window.Handle )
		{
			Contract.Requires( window != null );
		}

		public HotKey( ModifierKeys modifierKeys , VirtualKey key , IntPtr windowHandle )
		{
			Contract.Requires( modifierKeys != ModifierKeys.None || key != VirtualKey.VK_NONE );
			Contract.Requires( windowHandle != IntPtr.Zero );

			_key = key;
			_keyModifier = modifierKeys;
			_id = GetHashCode();
			_handle = windowHandle;
			RegisterHotKey();
			ComponentDispatcher.ThreadPreprocessMessage += ThreadPreprocessMessageMethod;
		}

		#region Disposal

		~HotKey()
		{
			Dispose( false );
		}

		private void Dispose( bool disposing )
		{
			if ( !_isDisposed )
			{
				if ( disposing )
				{
					// Dispose managed.
				}

				// Dispose unmanaged
				ComponentDispatcher.ThreadPreprocessMessage -= ThreadPreprocessMessageMethod;
				UnregisterHotKey();

				_isDisposed = true;
			}
		}

		public void Dispose()
		{
			Dispose( true );
			GC.SuppressFinalize( this );
		}

		#endregion

		public VirtualKey Key
		{
			get
			{
				return _key;
			}
		}

		public ModifierKeys KeyModifier
		{
			get
			{
				return _keyModifier;
			}
		}

		public void RegisterHotKey()
		{
			if ( Key == VirtualKey.VK_NONE )
				return;
			if ( _isKeyRegistered )
				UnregisterHotKey();
			_isKeyRegistered = NativeMethods.RegisterHotKey( _handle , _id , ( KeyModifiers ) KeyModifier , ( int ) Key );
			if ( !_isKeyRegistered )
				throw new ApplicationException( "Hotkey already in use" );
		}

		public void UnregisterHotKey()
		{
			_isKeyRegistered = !NativeMethods.UnregisterHotKey( _handle , _id );
		}

		private void ThreadPreprocessMessageMethod( ref MSG msg , ref bool handled )
		{
			if ( !handled )
			{
				if ( msg.message == ( int ) WindowMessage.WM_HOTKEY
					&& ( int ) ( msg.wParam ) == _id )
				{
					OnHotKeyPressed();
					handled = true;
				}
			}
		}

		private void OnHotKeyPressed()
		{
			var handler = HotKeyPressed;
			if ( handler != null )
			{
				handler( this , EventArgs.Empty );
			}
		}

		public event EventHandler HotKeyPressed;
	}
}
