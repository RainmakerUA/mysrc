﻿using System.Diagnostics.Contracts;
using System.Windows;

namespace WinHider.Windows
{
	public partial class SettingsWindow : Window
	{
		private static SettingsWindow _window;

		private SettingsWindow()
		{
			InitializeComponent();
			//mainMenu.DataContext = new object[] { new { Text = "[ROOT]" , Children = NativeWindow.EnumWindows( win => win.Parent == null && win.IsVisible ) } };
		}

		private static SettingsWindow Window
		{
			get
			{
				Contract.Ensures( _window != null );

				if ( _window == null )
				{
					_window = new SettingsWindow();
				}

				return _window;
			}
		}

		public static bool Show( object settings )
		{
			Contract.Requires( settings != null );

			var win = Window;
			win.DataContext = settings;

			var result = win.ShowDialog();
			// restore or... settings
			return result.HasValue && result.Value;
		}

		private void OnOK( object sender , RoutedEventArgs e )
		{
			DialogResult = true;
		}
	}
}
