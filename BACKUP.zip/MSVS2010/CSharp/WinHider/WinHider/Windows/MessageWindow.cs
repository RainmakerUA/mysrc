﻿using System;
using System.Windows;

namespace WinHider.Windows
{
	internal sealed class MessageWindow : Window
	{
		public MessageWindow()
		{
			WindowStartupLocation = WindowStartupLocation.Manual;
			Left = -100;
			Top = -100;
			Width = 0;
			Height = 0;
			WindowStyle = WindowStyle.None;
			ShowInTaskbar = false;
			ShowActivated = false;
		}

		protected override void OnActivated( EventArgs e )
		{
			base.OnActivated( e );
			Hide();
		}
	}
}
