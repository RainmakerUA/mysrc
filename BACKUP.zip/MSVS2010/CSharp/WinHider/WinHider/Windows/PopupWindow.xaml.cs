﻿using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using WinHider.WinInterop;

namespace WinHider.Windows
{
	/// <summary>
	/// Interaction logic for PopupWindow.xaml
	/// </summary>
	public partial class PopupWindow : Window
	{
		private static Matrix? _mDpi;

		public PopupWindow()
		{
			InitializeComponent();
		}

		protected override void OnKeyUp( KeyEventArgs e )
		{
			base.OnKeyUp( e );

			if ( e.Key == Key.Escape )
			{
				Close();
			}
		}

		protected override void OnPropertyChanged( DependencyPropertyChangedEventArgs e )
		{
			base.OnPropertyChanged( e );

			if ( e.Property == ActualWidthProperty || e.Property == ActualHeightProperty )
			{
				var screenEnd = PixelsToUnits( new Point(
					SystemParameters.PrimaryScreenWidth ,
					SystemParameters.PrimaryScreenHeight
				) );

				var screenW = screenEnd.X;
				var screenH = screenEnd.Y;
				var winW = ActualWidth;
				var winH = ActualHeight;

				Left = ( screenW - winW ) / 2;
				Top = ( screenH - winH ) / 2;
			}
		}
		protected override void OnDeactivated( EventArgs e )
		{
			base.OnDeactivated( e );
			Close();
		}

		protected override void OnClosing( CancelEventArgs e )
		{
			base.OnClosing( e );

			if ( !e.Cancel )
			{
				e.Cancel = true;
				Hide();
			}
		}

		private void OnButtonClick( object sender , RoutedEventArgs e )
		{
			var btn = e.OriginalSource as FrameworkElement;
			if ( btn != null )
			{
				var win = btn.DataContext as NativeWindow;
				if ( win != null )
				{
					win.IsVisible = !win.IsVisible;
				}

				Close();
			}
		}

		public void ShowPopup( object sender , EventArgs e )
		{
			if ( !IsVisible )
			{
				Show();
			}
		}

		private Point PixelsToUnits( Point pixels )
		{
			if ( !_mDpi.HasValue )
			{
				PresentationSource ps;
				if ( ( ps = PresentationSource.FromVisual( this ) ) != null )
				{
					_mDpi = ps.CompositionTarget.TransformToDevice;
				}
			}

			Matrix m = _mDpi.Value;
			return new Point( pixels.X / m.M11 , pixels.Y / m.M22 );
		}
	}
}
