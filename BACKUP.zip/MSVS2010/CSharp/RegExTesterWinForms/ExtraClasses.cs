﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace RegExTester
{
	public class EncodingWrapper
	{
		private readonly Encoding _encoding;

		public Encoding EncodingValue
		{
			get { return _encoding; }
		}

		public EncodingWrapper(Encoding encodingData)
		{
			_encoding = encodingData;
		}

		public override string ToString()
		{
			return _encoding.EncodingName;
		}
	}

	public sealed class GroupItem
	{
		private int Index
		{ get; set; }

		private string Name
		{ get; set; }

		public string Text
		{ get; private set; }

		public int StartIndex
		{ get; private set; }

		public int TextLength
		{ get; private set; }

		private GroupItem(int index, string name, Group group)
		{
			Index = index;
			Name = name;
			Text = group.Value;
			StartIndex = group.Index;
			TextLength = group.Length;
		}

		public override string ToString()
		{
			return String.Format("Group #{0:D} «{1}»: {2}", Index, Name, Text);
		}

		public static ReadOnlyCollection<GroupItem> GroupCollectionToItemList(Regex re, GroupCollection groupCollection)
		{
			var list = new List<GroupItem>();
			for (int i = 0; i < groupCollection.Count; i++)
			{
				Group grp = groupCollection[i];
				string name = re.GroupNameFromNumber(i);
				list.Add(
						new GroupItem(i, name, grp)
					);
			}

			return list.AsReadOnly();
		}
	}

	public sealed class MatchItem
	{
		public string Text
		{ get; private set; }

		public int StartIndex
		{ get; private set; }

		public int TextLength
		{ get; private set; }

		public ReadOnlyCollection<GroupItem> Groups
		{ get; private set; }

		private MatchItem(Regex re, Match match)
		{
			Text = match.Value;
			StartIndex = match.Index;
			TextLength = match.Length;
			Groups = GroupItem.GroupCollectionToItemList(re, match.Groups);
		}

		public override string ToString()
		{
			return String.Format("Match: {0}", Text);
		}

		public static ReadOnlyCollection<MatchItem> MatchCollectionToItemList(Regex re, MatchCollection matchCollection)
		{
			var list = new List<MatchItem>();
			for (int i = 0; i < matchCollection.Count; i++)
			{
				list.Add(
						new MatchItem(re, matchCollection[i])
					);
			}

			return list.AsReadOnly();
		}
	}

	public enum TextSourceType { Url, File, Clipboard };

	[Serializable]
	public class SaveState
	{
		public string Regex
		{ get; set; }

		public int[] RegexOptions
		{ get; set; }

		public string TextSource
		{ get; set; }

		public TextSourceType SourceType
		{ get; set; }

		public int EncodingIndex
		{ get; set; }

		public string Text
		{ get; set; }
	}
}