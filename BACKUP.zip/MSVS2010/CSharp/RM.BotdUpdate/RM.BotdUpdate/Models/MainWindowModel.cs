﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RM.BotdUpdate.Helpers;
using RM.BotdUpdate.Properties;

namespace RM.BotdUpdate.Models
{
	internal class MainWindowModel : INotifyPropertyChanged
	{
		private static MainWindowModel _instance;

		private DateTime _date;
		private int _fileCount;
		private ObservableCollection<TaskModel> _tasks;

		private MainWindowModel()
		{
		}

		public static MainWindowModel Instance
		{
			get { return Start( Settings.Default ); }
		}

		public DateTime Date
		{
			get
			{
				return _date;
			}

			private set
			{
				_date = value;
				this.RaisePropertyChanged( () => Date , PropertyChanged );
			}
		}

		public int FileCount
		{
			get
			{
				return _fileCount;
			}

			set
			{
				_fileCount = value;
				this.RaisePropertyChanged( () => FileCount , PropertyChanged );
			}
		}

		public ObservableCollection<TaskModel> Tasks
		{
			get
			{
				return _tasks;
			}

			private set
			{
				_tasks = value;
				this.RaisePropertyChanged( () => Tasks , PropertyChanged );
			}
		}

		public static MainWindowModel Start( Settings settings )
		{
			if ( _instance == null )
			{
				var formats = settings.UrlFormats;
				var days = settings.DaysCount;
				var path = settings.ImgPath;
				var log = settings.LogFile;
				var sleep = settings.Sleep;

				_instance = new MainWindowModel
					{
						Date = DateTime.Today ,
						FileCount = formats.Count * days ,
						Tasks = new ObservableCollection<TaskModel>()
					};

				Parallel.For( 0 , days ,
						i => { var s = i.ToString(); _instance.Tasks.Add( new TaskModel() ); }
					);
			}

			return _instance;
		}

		public event PropertyChangedEventHandler PropertyChanged;
	}
}
