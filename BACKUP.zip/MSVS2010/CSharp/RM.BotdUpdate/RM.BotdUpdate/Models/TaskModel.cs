﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RM.BotdUpdate.Helpers;

namespace RM.BotdUpdate.Models
{
	internal class TaskModel : INotifyPropertyChanged
	{
		private Task _task;

		public Task Task
		{
			get
			{
				return _task;
			}

			set
			{
				_task = value;
				_task.ContinueWith( SetStateIcon );
				this.RaisePropertyChanged( () => Task , PropertyChanged );
			}
		}



		private void SetStateIcon(Task task)
		{
			
		}

		public event PropertyChangedEventHandler PropertyChanged;
	}
}
