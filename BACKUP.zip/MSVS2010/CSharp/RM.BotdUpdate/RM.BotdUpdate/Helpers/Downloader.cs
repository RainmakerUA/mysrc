﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RM.BotdUpdate.Helpers
{
	internal static class Downloader
	{
		public static void DownloadFile( string url )
		{

		}
	}
}
