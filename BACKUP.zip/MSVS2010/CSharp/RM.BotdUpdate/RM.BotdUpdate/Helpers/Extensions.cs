﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace RM.BotdUpdate.Helpers
{
	internal static class Extensions
	{
		/// <summary>
		/// Raises PropertyChanged event for a property specified by expression.
		/// </summary>
		/// <typeparam name="T">Property value type.</typeparam>
		/// <param name="sender">Event sender object.</param>
		/// <param name="property">Changed property expression.</param>
		/// <param name="handler">Event handler delegate.</param>
		/// <exception cref="T:System.NotSupportedException">Thrown when <paramref name="property"/> is not property expression.</exception>
		public static void RaisePropertyChanged<T>( this INotifyPropertyChanged sender , Expression<Func<T>> property , PropertyChangedEventHandler handler )
		{
			var handlerCopy = handler;

			if ( handlerCopy != null )
			{
				var expression = property.Body as MemberExpression;
				if ( expression == null )
				{
					throw new NotSupportedException( "Invalid expression passed. Only property member should be selected." );
				}

				handlerCopy( sender , new PropertyChangedEventArgs( expression.Member.Name ) );
			}
		}

	}
}
