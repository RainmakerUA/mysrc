﻿using System.Windows;

namespace RM.ServiceController
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
		protected override void OnExit(ExitEventArgs e)
		{
			base.OnExit(e);
			Settings.SettingsManager.Current.Save();
		}
	}
}
