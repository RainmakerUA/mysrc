﻿
namespace RM.ServiceController.Common
{
	public enum UpdateRate
	{
		NotSet = -1,
		
		[EnumValueDescription("Very High (100ms)")]
		VeryHigh = 100,

		[EnumValueDescription("High (500ms)")]
		High = 500,

		[EnumValueDescription("Normal (1s)")]
		Normal = 1000,

		[EnumValueDescription("Low (5s)")]
		Low = 5000
	}
}
