﻿using System;
using System.ComponentModel;
using System.Diagnostics;

namespace RM.ServiceController.Common
{
	internal static class Extensions
	{
		public static void Raise(this PropertyChangedEventHandler handler, object sender)
		{
			const string setPrefix = "set_";

			if (handler != null)
			{
				var stackTrace = new StackTrace();
				var callerName = stackTrace.GetFrame(1).GetMethod().Name;

				if (!callerName.StartsWith(setPrefix))
				{
					throw new NotSupportedException("PropertyChangedEventHandler.Raise must be caller from a property setter!");
				}

				handler(sender, new PropertyChangedEventArgs(callerName.Substring(setPrefix.Length)));
			}
		}
	}
}
