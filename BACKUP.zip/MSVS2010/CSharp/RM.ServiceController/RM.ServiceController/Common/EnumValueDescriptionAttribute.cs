﻿using System;

namespace RM.ServiceController.Common
{
	[AttributeUsage(AttributeTargets.Field)]
	internal class EnumValueDescriptionAttribute : Attribute
	{
		private readonly string _description;

		public EnumValueDescriptionAttribute(string description)
		{
			_description = description;
		}

		public string Description
		{
			get { return _description; }
		}
	}
}
