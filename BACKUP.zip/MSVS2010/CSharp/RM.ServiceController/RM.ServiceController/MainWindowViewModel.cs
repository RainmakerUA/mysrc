﻿using System.ComponentModel;
using RM.ServiceController.Common;
using RM.ServiceController.Settings;

namespace RM.ServiceController
{
	public class MainWindowViewModel : INotifyPropertyChanged
	{
		private AppSettings _settings;



		public AppSettings Settings
		{
			get { return _settings; }
			set
			{
				_settings = value;
				PropertyChanged.Raise(this);
			}
		}


		//private 

		public event PropertyChangedEventHandler PropertyChanged;
	}
}
