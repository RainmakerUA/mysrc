﻿using System;
using System.ComponentModel;
using RM.ServiceController.Common;

namespace RM.ServiceController.Settings
{
	public sealed class AppSettings : INotifyPropertyChanged, ICloneable
	{
		private double _windowLeft;
		private double _windowTop;
		private double _windowWidth;
		private double _windowHeigth;
		private UpdateRate _updateRate;
		private string[] _services = new string[0];

		public double WindowLeft
		{
			get { return _windowLeft; }
			set
			{
				_windowLeft = value;
				PropertyChanged.Raise(this);
			}
		}

		public double WindowTop
		{
			get { return _windowTop; }
			set
			{
				_windowTop = value;
				PropertyChanged.Raise(this);
			}
		}

		public double WindowWidth
		{
			get { return _windowWidth; }
			set
			{
				_windowWidth = value;
				PropertyChanged.Raise(this);
			}
		}

		public double WindowHeigth
		{
			get { return _windowHeigth; }
			set
			{
				_windowHeigth = value;
				PropertyChanged.Raise(this);
			}
		}

		public UpdateRate UpdateRate
		{
			get { return _updateRate; }
			set
			{
				_updateRate = value;
				PropertyChanged.Raise(this);
			}
		}

		public string[] Services
		{
			get { return _services; }
			set
			{
				_services = value ?? new string[0];
				PropertyChanged.Raise(this);
			}
		}

		public object Clone()
		{
			throw new NotImplementedException();
			return new AppSettings
					{

					};
		}

		internal static AppSettings FromDefault()
		{
			var def = Properties.DefaultSettings.Default;
			return new AppSettings
					{
						_windowLeft = def.WindowLeft,
						_windowTop = def.WindowTop,
						_windowWidth = def.WindowWidth,
						_windowHeigth = def.WindowHeight
					};
		}

		public event PropertyChangedEventHandler PropertyChanged;
	}
}
