﻿using System;
using System.IO;
using System.Reflection;
using System.Xml.Serialization;

namespace RM.ServiceController.Settings
{
	internal sealed class SettingsManager
	{
		#region Fields

		private const string _ext = ".config";
		private static readonly Type _settingsType = typeof(AppSettings);
		private static readonly object _syncRootStatic = new object();
		private static readonly AppSettings _defaultSettings;
		private static readonly string _currentSettingsFilename;
		private static volatile SettingsManager _current;

		private readonly object _syncRoot = new object();
		private readonly string _fileName;
		private volatile AppSettings _settings;

		#endregion

		#region Constructors

		static SettingsManager()
		{
			var asm = Assembly.GetEntryAssembly();
			var exeName = asm != null ? asm.Location : Path.Combine(Environment.CurrentDirectory, "test.exe");
			_currentSettingsFilename = Path.ChangeExtension(exeName, _ext);
			_defaultSettings = AppSettings.FromDefault();
		}

		private SettingsManager(string fileName)
		{
			_fileName = fileName;
		}

		#endregion

		#region Properties

		public static SettingsManager Current
		{
			get
			{
				if (_current == null)
				{
					lock (_syncRootStatic)
					{
						if (_current == null)
						{
							_current = new SettingsManager(_currentSettingsFilename);
						}
					}
				}

				return _current;
			}
		}

		public static AppSettings CurrentSettings
		{
			get { return Current.Settings; }
		}

		public AppSettings Settings
		{
			get
			{
				if (_settings == null)
				{
					lock (_syncRoot)
					{
						if (_settings == null)
						{
							_settings = Load(_fileName) ?? _defaultSettings;
						}
					}
				}

				return _settings;
			}
		}

		#endregion

		#region Methods

		public void Reload()
		{
			lock (_syncRoot)
			{
				_settings = Load(_fileName);
			}
		}

		public void Save()
		{
			Save(_settings, _fileName);
		}

		private static AppSettings Load(string filename)
		{
			try
			{
				var ser = new XmlSerializer(_settingsType);
				using (var fs = File.OpenRead(filename))
				{
					return (AppSettings)ser.Deserialize(fs);
				}
			}
			catch (Exception)
			{
				return null;
			}
		}

		private static void Save(AppSettings settings, string filename)
		{
			try
			{
				var ser = new XmlSerializer(_settingsType);
				using (var fs = File.OpenWrite(filename))
				{
					ser.Serialize(fs, settings);
				}
			}
			catch (Exception)
			{
			}
		}

		#endregion
	}
}
