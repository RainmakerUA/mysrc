﻿using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using RM.PictureSplitter.Properties;

namespace RM.PictureSplitter
{
	internal static class Program
	{
		private static void PrintWait(string message)
		{
			Console.WriteLine(message);
			Console.WriteLine("Press any key...");
			Console.ReadKey(true);
		}

		private static void PrintWait(string format, params object[] args)
		{
			PrintWait(String.Format(format, args));
		}

		private static void PrintUsage()
		{
			PrintWait(
@"Usage:
{0} <source-file> [<target-dir>]
  <source-file> - file to be splitted
  <target-dir> - directory for resulting files (optional, default is source-file directory)
Current settings ({1}):
  SourceWidth: {2}
  SourceHeight: {3}
  CountX: {4}
  CountY: {5}
  SliceWidth: {6}
  SliceHeight: {7}
",
						Path.GetFileName(Assembly.GetExecutingAssembly().Location),
						ValidateSettings(Settings.Default) ? "valid" : "invalid",
						Settings.Default.SourceWidth,
						Settings.Default.SourceHeight,
						Settings.Default.CountX,
						Settings.Default.CountY,
						Settings.Default.SliceWidth,
						Settings.Default.SliceHeight
				);
		}

		private static bool ValidateSettings(Settings settings)
		{
			var restX = settings.SourceWidth - settings.CountX * settings.SliceWidth;
			var restY = settings.SourceHeight - settings.CountY * settings.SliceHeight;

			return restX >= 0 && restX % (settings.CountX - 1) == 0
				   && restY >= 0 && restY % (settings.CountY - 1) == 0;
		}

		private static string GetSliceFileName(int x, int y, int maxX, int maxY)
		{
			var digitsX = maxX / 10 + 1;
			var digitsY = maxY / 10 + 1;
			var preformat = String.Format("{{0:D{0}}}_{{1:D{1}}}", digitsY, digitsX);

			return String.Format(preformat, y, x);
		}

		private static void Main(string[] args)
		{
			if (args.Length < 1 || args.Length > 2)
			{
				PrintUsage();
				return;
			}

			var sourceFile = args[0];
			var targetDir = args.Length == 2 ? args[1] : Path.GetDirectoryName(sourceFile) ?? Environment.CurrentDirectory;

			if (!File.Exists(sourceFile))
			{
				PrintWait("File '{0}' does not exist!", sourceFile);
				return;
			}

			if (!Directory.Exists(targetDir))
			{
				PrintWait("Directory '{0}' does not exist!", targetDir);
				return;
			}

			var settings = Settings.Default;
			if (!ValidateSettings(settings))
			{
				PrintWait("Settings are not valid! Please correct them!");
				return;
			}

			var sourceWidth = settings.SourceWidth;
			var sourceHeight = settings.SourceHeight;
			var countX = settings.CountX;
			var countY = settings.CountY;
			var sliceWidth = settings.SliceWidth;
			var sliceHeight = settings.SliceHeight;

			var stepX = countX > 1 ? (sourceWidth % sliceWidth) / (countX - 1) : 0;
			var stepY = countY > 1 ? (sourceHeight % sliceHeight) / (countY - 1) : 0;

			var image = new Bitmap(sourceFile);
			if (image.Width != sourceWidth || image.Height != sourceHeight)
			{
				PrintWait("Source image must have following dimensions: {0}x{1}", sourceWidth, sourceHeight);
				return;
			}

			for (int y = 0; y < countY; y++)
			{
				for (int x = 0; x < countX; x++)
				{
					var rect = new Rectangle(x * (sliceWidth + stepX), y * (sliceHeight + stepY), sliceWidth, sliceHeight);
					var imgSlice = image.Clone(rect, image.PixelFormat);
					imgSlice.Save(Path.Combine(targetDir, GetSliceFileName(x, y, countX - 1, countY - 1) + Path.GetExtension(sourceFile)));
				}
			}

			PrintWait("Splitting completed successfully");
		}
	}
}
