using System;
using System.IO;
using System.IO.Compression;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Reflection;

namespace RMLib
{
    /// <summary>
    /// Provides XML serialization with gzip compression.
    /// </summary>
    public static class XmlZ
    {
        public class XmlZException : Exception
        {
            public XmlZException()
                : base( "XmlZ exception thrown!" )
            {
                // Do nothing.
            }

            public XmlZException( string message )
                : base( message )
            {
                // Do nothing.
            }

            public XmlZException( string message , Exception innerException )
                : base( message , innerException )
            {
                // Do nothing.
            }

            protected XmlZException( SerializationInfo info , StreamingContext context )
                : base( info , context )
            {
                // Do nothing.
            }
        }

        public static void Serialize<T>( this T obj , string filename ) //where T : new()
        {
            Serialize<T>( obj , filename , true );
        }

        public static void Serialize<T>( this T obj , string filename , bool overwrite ) //where T : new()
        {
            FileStream fs;
            GZipStream cs;
            XmlSerializer ser;

            if ( String.IsNullOrEmpty( filename ) )
            {
                throw new ArgumentException( "Filename cannot be null or empty!" , "filename" );
            }

            if ( File.Exists( filename ) && !overwrite )
            {
                throw new InvalidOperationException( "File already exists. Cannot overwrite it!" );
            }

            try
            {
                using ( fs = File.Open( filename , overwrite ? FileMode.Create : FileMode.CreateNew , FileAccess.Write , FileShare.Read ) )
                {
                    using ( cs = new GZipStream( fs , CompressionMode.Compress ) )
                    {
                        ser = new XmlSerializer( typeof( T ) );
                        ser.Serialize( cs , obj );
                    }
                }
            }
            catch ( Exception e )
            {
                throw new XmlZException( "Serialization failed!" , e );
            }
        }


        public static T Deserialize<T>( string filename ) //where T : new()
        {
            return Deserialize<T>( filename , true );
        }

        public static T Deserialize<T>( string filename , bool useDefault ) //where T : new()
        {
            return (T) Deserialize( typeof( T ) , filename , useDefault );
        }

        public static object Deserialize( Type targetType , string filename , bool useDefault )
        {
            FileStream fs;
            GZipStream cs;
            XmlSerializer ser;
            ConstructorInfo[] ctors;
            ConstructorInfo defCtor;
            object obj;

            if ( String.IsNullOrEmpty( filename ) )
            {
                throw new ArgumentException( "Filename cannot be null or empty!" , "filename" );
            }

            defCtor = null;
            ctors = targetType.GetConstructors( BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic );

            foreach ( var ctor in ctors )
            {
                if ( ctor.GetParameters().Length == 0 )
                {
                    defCtor = ctor;
                    break;
                }
            }

            if ( ctors.Length == 0 || defCtor == null )
            {
                throw new ArgumentException( "TargetType must have default constructor!" , "targetType" );
            }

            if ( !File.Exists( filename ) && useDefault )
            {
                obj = defCtor.Invoke( new object[ 0 ] );
            }
            else
            {
                try
                {
                    using ( fs = File.Open( filename , FileMode.Open , FileAccess.Read , FileShare.Read ) )
                    {
                        using ( cs = new GZipStream( fs , CompressionMode.Decompress ) )
                        {
                            ser = new XmlSerializer( targetType );
                            obj = ser.Deserialize( cs );
                        }
                    }
                }
                catch ( Exception e )
                {
                    if ( useDefault )
                    {
                        obj = defCtor.Invoke( new object[ 0 ] );
                    }
                    else
                    {
                        throw new XmlZException( "Deserialization failed!" , e );
                    }
                }
            }

            return obj;
        }
    }
}
