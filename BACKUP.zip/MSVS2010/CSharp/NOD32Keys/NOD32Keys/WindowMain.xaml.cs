﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using RMLib;

namespace NOD32Keys
{
    public partial class WindowMain : Window
    {
        private const string DATAERROR = "Error!";
        private const string DATALOADING = "Loading...";

        private BackgroundWorker worker;

        public WindowMain()
        {
            InitializeComponent();
            worker = new BackgroundWorker
                {
                    WorkerReportsProgress = false ,
                    WorkerSupportsCancellation = true
                };
            worker.DoWork += LoadData;
            worker.RunWorkerCompleted += OnDataLoaded;
        }

        private void LoadData( object sender , DoWorkEventArgs e )
        {
            try
            {
                e.Result = Key.DownloadFromWeb( Properties.Settings.Default.DefUrl , Properties.Settings.Default.DefRegex ).Take( Properties.Settings.Default.DefMaxCount );
            }
            catch ( Exception )
            {
                e.Result = null;
            }
        }

        private void OnDataLoaded( object sender , RunWorkerCompletedEventArgs e )
        {
            var data = e.Result as IEnumerable<Key>;
            if ( data == null || data.Count() == 0 )
            {
                textBlockLoading.Visibility = Visibility.Visible;
                textBlockLoading.Text = DATAERROR;
            }
            else
            {
                textBlockLoading.Visibility = Visibility.Collapsed;
                foreach ( var key in data )
                {
                    stackPanelList.Children.Add(
                        new LoginPasswordCopy
                        {
                            Login = key.Login ,
                            Password = key.Password ,
                            FontFamily = new FontFamily( "Courier New" )
                        }
                    );
                }
            }
        }

        private void UpdateData()
        {
            if ( !worker.IsBusy )
            {
                stackPanelList.Children.Clear();
                textBlockLoading.Visibility = Visibility.Visible;
                textBlockLoading.Text = DATALOADING;
                worker.RunWorkerAsync();
            }
        }

        private void OnLoaded( object sender , RoutedEventArgs e )
        {
            const string serfile = @"R:\data.xmlz";
            //var b = new BaseSettings( @"..\..\settings.dat" );
            //var bl = new Settings( "bl" ) { date=DateTime.Now, Sites = new Site[] { new Site { Url = "1" , RePattern = "p1" } } , MaxResults = 19 };
            //bl.Serialize( serfile );

            Settings deser = XmlZ.Deserialize( typeof( Settings ) , serfile , true ) as Settings;
            //buttonRefresh_Click( this , e );
        }

        private void buttonRefresh_Click( object sender , RoutedEventArgs e )
        {
            UpdateData();
        }

        private void buttonClose_Click( object sender , RoutedEventArgs e )
        {
            if ( worker.IsBusy )
            {
                worker.CancelAsync();
            }
            Close();
        }
    }
}
