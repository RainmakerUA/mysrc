using System;
using System.IO;
using System.Reflection;

namespace RMLib
{
    public abstract class BaseSettings
    {
        private const string _DEFFILEEXT = "xmlz";

        private readonly string _filename;

        protected BaseSettings()
            : this( null )
        {
            // Do nothing.
        }

        protected BaseSettings( string filename )
        {
            if ( String.IsNullOrEmpty( filename ) )
            {
                _filename = GetDefaultFileName();
            }
            else
            {
                _filename = Path.IsPathRooted( filename ) ? filename : Path.GetFullPath( filename );
            }
        }

        private static string GetDefaultFileName()
        {
            var s = Assembly.GetEntryAssembly().Location;
            return Path.ChangeExtension( s , _DEFFILEEXT );
        }

        protected abstract void Apply( BaseSettings other );

        public virtual void Save()
        {
            this.Serialize( _filename );
        }

        public virtual void Load()
        {
            Load( true );
        }

        public virtual void Load( bool useDefault )
        {
            Apply( XmlZ.Deserialize( GetType() , _filename , useDefault ) as BaseSettings );
        }
    }
}