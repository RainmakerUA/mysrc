﻿using System;
using RMLib;

namespace NOD32Keys
{
    public sealed class Settings : BaseSettings
    {
        private Site[] sites;

        private byte maxResults;
        public DateTime date;

        private Settings()
        {
            // Do nothing.
        }

        public Settings( string filename )
            : this( filename , false )
        {
            // Do nothing.
        }

        public Settings( string filename , bool autoLoad )
            : base( filename )
        {
            if ( autoLoad )
            {
                Load();
            }
        }

        public Site[] Sites
        {
            get { return sites; }
            set { sites = value; }
        }
        public byte MaxResults
        {
            get { return maxResults; }
            set { maxResults = value; }
        }

        protected override void Apply( BaseSettings other )
        {
            Settings otherSettings;

            if ( other is Settings )
            {
                otherSettings = other as Settings;
                
                sites = otherSettings.sites;
                maxResults = otherSettings.maxResults;
            }
        }
    }
}
