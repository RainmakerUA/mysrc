﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Text.RegularExpressions;

namespace NOD32Keys
{
    internal class Key
    {
        public string Login
        {
            get;
            set;
        }

        public string Password
        {
            get;
            set;
        }

        public Key()
            : this( String.Empty , String.Empty )
        {
            // Do nothing.
        }

        public Key( string login , string password )
        {
            Login = login;
            Password = password;
        }

        public override string ToString()
        {
            return String.Format( "{0}: ( Login=\"{1}\",Password=\"{2}\")" , GetType().ToString() , Login , Password );
        }

        public static IEnumerable<Key> DownloadFromWeb( string url , string regex )
        {
            string content = Encoding.UTF8.GetString( ( new WebClient() ).DownloadData( url ) );
            Regex reg = new Regex( regex , RegexOptions.CultureInvariant | RegexOptions.IgnoreCase | RegexOptions.Multiline );
            MatchCollection matches = reg.Matches( content );
            return matches.Cast<Match>().Select( m => new Key( m.Groups[ "login" ].Value , m.Groups[ "passw" ].Value ) );
        }
    }
}
