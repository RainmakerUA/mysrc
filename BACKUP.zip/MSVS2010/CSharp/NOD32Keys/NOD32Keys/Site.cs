﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NOD32Keys
{
    public struct Site
    {
        public string Url;
        public string RePattern;
    }
}
