﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NOD32Keys
{
    /// <summary>
    /// Interaction logic for LoginPasswordCopy.xaml
    /// </summary>
    public partial class LoginPasswordCopy : UserControl
    {
        public static readonly DependencyProperty LoginProperty =
            DependencyProperty.Register( "Login" , typeof( string ) , typeof( LoginPasswordCopy ) ,
            new UIPropertyMetadata( String.Empty , LoginPasswordChanged ) );

        public static readonly DependencyProperty PasswordProperty =
            DependencyProperty.Register( "Password" , typeof( string ) , typeof( LoginPasswordCopy ) ,
            new UIPropertyMetadata( String.Empty , LoginPasswordChanged ) );

        public string Login
        {
            get
            {
                return (string) GetValue( LoginProperty );
            }
            set
            {
                SetValue( LoginProperty , value );
            }
        }

        public string Password
        {
            get
            {
                return (string) GetValue( PasswordProperty );
            }
            set
            {
                SetValue( PasswordProperty , value );
            }
        }

        private static void LoginPasswordChanged( DependencyObject o , DependencyPropertyChangedEventArgs e )
        {
            if ( e.Property == LoginProperty )
            {
                ( o as LoginPasswordCopy ).textBoxLogin.Text = e.NewValue as String;
            }
            else if ( e.Property == PasswordProperty )
            {
                ( o as LoginPasswordCopy ).textBoxPassword.Text = e.NewValue as String;
            }
        }

        public LoginPasswordCopy()
        {
            InitializeComponent();
        }

        private void OnButtonClick( object sender , RoutedEventArgs e )
        {
            if ( ( e.OriginalSource as Button ).Name.ToUpper().Contains( "LOGIN" ) )
            {
                textBoxLogin.Copy();
            }
            else if ( ( e.OriginalSource as Button ).Name.ToUpper().Contains( "PASSWORD" ) )
            {
                textBoxPassword.Copy();
            }
        }
    }
}
