﻿using System;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using Chatter.Net;
using Chatter.Net.Chat;
using Chatter.Common;

namespace Chatter
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private static readonly Encoding _enc = Encoding.UTF8;
		private ChatClient _client;

		public MainWindow()
		{
			InitializeComponent();
		}

		protected override void OnSourceInitialized( EventArgs e )
		{
			base.OnSourceInitialized( e );

			var nets = NetworkConfig.Configs;

			_client = new ChatClient( new IPAddress( new byte[] { 192 , 168 , 1 , 255 } ) );
			_client.Received += OnClientReceived;
		}

		protected override void OnClosed( EventArgs e )
		{
			_client.Close();

			base.OnClosed( e );
		}

		private void AddChatMessage( string msg )
		{
			textBoxChat.Text += msg + Environment.NewLine;
			LimitText( textBoxChat , 256 );
		}

		private static void LimitText( TextBox textBox , int nLines )
		{
			int n = textBox.LineCount;
			if ( n <= nLines )
			{
				return;
			}

			textBox.SelectionStart = 0;
			textBox.SelectionLength = textBox.GetCharacterIndexFromLineIndex( n - nLines );
			textBox.SelectedText = String.Empty;
		}

		private void OnClientReceived( object sender , EventArgs<UserInfo , string> e )
		{
			Dispatcher.Invoke( new Action<string>( AddChatMessage ) , String.Format( "{0}: {1}" , e.Argument1.Name , e.Argument2 ) );
		}

		private void OnSendClick( object sender , RoutedEventArgs e )
		{
			string msg = textBoxMessage.Text;

			if ( !String.IsNullOrWhiteSpace( msg ) )
			{
				_client.SendMessage( msg );
			}

			textBoxMessage.Clear();
		}

		private void OnKeyDown( object sender , KeyEventArgs e )
		{
			if ( e.Key == Key.Enter )
			{
				OnSendClick( this , new RoutedEventArgs() );
			}
		}
	}
}
