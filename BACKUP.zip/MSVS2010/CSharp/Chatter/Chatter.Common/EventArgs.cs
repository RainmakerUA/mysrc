﻿using System;

namespace Chatter.Common
{
	/// <summary>
	/// Event argument class with one event data element.
	/// </summary>
	/// <typeparam name="T">Data element type.</typeparam>
	public class EventArgs<T> : EventArgs
	{
		private readonly T _arg;

		/// <summary>
		/// Creates argument with specified event data value.
		/// </summary>
		/// <param name="arg">Event data value.</param>
		public EventArgs( T arg )
		{
			_arg = arg;
		}

		/// <summary>
		/// Event data.
		/// </summary>
		public T Argument { get { return _arg; } }

		/// <summary>
		/// Retrieves string representation of event data.
		/// </summary>
		/// <returns>String representation of event data.</returns>
		public override string ToString()
		{
			return String.Format(
					"( {0}: {1} )" ,
					typeof( T ).Name , _arg
				);
		}
	}

	/// <summary>
	/// Event argument class with two event data elements.
	/// </summary>
	/// <typeparam name="T1"></typeparam>
	/// <typeparam name="T2"></typeparam>
	public sealed class EventArgs<T1 , T2> : EventArgs
	{
		private readonly T1 _arg1;
		private readonly T2 _arg2;

		/// <summary>
		/// Creates argument with specified event data values.
		/// </summary>
		/// <param name="argument1">First event data value.</param>
		/// <param name="argument2">Second event data value.</param>
		public EventArgs( T1 argument1 , T2 argument2 )
		{
			_arg1 = argument1;
			_arg2 = argument2;
		}

		/// <summary>
		/// First event data value.
		/// </summary>
		public T1 Argument1 { get { return _arg1; } }

		/// <summary>
		/// Second event data value.
		/// </summary>
		public T2 Argument2 { get { return _arg2; } }

		/// <summary>
		/// Retrieves string representation of event data.
		/// </summary>
		/// <returns>String representation of event data.</returns>
		public override string ToString()
		{
			return String.Format(
					"( {0}: {1}\n{2}: {3} )" ,
					typeof( T1 ).Name , _arg1 ,
					typeof( T2 ).Name , _arg2
				);
		}
	}
}
