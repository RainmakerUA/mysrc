﻿using System;
using System.IO;
using System.Reflection;

namespace Chatter.Common.Utililty
{
	/// <summary>
	/// File system utility class.
	/// </summary>
	public static class FileSystem
	{
		private static string _mainAssemblyDir;

		/// <summary>
		/// Gets directory path where main application assembly is stored.
		/// </summary>
		private static string MainAssemblyDirectory
		{
			get
			{
				if ( String.IsNullOrWhiteSpace( _mainAssemblyDir ) )
				{
					_mainAssemblyDir = Path.GetDirectoryName( Assembly.GetEntryAssembly().Location );
				}
				return _mainAssemblyDir;
			}
		}

		//public static string CurrentAssemblyDirectory
		//{
		//    get
		//    {
		//        return Path.GetDirectoryName( Assembly.GetExecutingAssembly().Location );
		//    }
		//}

		//public static string CallingAssemblyDirectory
		//{
		//    get
		//    {
		//        return Path.GetDirectoryName( Assembly.GetCallingAssembly().Location );
		//    }
		//}

		/// <summary>
		/// Opens a text file, reads all lines of the file, and then closes the file.
		/// File path is relative to main assembly directory.
		/// </summary>
		/// <param name="name">File name.</param>
		/// <returns>Text stored in the file.</returns>
		public static string LocalReadAllText( string name )
		{
			string fullname = Path.Combine( MainAssemblyDirectory , name );
			return File.ReadAllText( fullname );
		}

		/// <summary>
		/// Creates a new file, writes the specified string to the file, and then closes the file.
		/// If the target file already exists, it is overwritten.
		/// File path is relative to main assembly directory.
		/// </summary>
		/// <param name="name">File name.</param>
		/// <param name="text">Text to be stored in the file.</param>
		public static void LocalWriteAllText( string name , string text )
		{
			string fullname = Path.Combine( MainAssemblyDirectory , name );
			File.WriteAllText( fullname , text );
		}
	}
}
