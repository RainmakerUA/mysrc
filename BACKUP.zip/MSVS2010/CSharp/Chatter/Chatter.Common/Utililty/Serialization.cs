﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace Chatter.Common.Utililty
{
	/// <summary>
	/// Serialization utility class.
	/// </summary>
	public static class Serialization
	{
		/// <summary>
		/// Serializes arbitrary object to binary representation
		/// using <see cref="T:System.Runtime.Serialization.Formatters.Binary.BinaryFormatter" />.
		/// </summary>
		/// <param name="obj">Object to be serialized.</param>
		/// <returns>Object binary representation or null if null value passed.</returns>
		/// <exception cref="T:System.Runtime.Serialization.SerializationException">Thrown when serialization error occured.</exception>
		public static byte[] SerializeToBinary( this object obj )
		{
			if ( obj == null )
			{
				return null;
			}

			using ( var ms = new MemoryStream() )
			{
				new BinaryFormatter().Serialize( ms , obj );
				return ms.ToArray();
			}
		}

		/// <summary>
		/// Deserializes binary data to object of specified type.
		/// </summary>
		/// <typeparam name="T">Object type.</typeparam>
		/// <param name="data">Binary object data.</param>
		/// <returns>Deserialized instance or default value if data is null.</returns>
		/// <exception cref="T:System.Runtime.Serialization.SerializationException">Thrown when serialization error occured.</exception>
		public static T DeserializeTo<T>( this byte[] data )
		{
			if ( data == null )
			{
				return default( T );
			}

			using ( var ms = new MemoryStream( data ) )
			{
				return ( T ) new BinaryFormatter().Deserialize( ms );
			}
		}

		/// <summary>
		/// Serializes arbitrary object to XML representation.
		/// </summary>
		/// <param name="obj">Object to be serialized.</param>
		/// <param name="rootElementName">Specifies root XML node name, if it is null, default is used.</param>
		/// <returns>String containing XML representation of object, or null if object is null.</returns>
		public static string SerializeToXml( this object obj , string rootElementName = null )
		{
			if ( obj == null )
			{
				return null;
			}

			Type type = obj.GetType();
			var ser = String.IsNullOrWhiteSpace( rootElementName )
				? new XmlSerializer( type )
				: new XmlSerializer( type , new XmlRootAttribute( rootElementName ) );

			using ( var writer = new StringWriter() )
			{
				ser.Serialize( writer , obj );
				return writer.ToString();
			}
		}

		/// <summary>
		/// Deserializes XML to object of specified type.
		/// </summary>
		/// <typeparam name="T">Object type.</typeparam>
		/// <param name="str">String with XML to deserialize.</param>
		/// <param name="rootElementName">Specifies root XML node name, if it is null, default is used.</param>
		/// <returns>Deserialized instance or default value if XML string is null.</returns>
		public static T DeserializeXmlTo<T>( this string str , string rootElementName = null )
		{
			if ( str == null )
			{
				return default( T );
			}

			Type type = typeof( T );
			var ser = String.IsNullOrWhiteSpace( rootElementName )
				? new XmlSerializer( type )
				: new XmlSerializer( type , new XmlRootAttribute( rootElementName ) );

			using ( var reader = new StringReader( str ) )
			{
				return ( T ) ser.Deserialize( reader );
			}
		}
	}
}
