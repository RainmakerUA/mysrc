﻿using System;
using System.ComponentModel;
using System.Linq.Expressions;
using System.Net;

namespace Chatter.Common.Utililty
{
	/// <summary>
	/// Extension methos class.
	/// </summary>
	public static class Extensions
	{
		#region Casting

		/// <summary>
		/// Casts arbitrary object to instance of specified reference type.
		/// </summary>
		/// <typeparam name="T">Reference type, object must be casted to.</typeparam>
		/// <param name="obj">Object to cast.</param>
		/// <param name="returnNull">
		/// Boolean, determining, whether <I>null</I> must be returned
		/// instead of throwing an exception.
		/// </param>
		/// <returns>
		/// Instance of specified class or <I>null</I>
		/// when object is null or cannot be casted (when <paramref name="returnNull"/> is true).
		/// </returns>
		/// <exception cref="T:System.InvalidCastException">Thrown when object cannot be casted and <paramref name="returnNull"/> is false.</exception>
		public static T ToRef<T>( this object obj , bool returnNull = true ) where T : class
		{
			var t = obj as T;

			if ( t == null && !returnNull )
			{
				throw new InvalidCastException(
						String.Format(
								"Value '{0}' of type {1} cannot be converted to type {2}" ,
								obj , obj.GetType() , typeof( T )
							)
					);
			}

			return t;
		}

		/// <summary>
		/// Casts arbitrary object unboxing to instance of specified value type.
		/// </summary>
		/// <typeparam name="T">Value type, object must be casted to.</typeparam>
		/// <param name="obj">Object to cast.</param>
		/// <param name="returnNull">
		/// Boolean, determining, whether <I>null</I> must be returned instead of throwing an exception.
		/// </param>
		/// <returns>Nullable specified type instance, containing cast result or <I>null</I>.</returns>
		/// <exception cref="T:System.InvalidCastException">Thrown when object cannot be casted and <paramref name="returnNull"/> is false.</exception>
		public static T? ToValue<T>( this object obj , bool returnNull = true ) where T : struct
		{
			if ( returnNull && !( obj is T ) )
			{
				return null;
			}

			return ( T ) obj;
		}

		#endregion

		#region IP Address

		/// <summary>
		/// Calculates broadcast address for specified address and subnet mask.
		/// </summary>
		/// <param name="address">IP address.</param>
		/// <param name="subnetMask">IP subnet mask.</param>
		/// <returns>Broadcast address for specified address and subnet mask.</returns>
		/// <exception cref="T:System.ArgumentException">Thrown when address and mask have different length.</exception>
		public static IPAddress GetBroadcastAddress( this IPAddress address , IPAddress subnetMask )
		{
			byte[] ipAdressBytes = address.GetAddressBytes();
			byte[] subnetMaskBytes = subnetMask.GetAddressBytes();

			if ( ipAdressBytes.Length != subnetMaskBytes.Length )
				throw new ArgumentException( "Lengths of IP address and subnet mask do not match." );

			var broadcastAddress = new byte[ ipAdressBytes.Length ];
			for ( int i = 0 ; i < broadcastAddress.Length ; i++ )
			{
				broadcastAddress[ i ] = ( byte ) ( ipAdressBytes[ i ] | ( subnetMaskBytes[ i ] ^ 255 ) );
			}
			return new IPAddress( broadcastAddress );
		}

		/// <summary>
		/// Calculates network address for specified address and subnet mask.
		/// </summary>
		/// <param name="address">IP address.</param>
		/// <param name="subnetMask">IP subnet mask.</param>
		/// <returns>Network address for specified address and subnet mask.</returns>
		/// <remarks>Network address is an IP address with all changeable bits reset.</remarks>
		/// <exception cref="T:System.ArgumentException">Thrown when address and mask have different length.</exception>
		public static IPAddress GetNetworkAddress( this IPAddress address , IPAddress subnetMask )
		{
			byte[] ipAdressBytes = address.GetAddressBytes();
			byte[] subnetMaskBytes = subnetMask.GetAddressBytes();

			if ( ipAdressBytes.Length != subnetMaskBytes.Length )
				throw new ArgumentException( "Lengths of IP address and subnet mask do not match." );

			var broadcastAddress = new byte[ ipAdressBytes.Length ];
			for ( int i = 0 ; i < broadcastAddress.Length ; i++ )
			{
				broadcastAddress[ i ] = ( byte ) ( ipAdressBytes[ i ] & ( subnetMaskBytes[ i ] ) );
			}
			return new IPAddress( broadcastAddress );
		}

		/// <summary>
		/// Determines whether IP addresses are in the same subnet.
		/// </summary>
		/// <param name="address1">IP address 1.</param>
		/// <param name="address2">IP address 2.</param>
		/// <param name="subnetMask">IP subnet mask.</param>
		/// <returns>True if addresses are in the same subnet, false otherwise.</returns>
		public static bool IsInSameSubnet( this IPAddress address1 , IPAddress address2 , IPAddress subnetMask )
		{
			IPAddress network1 = address2.GetNetworkAddress( subnetMask );
			IPAddress network2 = address1.GetNetworkAddress( subnetMask );

			return network1.Equals( network2 );
		}

		#endregion

		/// <summary>
		/// Raises PropertyChanged event for a property specified by expression.
		/// </summary>
		/// <typeparam name="T">Property value type.</typeparam>
		/// <param name="sender">Event sender object.</param>
		/// <param name="property">Changed property expression.</param>
		/// <param name="handler">Event handler delegate.</param>
		/// <exception cref="T:System.NotSupportedException">Thrown when <paramref name="property"/> is not property expression.</exception>
		public static void RaisePropertyChanged<T>( this INotifyPropertyChanged sender , Expression<Func<T>> property , PropertyChangedEventHandler handler )
		{
			if ( handler != null )
			{
				var expression = property.Body as MemberExpression;
				if ( expression == null )
				{
					throw new NotSupportedException( "Invalid expression passed. Only property member should be selected." );
				}

				handler( sender , new PropertyChangedEventArgs( expression.Member.Name ) );
			}
		}
	}
}
