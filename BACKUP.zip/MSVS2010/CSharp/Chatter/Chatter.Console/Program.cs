﻿using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.Net;
using Chatter.Net.Chat;
using Con = System.Console;
using Chatter.Common;

namespace Chatter.Console
{
	internal static class Program
	{
		private static void Main( string[] args )
		{
			ChatClient cc = null;
			try
			{
				cc = new ChatClient( IPAddress.Parse( "192.168.1.255" ) , 65019 );

				cc.Received += OnReceived;

				cc.PropertyChanged += OnLocalInfoChanged;
				( cc.ClientUserList as INotifyCollectionChanged ).CollectionChanged += OnCollectionChanged;

				cc.LocalUserInfo = LoadUserInfo();
				cc.UpdateUsers();

				string s;
				while ( !String.IsNullOrWhiteSpace( s = System.Console.ReadLine() ) )
				{
					cc.SendMessage( s );
				}
			}
			catch ( Exception e )
			{
				File.WriteAllText( "error.txt" , e.ToString() );
				Con.WriteLine( e );
			}
			finally
			{
				if ( cc != null )
				{
					cc.Close();
				}
			}

			Con.WriteLine( "Press any key..." );
			Con.ReadKey( true );
		}

		private static UserInfo LoadUserInfo()
		{
			const string FILE = "name.txt";
			string name = "Unnamed";
			string descr = null;

			if ( File.Exists( FILE ) )
			{
				var lines = File.ReadAllLines( FILE );
				if ( lines.Length > 0 )
				{
					name = lines[ 0 ];
					if ( lines.Length > 1 )
					{
						descr = lines[ 1 ];
					}
				}
			}

			return new UserInfo
					   {
						   Name = name ,
						   Description = descr ,
						   IsLost = false
					   };
		}

		private static void OnCollectionChanged( object sender , NotifyCollectionChangedEventArgs e )
		{
			Con.WriteLine( "--- CC collection changed: {0}" , e.Action );
		}

		private static void OnLocalInfoChanged( object sender , PropertyChangedEventArgs e )
		{
			Con.WriteLine( "--- CC property {0} changed." , e.PropertyName );
		}

		private static void OnReceived( object sender , EventArgs<UserInfo , string> e )
		{
			Con.WriteLine( "{0}: {1}" , e.Argument1.Name , e.Argument2 );
		}
	}
}
