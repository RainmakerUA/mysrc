﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using Chatter.Common;

namespace Chatter.Net
{
	internal class UdpNetClient : IDisposable
	{
		internal const int DefaultPort = 19019;
		private static readonly IPAddress _defaultBroadcast = IPAddress.Broadcast;
		private static readonly bool _isWinXP = Environment.OSVersion.Version.Major < 6;

		private readonly Thread _receiverThread;
		private readonly ManualResetEventSlim _receiveEvent;
		private readonly IPAddress _broadcast;
		private readonly int _receivePort;
		private volatile bool _disposed;
		private UdpClient _sender;
		private UdpClient _receiver;
		private UdpClient _unicastSender;

		public UdpNetClient()
			: this( _defaultBroadcast )
		{
		}

		public UdpNetClient( IPAddress broadcast , int port = DefaultPort )
		{
			_disposed = false;

			_broadcast = broadcast;
			_receivePort = port == 0 ? DefaultPort : port;

			_sender = new UdpClient { EnableBroadcast = true };
			_unicastSender = new UdpClient();

			_receiveEvent = new ManualResetEventSlim();

			_receiverThread = new Thread( ReceiverThreadStart ) { IsBackground = false };
			_receiverThread.Start();
		}

		#region Disposing

		~UdpNetClient()
		{
			Dispose( false );
		}

		#region IDisposable Members

		void IDisposable.Dispose()
		{
			Dispose( true );
			GC.SuppressFinalize( this );
		}

		#endregion

		private void Dispose( bool disposing )
		{
			if ( _disposed )
			{
				return;
			}

			if ( disposing )
			{
				// Dispose managed

				Received = null;

				_receiveEvent.Dispose();

				if ( _receiverThread.IsAlive )
				{
					_receiverThread.Abort();
				}

				lock ( _receiver )
				{
					_receiver.Close();
					_receiver = null;
				}

				_sender.Close();
				_sender = null;

				_unicastSender.Close();
				_unicastSender = null;
			}

			// Dispose unmanaged
			// ...

			_disposed = true;
		}

		public void Close()
		{
			( this as IDisposable ).Dispose();
		}

		#endregion Disposing

		private void ReceiverThreadStart()
		{
			_receiver = new UdpClient { EnableBroadcast = true };
			_receiver.Client.Bind( new IPEndPoint( IPAddress.Any , _receivePort ) );

			BeginReceive();

			if ( _isWinXP )
			{
				if ( _receiveEvent.IsSet )
				{
					_receiveEvent.Reset();
				}

				_receiveEvent.Wait();
			}
		}

		private void BeginReceive()
		{
			if ( _receiver != null )
			{
				lock ( _receiver )
				{
					_receiver.BeginReceive( EndReceive , new object[ 0 ] );
				}
			}
		}

		private void EndReceive( IAsyncResult result )
		{
			if ( _receiver != null )
			{
				lock ( _receiver )
				{
					// ReSharper disable ConditionIsAlwaysTrueOrFalse
					if ( _receiver != null && result.IsCompleted )
					// ReSharper restore ConditionIsAlwaysTrueOrFalse
					{
						var ep = new IPEndPoint( IPAddress.Any , _receivePort );
						byte[] data = _receiver.EndReceive( result , ref ep );

						if ( data != null )
						{
							RaiseReceived( ep.Address , data );
						}
					}
				}

				BeginReceive();
			}

			if ( _isWinXP )
			{
				_receiveEvent.Set();
			}
		}

		private void RaiseReceived( IPAddress address , byte[] data )
		{
			var handler = Received;

			if ( handler != null )
			{
				handler( this , new EventArgs<IPAddress , byte[]>( address , data ) );
			}
		}

		public void SendUnicast( IPAddress address , byte[] data )
		{
			if ( !_disposed && data != null && data.Length > 0 )
			{
				_unicastSender.Send( data , data.Length , new IPEndPoint( address , _receivePort ) );
			}
		}

		public void Send( byte[] data )
		{
			if ( !_disposed && data != null && data.Length > 0 )
			{
				_sender.Send( data , data.Length , new IPEndPoint( _broadcast , _receivePort ) );
			}
		}

		public event EventHandler<EventArgs<IPAddress , byte[]>> Received;
	}
}
