﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Net;
using Chatter.Common.Utililty;

namespace Chatter.Net.Chat
{
	[Serializable]
	internal sealed class UserList : IDictionary<IPAddress , UserInfo> , IList<UserInfo> , IList
	{
		private const string _XML_ROOT = "UserList";

		private readonly ObservableCollection<UserInfo> _users;
		private readonly List<IPAddress> _addresses = new List<IPAddress>();

		#region Constructors

		public UserList()
		{
			_users = new ObservableCollection<UserInfo>();
		}

		public UserList( IEnumerable<UserInfo> list )
		{
			_users = new ObservableCollection<UserInfo>( list );
			InitializeKeys();
		}

		#endregion

		#region Common Implementation

		public int Count
		{
			get { return _addresses.Count; }
		}

		public bool IsReadOnly
		{
			get { return false; }
		}

		public void Clear()
		{
			if ( _addresses.Count > 0 )
			{
				_addresses.Clear();
				_users.Clear();
			}
		}

		#endregion

		#region IDictionary<IPAddress,UserInfo> Members

		public void Add( IPAddress key , UserInfo value )
		{
			AddAddress( key );
			_users.Add( value );
		}

		public bool ContainsKey( IPAddress key )
		{
			return _addresses.Contains( key );
		}

		public ICollection<IPAddress> Keys
		{
			get { return _addresses.AsReadOnly(); }
		}

		public bool Remove( IPAddress key )
		{
			int index = FindEntry( key );

			if ( index >= 0 )
			{
				_users.RemoveAt( index );
				_addresses.RemoveAt( index );
				return true;
			}

			return false;
		}

		public bool TryGetValue( IPAddress key , out UserInfo value )
		{
			int index = FindEntry( key );
			value = index > -1 ? _users[ index ] : null;
			return index > -1;
		}

		public ICollection<UserInfo> Values
		{
			get { return AsReadonlyObservable(); }
		}

		public UserInfo this[ IPAddress key ]
		{
			get
			{
				int index = FindEntry( key );

				if ( index >= 0 )
				{
					return _users[ index ];
				}

				throw new KeyNotFoundException();
			}
			set
			{
				int index = FindEntry( key );

				if ( index >= 0 )
				{
					_users[ index ] = value;
				}
				else
				{
					Add( key , value );
				}
			}
		}

		#endregion

		#region ICollection<KeyValuePair<IPAddress,UserInfo>> Members

		public void Add( KeyValuePair<IPAddress , UserInfo> item )
		{
			Add( item.Key , item.Value );
		}

		public bool Contains( KeyValuePair<IPAddress , UserInfo> item )
		{
			int index = FindEntry( item.Key );
			return index >= 0 && Equals( item.Value , _users[ index ] );
		}

		public void CopyTo( KeyValuePair<IPAddress , UserInfo>[] array , int arrayIndex )
		{
			if ( array == null )
			{
				throw new ArgumentNullException( "array" );
			}
			if ( ( arrayIndex < 0 ) || ( arrayIndex > array.Length ) )
			{
				throw new ArgumentOutOfRangeException( "arrayIndex" );
			}
			if ( ( array.Length - arrayIndex ) < Count )
			{
				throw new ArgumentException( "Array range is too small!" , "arrayIndex" );
			}

			for ( int i = 0 ; i < _addresses.Count ; i++ )
			{
				array[ arrayIndex++ ] = new KeyValuePair<IPAddress , UserInfo>( _addresses[ i ] , _users[ i ] );
			}
		}

		public bool Remove( KeyValuePair<IPAddress , UserInfo> item )
		{
			return Contains( item ) && Remove( item.Key );
		}

		#endregion

		#region IEnumerable<KeyValuePair<IPAddress,UserInfo>> Members

		IEnumerator<KeyValuePair<IPAddress , UserInfo>> IEnumerable<KeyValuePair<IPAddress , UserInfo>>.GetEnumerator()
		{
			for ( int i = 0 ; i < Count ; i++ )
			{
				yield return new KeyValuePair<IPAddress , UserInfo>( _addresses[ i ] , _users[ i ] );
			}
		}

		#endregion

		#region IList<UserInfo> Members

		public int IndexOf( UserInfo item )
		{
			return _users.IndexOf( item );
		}

		public void Insert( int index , UserInfo item )
		{
			if ( ( index < 0 ) || ( index > Count ) )
			{
				throw new ArgumentOutOfRangeException( "index" );
			}

			IPAddress addr = item.IPAddress;

			CheckAddressExists( addr );
			_addresses.Insert( index , addr );
			_users.Insert( index , item );
		}

		public void RemoveAt( int index )
		{
			_users.RemoveAt( index );
			_addresses.RemoveAt( index );
		}

		public UserInfo this[ int index ]
		{
			get
			{
				return _users[ index ];
			}
			set
			{
				IPAddress addr = value.IPAddress;
				CheckAddressExists( addr , index );

				_users[ index ] = value;
				if ( !Equals( _addresses[ index ] , addr ) )
				{
					_addresses[ index ] = addr;
				}
			}
		}

		#endregion

		#region ICollection<UserInfo> Members

		public void Add( UserInfo item )
		{
			Add( item.IPAddress , item );
		}

		public bool Contains( UserInfo item )
		{
			return _users.Contains( item );
		}

		public void CopyTo( UserInfo[] array , int arrayIndex )
		{
			_users.CopyTo( array , arrayIndex );
		}

		public bool Remove( UserInfo item )
		{
			int index = IndexOf( item );
			return index >= 0 && _users.Remove( item ) && _addresses.Remove( item.IPAddress );
		}

		#endregion

		#region IEnumerable<UserInfo> Members

		public IEnumerator<UserInfo> GetEnumerator()
		{
			return _users.GetEnumerator();
		}

		#endregion

		#region IList Members

		public int Add( object value )
		{
			CheckArgumentType<UserInfo>( value );
			int newIndex = Count;
			Add( value as UserInfo );
			return newIndex;
		}

		public bool Contains( object value )
		{
			return Contains( value as UserInfo );
		}

		public int IndexOf( object value )
		{
			return IndexOf( value as UserInfo );
		}

		public void Insert( int index , object value )
		{
			CheckArgumentType<UserInfo>( value );
			Insert( index , value as UserInfo );
		}

		public bool IsFixedSize
		{
			get { return false; }
		}

		public void Remove( object value )
		{
			Remove( value as UserInfo );
		}

		object IList.this[ int index ]
		{
			get
			{
				return this[ index ];
			}
			set
			{
				CheckArgumentType<UserInfo>( value );
				this[ index ] = value as UserInfo;
			}
		}

		#endregion

		#region ICollection Members

		public void CopyTo( Array array , int index )
		{
			CheckArgumentType<UserInfo[]>( array );
			var users = array as UserInfo[];
			CopyTo( users , index );
		}

		public bool IsSynchronized
		{
			get { return ( _users as ICollection ).IsSynchronized; }
		}

		public object SyncRoot
		{
			get { return ( _users as ICollection ).SyncRoot; }
		}

		#endregion

		#region IEnumerable Members

		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}

		#endregion

		public ReadOnlyObservableCollection<UserInfo> AsReadonlyObservable()
		{
			return new ReadOnlyObservableCollection<UserInfo>( _users );
		}

		#region Serializiation

		public string ToXml()
		{
			return _users.SerializeToXml( _XML_ROOT );
		}

		public static UserList FromXml( string xml )
		{
			return new UserList( xml.DeserializeXmlTo<UserInfo[]>( _XML_ROOT ) );
		}

		#endregion

		#region Private Methods

		private void InitializeKeys()
		{
			foreach ( var userInfo in _users )
			{
				AddAddress( userInfo.IPAddress );
			}
		}

		private void CheckAddressExists( IPAddress address )
		{
			if ( _addresses.Contains( address ) )
			{
				ThrowInvalidOperation( "User Address must be unique through the list!" );
			}
		}

		private void CheckAddressExists( IPAddress address , int index )
		{
			int addressIndex = _addresses.IndexOf( address );

			if ( addressIndex >= 0 && addressIndex != index )
			{
				ThrowInvalidOperation( "User Address must be unique through the list!" );
			}
		}

		private void AddAddress( IPAddress address )
		{
			CheckAddressExists( address );
			_addresses.Add( address );
		}

		private int FindEntry( IPAddress address )
		{
			int index = _addresses.IndexOf( address );
			if ( index > -1 && !Equals( _addresses[ index ] , _users[ index ].IPAddress ) )
			{
				ThrowInvalidOperation( "Unrelated Address and User on same index!" );
			}

			return index;
		}

		private static void CheckArgumentType<T>( object arg )
		{
			if ( !( arg is T ) )
			{
				throw new ArgumentException(
					String.Format(
							"The value '{0}' is not of type '{1}' and cannot be used in this generic collection." ,
							arg , typeof( T )
						)
				);
			}
		}

		private static void ThrowInvalidOperation( string message )
		{
			throw new InvalidOperationException( message );
		}

		#endregion
	}
}
