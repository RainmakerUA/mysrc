﻿using System;
using System.Diagnostics.Contracts;
using System.Net;
using System.ComponentModel;
using Chatter.Common.Utililty;

namespace Chatter.Net.Chat
{
	[Serializable]
	public class UserInfo : INotifyPropertyChanged
	{
		private const string _NO_NAME = "Unnamed";
		private string _address;
		private string _name;
		private string _description;
		private bool _isLost = false;

		public string Address
		{
			get
			{
				return _address;
			}
			set
			{
				Contract.Requires( value != null );
				_address = value;
				this.RaisePropertyChanged( () => Address , PropertyChanged );
				this.RaisePropertyChanged( () => IPAddress, PropertyChanged );
			}
		}

		public IPAddress IPAddress
		{
			get
			{
				IPAddress res;
				return IPAddress.TryParse( _address , out res ) ? res : null;
			}
		}

		public string Name
		{
			get
			{
				return _name;
			}
			set
			{
				_name = value ?? _NO_NAME;
				this.RaisePropertyChanged( () => Name , PropertyChanged );
			}
		}

		public string Description
		{
			get
			{
				return _description;
			}
			set
			{
				_description = value;
				this.RaisePropertyChanged( () => Description , PropertyChanged );
			}
		}

		public bool IsLost
		{
			get
			{
				return _isLost;
			}
			set
			{
				_isLost = value;
				this.RaisePropertyChanged( () => IsLost , PropertyChanged );
			}
		}

		public override int GetHashCode()
		{
			int addrCode = _address != null ? _address.GetHashCode() : 0;
			int nameCode = _name != null ? _name.GetHashCode() : 0;
			int descCode = _description != null ? _description.GetHashCode() : 0;
			int lostCode = _isLost.GetHashCode();

			return addrCode ^ nameCode ^ descCode ^ lostCode;
		}

		public override bool Equals( object obj )
		{
			return Equals( obj as UserInfo );
		}

		public bool Equals( UserInfo userInfo )
		{
			return userInfo != null && _address.Equals( userInfo._address ) && _name.Equals( userInfo._name )
					&& _description.Equals( userInfo._description ) && _isLost.Equals( userInfo._isLost );
		}

		public static bool operator ==( UserInfo info1 , UserInfo info2 )
		{
			return Equals( info1 , info2 );
		}

		public static bool operator !=( UserInfo info1 , UserInfo info2 )
		{
			return !Equals( info1 , info2 );
		}

		private static void ThrowIfNull( object value , string argName )
		{
			if ( ReferenceEquals( value , null ) )
			{
				throw new ArgumentNullException( argName );
			}
		}

		#region INotifyPropertyChanged Members

		public event PropertyChangedEventHandler PropertyChanged;

		#endregion
	}
}
