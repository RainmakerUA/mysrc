﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Chatter.Common.Utililty;

namespace Chatter.Net.Chat
{
	[Serializable]
	internal struct ChatPacket
	{
		public enum PacketKind : byte
		{
			Ping = 1 ,
			Pong ,
			UserInfoRequest ,
			UserInfo ,
			Message ,
			Custom
		}

		private readonly PacketKind _kind;
		private readonly object _data;
		private readonly DateTime _timestamp;

		public ChatPacket( PacketKind kind , object data )
		{
			_kind = kind;
			_data = data;
			_timestamp = DateTime.Now;
		}

		public PacketKind Kind
		{
			get
			{
				return _kind;
			}
		}

		public object Data
		{
			get
			{
				return _data;
			}
		}

		public DateTime Timestamp
		{
			get
			{
				return _timestamp;
			}
		}

		public override string ToString()
		{
			return String.Format( "{0} | {1:dd.MM.yyyy HH:mm:ss} | {2}" , _kind , _timestamp , _data ?? "<null>" );
		}

		public byte[] ToBinary()
		{
			return this.SerializeToBinary();
		}

		public static ChatPacket FromBinary( byte[] data )
		{
			return data.DeserializeTo<ChatPacket>();
		}
	}
}
