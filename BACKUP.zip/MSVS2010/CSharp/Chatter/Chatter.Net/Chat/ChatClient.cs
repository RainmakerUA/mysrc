﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net;
using Chatter.Common;
using Chatter.Common.Utililty;

namespace Chatter.Net.Chat
{
	public sealed class ChatClient : IDisposable , INotifyPropertyChanged
	{
		private const string _USERLIST_FILE = "userlist.dat";

		private bool _disposed;
		private UdpNetClient _client;
		private UserInfo _localInfo;
		private UserList _users = new UserList();

		public ChatClient( IPAddress ipBroadcast = null , int port = UdpNetClient.DefaultPort )
		{
			_disposed = false;
			Initialize( ipBroadcast , port );
		}

		public UserInfo LocalUserInfo
		{
			get { return _localInfo; }
			set
			{
				_localInfo = value;
				this.RaisePropertyChanged( () => LocalUserInfo , PropertyChanged );
				SendName( _localInfo );
			}
		}

		public ReadOnlyObservableCollection<UserInfo> ClientUserList
		{
			get
			{
				return _users.AsReadonlyObservable();
			}
		}

		#region Disposing

		~ChatClient()
		{
			Dispose( false );
		}

		#region IDisposable Members

		void IDisposable.Dispose()
		{
			Dispose( true );
			GC.SuppressFinalize( this );
		}

		#endregion

		private void Dispose( bool disposing )
		{
			if ( _disposed )
			{
				return;
			}

			if ( disposing )
			{
				// Dispose managed

				CloseClient();
			}

			// Dispose unmanaged
			// ...

			_disposed = true;
		}

		public void Close()
		{
			( this as IDisposable ).Dispose();
		}

		#endregion Disposing

		public void Initialize( IPAddress ipBroadcast , int port )
		{
			if ( _client != null )
			{
				CloseClient();
			}

			_client = ipBroadcast == null ? new UdpNetClient() : new UdpNetClient( ipBroadcast , port );
			_client.Received += OnClientReceive;

			LoadUsers();
			UpdateUsers( _users == null || _users.Count == 0 );
		}

		public void SendMessage( string message )
		{
			SendPacket( new ChatPacket( ChatPacket.PacketKind.Message , message ) );
		}

		private void CloseClient()
		{
			FileSystem.LocalWriteAllText( _USERLIST_FILE , _users.ToXml() );
			_client.Close();
			_client.Received -= OnClientReceive;
		}

		#region UserList

		private void LoadUsers()
		{
			string str = FileSystem.LocalReadAllText( _USERLIST_FILE );
			if ( !String.IsNullOrWhiteSpace( str ) )
			{
				var newList = UserList.FromXml( str );

				if ( newList != null )
				{
					_users = newList;
				}
			}
		}

		public void UpdateUsers()
		{
			UpdateUsers( true );
		}

		private void UpdateUsers( bool rescan )
		{
			if ( rescan )
			{
				_users.Clear();
				SendNameRequest();
			}
			else
			{
				foreach ( var info in _users )
				{
					info.IsLost = true;
					SendPing( info.IPAddress );
				}
			}
		}

		#endregion

		#region Private Sending

		private void SendPacket( ChatPacket packet , IPAddress address = null )
		{
			var data = packet.ToBinary();

			if ( address == null )
			{
				_client.Send( data );
			}
			else
			{
				_client.SendUnicast( address , data );
			}
		}

		private void SendName( UserInfo info , IPAddress address = null )
		{
			var packet = new ChatPacket( ChatPacket.PacketKind.UserInfo , info );
			SendPacket( packet , address );
		}

		private void SendNameRequest( IPAddress address = null )
		{
			var packet = new ChatPacket( ChatPacket.PacketKind.UserInfoRequest , null );
			SendPacket( packet , address );
		}

		private void SendPing( IPAddress address , bool isResponse = false )
		{
			var packet = new ChatPacket( isResponse ? ChatPacket.PacketKind.Pong : ChatPacket.PacketKind.Ping , null );
			SendPacket( packet , address );
		}

		#endregion

		#region Private Receiving

		private void RaiseReceived( EventArgs<UserInfo , string> e )
		{
			var handler = Received;

			if ( handler != null )
			{
				handler( this , e );
			}
		}

		private void UpdateUserInfo( IPAddress address , UserInfo info )
		{
			if ( address == null )
			{
				throw new ArgumentNullException( "address" );
			}

			if ( info == null )
			{
				throw new ArgumentNullException( "info" );
			}

			if ( _users.ContainsKey( address ) )
			{
				var user = _users[ address ];
				user.Name = info.Name;
				user.Description = info.Description;
				user.IsLost = false;
			}
			else
			{
				_users.Add(
						new UserInfo
						{
							Address = address.ToString() ,
							Name = info.Name ,
							Description = info.Description ,
							IsLost = false
						}
					);
			}
		}

		private void OnMessage( IPAddress address , ChatPacket packet )
		{
			UserInfo user;
			if ( !_users.TryGetValue( address , out user ) )
			{
				user = new UserInfo { Address = address.ToString() , Name = "Unknown user" };
			}

			var args = new EventArgs<UserInfo , string>(
					user ,
					packet.Data.ToRef<string>()
				);
			RaiseReceived( args );
		}

		private void OnClientReceive( object sender , EventArgs<IPAddress , byte[]> e )
		{
			var address = e.Argument1;
			var data = e.Argument2;
			var packet = ChatPacket.FromBinary( data );

			if ( packet.Kind != ChatPacket.PacketKind.UserInfo && !_users.ContainsKey( address ) )
			{
				SendNameRequest( address );
			}

			switch ( packet.Kind )
			{
				case ChatPacket.PacketKind.Ping:
					SendPing( address , true );
					break;

				case ChatPacket.PacketKind.Pong:
					//SendNameRequest( address );
					break;

				case ChatPacket.PacketKind.Message:
					OnMessage( e.Argument1 , packet );
					break;

				case ChatPacket.PacketKind.UserInfo:
					UpdateUserInfo( address , packet.Data.ToRef<UserInfo>() );
					break;

				case ChatPacket.PacketKind.UserInfoRequest:
					SendName( _localInfo ?? new UserInfo { IsLost = true } , address );
					break;

				default:
					break;
			}
		}

		#endregion

		//public event EventHandler<EventArgs<UserInfo>> UserInfoRequest;
		public event EventHandler<EventArgs<UserInfo , string>> Received;

		#region INotifyPropertyChanged Members

		public event PropertyChangedEventHandler PropertyChanged;

		#endregion
	}
}
