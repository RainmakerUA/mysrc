﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using Chatter.Common.Utililty;

namespace Chatter.Net
{
	/// <summary>
	/// Class for retrieving network configuration and tracking network configuration changes.
	/// </summary>
	public class NetworkConfig
	{
		private static readonly List<NetworkConfig> _configs;

		private readonly string _name;
		private readonly string _description;
		private readonly IPAddress _address;
		private readonly IPAddress _mask;
		private readonly IPAddress _broadcast;

		static NetworkConfig()
		{
			_configs = new List<NetworkConfig>();
			NetworkChange.NetworkAddressChanged += OnNetworkChanged;
			NetworkChange.NetworkAvailabilityChanged += OnNetworkChanged;
			RefreshNetworks();
		}

		private NetworkConfig( string name , string description , IPAddress address , IPAddress mask )
		{
			_name = name;
			_description = description;
			_address = address;
			_mask = mask;

			_broadcast = _address.GetBroadcastAddress( _mask );
		}

		/// <summary>
		/// Gets collection of all available network configurations.
		/// </summary>
		public static ReadOnlyCollection<NetworkConfig> Configs
		{
			get
			{
				return _configs.AsReadOnly();
			}
		}

		/// <summary>
		/// Network name.
		/// </summary>
		public string Name
		{
			get
			{
				return _name;
			}
		}

		/// <summary>
		/// Network description.
		/// </summary>
		public string Description
		{
			get
			{
				return _description;
			}
		}

		/// <summary>
		/// Network address.
		/// </summary>
		public IPAddress Address
		{
			get
			{
				return _address;
			}
		}

		/// <summary>
		/// Network subnet mask.
		/// </summary>
		public IPAddress Mask
		{
			get
			{
				return _mask;
			}
		}

		/// <summary>
		/// Network broadcast address.
		/// </summary>
		public IPAddress Broadcast
		{
			get
			{
				return _broadcast;
			}
		}

		private static void RefreshNetworks()
		{
			_configs.Clear();
			_configs.AddRange(
					from ni in NetworkInterface.GetAllNetworkInterfaces()
					where ni.OperationalStatus == OperationalStatus.Up
					from ip in ni.GetIPProperties().UnicastAddresses
					where ip.Address.AddressFamily == AddressFamily.InterNetwork && ip.IPv4Mask != null && ip.IPv4Mask != IPAddress.Any
					select new NetworkConfig( ni.Name , ni.Description , ip.Address , ip.IPv4Mask )
				);
		}

		private static void OnNetworkChanged( object sender , EventArgs e )
		{
			RefreshNetworks();

			EventHandler handler = NetworkChanged;
			if ( handler!=null )
			{
				handler( Configs , EventArgs.Empty );
			}
		}

		/// <summary>
		/// Retrieves string representation of <see cref="T:Chatter.Net.NetworkConfig"/> object.
		/// </summary>
		/// <returns>String representation of NetworkConfig.</returns>
		public override string ToString()
		{
			return String.Format( "{0} :: {1}/{2}" , _name , _address , _mask );
		}

		/// <summary>
		/// Occurs when computer network configuration or availability changes.
		/// </summary>
		public static event EventHandler NetworkChanged;
	}
}
