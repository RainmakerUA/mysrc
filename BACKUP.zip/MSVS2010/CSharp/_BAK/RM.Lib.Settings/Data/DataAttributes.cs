﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RM.Lib.Settings.Data
{
	[AttributeUsage( AttributeTargets.Class , AllowMultiple = false , Inherited = false )]
	public class SettingsDataAttribute : Attribute
	{
	}

	[AttributeUsage( AttributeTargets.Property , AllowMultiple = false , Inherited = true )]
	public class IgnorePropertyAttribute : Attribute
	{
	}

	[AttributeUsage( AttributeTargets.Property , AllowMultiple = false , Inherited = false )]
	public class ReadOnlyPropertyAttribute : Attribute
	{
	}

	[AttributeUsage( AttributeTargets.Property , AllowMultiple = false , Inherited = false )]
	public class DefaultValueAttribute : Attribute
	{
		private readonly object _value;

		public DefaultValueAttribute( object value )
		{
			_value = value;
		}

		public object Value
		{
			get { return _value; }
		}
	}
}
