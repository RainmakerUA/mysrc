﻿using System;

namespace RM.Lib.Settings
{
	public class SettingsException : ApplicationException
	{
		public SettingsException( string message )
			: base( message )
		{
		}

		public SettingsException( string messageFormat , params object[] args )
			: base( String.Format( messageFormat , args ) )
		{
		}
	}
}
