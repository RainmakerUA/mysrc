﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RM.Lib.Settings
{
	//public class Class1 : ISettingsData<Class1> //:BaseFileSettingsProvider<EmptySettingsData>
	//{
	//    public Class1 Default
	//    {
	//        get { return null; }
	//    }
	//}
}
