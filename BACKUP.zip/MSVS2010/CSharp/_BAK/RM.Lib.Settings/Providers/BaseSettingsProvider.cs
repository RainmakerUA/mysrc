﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Reflection;
using RM.Lib.Settings.Data;

namespace RM.Lib.Settings.Providers
{
	[ContractClass( typeof( BaseSettingsProviderContracts<> ) )]
	public abstract class BaseSettingsProvider<T> where T : class, new()
	{
		#region Inner class

		private class Property
		{
			public Property( PropertyInfo info , object defaultValue )
			{
				System.Diagnostics.Trace.Assert(
						info.DeclaringType == typeof( T )
						&& ( defaultValue == null || info.PropertyType.IsAssignableFrom( defaultValue.GetType() ) )
					);

				Name = info.Name;
				IsReadOnly = info.GetSetMethod() == null || info.GetCustomAttributes( _readonlyAttr , false ).Length > 0;
				Info = info;
				DefaultValue = defaultValue;
			}

			public string Name { get; private set; }
			public bool IsReadOnly { get; private set; }
			public PropertyInfo Info { get; private set; }
			public object DefaultValue { get; private set; }

			public object GetValue( T data )
			{
				return Info.GetValue( data , null );
			}

			public void SetValue( T data , object value )
			{
				Info.SetValue( data , value , null );
			}

			public void ResetValue( T data )
			{
				Info.SetValue( data , DefaultValue , null );
			}

			public override string ToString()
			{
				return String.Format( "[{0}] {1}: {2} = {3}" , IsReadOnly ? "x" : "v" , Name , Info.PropertyType.Name , DefaultValue ?? "<not set>" );
			}
		}

		#endregion

		#region Fields-ReadOnly

		private static readonly Type _settingsDataAttr = typeof( SettingsDataAttribute );
		private static readonly Type _skipAttr = typeof( IgnorePropertyAttribute );
		private static readonly Type _readonlyAttr = typeof( ReadOnlyPropertyAttribute );
		private static readonly Type _defaultValueAttr = typeof( DefaultValueAttribute );

		private static readonly object _syncRoot = new object();
		private static readonly Type _type = typeof( T );
		private static readonly Assembly _mainAssembly;
		private static readonly Dictionary<string , Property> _properties;

		#endregion

		#region Fields

		private static T _defaultData;
		private T _data;

		#endregion

		#region Constructors

		static BaseSettingsProvider()
		{
			ValidateType();
			_mainAssembly = Assembly.GetEntryAssembly();
			_properties = GetProperties();
		}

		protected BaseSettingsProvider()
		{
			_data = Default;
		}

		protected BaseSettingsProvider( T initialData )
		{
			_data = initialData;
		}

		#endregion

		#region Properties

		public static T Default
		{
			get
			{
				if ( _defaultData == null )
				{
					lock ( _syncRoot )
					{
						if ( _defaultData == null )
						{
							_defaultData = GetDefaultData();
						}
					}
				}

				return _defaultData;
			}
		}

		public T Settings { get { return _data; } }

		#endregion

		#region Methods

		[Pure]
		protected abstract string GetSettingsLocation( Assembly mainAssembly );

		[Pure]
		protected abstract Dictionary<string , object> LoadData( string location );

		[Pure]
		protected abstract void SaveData( string location , Dictionary<string , object> data );

		public void Load( string location )
		{
			var dict = LoadData( location );
			_data = DictionaryToData( dict );
		}

		public void Load()
		{
			Load( GetSettingsLocation( _mainAssembly ) );
		}

		public void Save( string location )
		{
			SaveData( location , DataToDictionary( _data ) );
		}

		public void Save()
		{
			Save( GetSettingsLocation( _mainAssembly ) );
		}

		#endregion

		#region Methods-Private

		private static void ValidateType()
		{
			var attrs = _type.GetCustomAttributes( _settingsDataAttr , false );
			if ( attrs.Length == 0 )
			{
				throw new SettingsException( "Settings type must be marked with {0} attribute!" , _settingsDataAttr.FullName );
			}
		}

		private static Dictionary<string , Property> GetProperties()
		{
			var props = from prop in _type.GetProperties()
						let propAttrs = prop.GetCustomAttributes( false )
						let defaultAttr = propAttrs.FirstOrDefault( p => p.GetType() == _defaultValueAttr ) as DefaultValueAttribute
						where prop.CanRead && prop.CanWrite
								&& prop.GetIndexParameters().Length == 0
								&& !propAttrs.Any( propAttr => propAttr.GetType() == _skipAttr )
						select new Property(
								prop ,
								defaultAttr != null ? defaultAttr.Value : null
							);

			return props.ToDictionary( p => p.Name );
		}

		private static T GetDefaultData()
		{
			var data = new T();

			foreach ( var property in _properties.Values )
			{
				if ( property.DefaultValue != null )
				{

					property.ResetValue( data );
				}
			}

			return data;
		}

		private static Dictionary<string , object> DataToDictionary( T data )
		{
			return _properties.ToDictionary( prop => prop.Key , prop => prop.Value.GetValue( data ) );
		}

		private static T DictionaryToData( Dictionary<string , object> dictionary )
		{
			T data = GetDefaultData();

			foreach ( var o in dictionary )
			{
				if ( _properties.ContainsKey( o.Key ) )
				{
					_properties[ o.Key ].SetValue( data , o.Value );
				}
			}

			return data;
		}

		#endregion
	}

	[ContractClassFor( typeof( BaseSettingsProvider<> ) )]
	internal abstract class BaseSettingsProviderContracts<T> : BaseSettingsProvider<T> where T : class,new()
	{
		protected override string GetSettingsLocation( Assembly mainAssembly )
		{
			Contract.Requires( mainAssembly != null );
			Contract.Ensures( !String.IsNullOrWhiteSpace( Contract.Result<string>() ) );

			return null;
		}

		protected override Dictionary<string , object> LoadData( string location )
		{
			Contract.Requires( location != null );
			Contract.Ensures( Contract.Result<Dictionary<string , object>>() != null );

			return null;
		}

		protected override void SaveData( string location , Dictionary<string , object> dict )
		{
			Contract.Requires( location != null );
			Contract.Requires( dict != null );
		}
	}
}
