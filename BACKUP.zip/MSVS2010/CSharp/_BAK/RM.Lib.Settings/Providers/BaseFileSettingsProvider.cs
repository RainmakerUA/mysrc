﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.IO;
using System.Reflection;

namespace RM.Lib.Settings.Providers
{
	[ContractClass( typeof( BaseFileSettingsProviderContracts<> ) )]
	public abstract class BaseFileSettingsProvider<T> : BaseSettingsProvider<T> where T : class,new()
	{
		private const string _EXT = ".dat";

		protected BaseFileSettingsProvider()
		{
		}

		protected BaseFileSettingsProvider( T initialData )
			: base( initialData )
		{
		}

		protected virtual string Extension
		{
			get { return _EXT; }
		}

		protected abstract void SerializeToFile( string filename , Dictionary<string , object> dictionary );
		protected abstract void DeserializeFromFile( string filename , out Dictionary<string , object> dictionary );

		protected override string GetSettingsLocation( Assembly mainAssembly )
		{
			return Path.ChangeExtension( mainAssembly.Location , Extension );
		}

		protected override Dictionary<string , object> LoadData( string location )
		{
			throw new NotImplementedException();
		}

		protected override void SaveData( string location , Dictionary<string , object> data )
		{
			throw new NotImplementedException();
		}
	}

	[ContractClassFor( typeof( BaseFileSettingsProvider<> ) )]
	internal abstract class BaseFileSettingsProviderContracts<T> : BaseFileSettingsProvider<T> where T : class,new()
	{
		protected override void SerializeToFile( string filename , Dictionary<string , object> dictionary )
		{
			Contract.Requires( !String.IsNullOrWhiteSpace( filename ) );
			Contract.Requires( dictionary != null );
			Contract.EnsuresOnThrow<SettingsException>( true );
			Contract.EnsuresOnThrow<Exception>( false );
		}

		protected override void DeserializeFromFile( string filename , out Dictionary<string , object> dictionary )
		{
			Contract.Requires( !String.IsNullOrWhiteSpace( filename ) );
			Contract.Ensures( Contract.ValueAtReturn( out dictionary ) != null );
			Contract.EnsuresOnThrow<SettingsException>( true );
			Contract.EnsuresOnThrow<Exception>( false );

			dictionary = null;
		}
	}
}
