﻿using System;
using System.Collections;
using System.Reflection;
using System.Runtime.Serialization;

namespace RM.Lib.Settings.Utility
{
	public static class DataHelper
	{
	}
}
