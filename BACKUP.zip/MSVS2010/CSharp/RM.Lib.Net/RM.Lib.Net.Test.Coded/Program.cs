﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;
using RM.Lib.Net.Contracts.Serialization;

namespace RM.Lib.Net.Test.Coded
{
	[Binarizable]
	[Serializable]
	public class SerTest
	{
		public string Name { get; set; }
		public AttributeTargets Target { get; set; }
		public Guid ID { get; set; }

		//[NonBinarized]
		public SerTest Parent1 { get; set; }
		public SerTest Parent2 { get; set; }
	}

	internal static class Program
	{
		static void Main(string[] args)
		{
			var p = new SerTest {ID = Guid.NewGuid(), Name = "Tarent"};
			var obj = new SerTest
			          	{
			          		ID = Guid.NewGuid(),
							Name = "Test Object для меня…",
							Target = AttributeTargets.Constructor,
							Parent1 = p,
							Parent2 = p
			          	};
			var eq = ReferenceEquals(obj.Parent1, obj.Parent2);
			//obj.Parent = obj;

			//using (var fs = new FileStream(@"D:\test.bin", FileMode.Create, FileAccess.Write))
			//{
			//    fs.WriteBinary(obj);
			//}

			//SerTest deser;
			//using (var fs = new FileStream(@"D:\test.bin", FileMode.Open, FileAccess.Read))
			//{
			//    deser = fs.ReadBinary<SerTest>();
			//}


			using (var fs = new FileStream(@"D:\test_xs.xml", FileMode.Create, FileAccess.Write))
			{
				new XmlSerializer(typeof (SerTest)).Serialize(fs,obj);
			}

			SerTest deser_bf;
			using (var fs = new FileStream(@"D:\test_xs.xml", FileMode.Open, FileAccess.Read))
			{
				deser_bf = (SerTest) new XmlSerializer(typeof (SerTest)).Deserialize(fs);
			}
			eq = ReferenceEquals(deser_bf.Parent1, deser_bf.Parent2);
		}
	}
}
