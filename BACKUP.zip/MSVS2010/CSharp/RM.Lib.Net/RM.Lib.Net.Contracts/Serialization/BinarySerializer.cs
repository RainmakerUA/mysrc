﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using RM.Lib.Net.Contracts.Serialization.Internal;
using Stream = System.IO.Stream;

namespace RM.Lib.Net.Contracts.Serialization
{
	internal static class BinarySerializer
	{
		private static ObjectCache _cache;

		public static void Serialize(Stream stream, object obj)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}

			if (obj == null)
			{
				throw new ArgumentNullException("obj");
			}

			_cache = new ObjectCache();
			WriteObject(new StreamWriter(stream), obj);
		}

		public static T Deserialize<T>(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}

			_cache = new ObjectCache();
			return (T)ReadObject(new StreamReader(stream));
		}

		private static void WriteObject(StreamWriter w, object obj)
		{
			var type = obj == null ? null : obj.GetType();
			var entry = ObjectEntry.GetEntryDescription(type);
			var kind = entry.Kind;

			switch (kind)
			{
				case EntryKind.Null:
					w.WriteKind(kind);
					break;

				case EntryKind.Bool:
					w.WriteKind(kind);
					w.WriteByte((byte)((bool)obj ? 1 : 0));
					break;

				case EntryKind.Byte:
					w.WriteKind(kind);
					w.WriteByte((byte)obj);
					break;

				case EntryKind.SByte:
					w.WriteKind(kind);
					w.WriteByte((byte)(sbyte)obj);
					break;

				case EntryKind.Short:
					w.WriteKind(kind);
					w.WriteShort((short)obj);
					break;

				case EntryKind.UShort:
					w.WriteKind(kind);
					w.WriteShort((short)(ushort)obj);
					break;

				case EntryKind.Int:
					w.WriteKind(kind);
					w.WriteInt((int)obj);
					break;

				case EntryKind.UInt:
					w.WriteKind(kind);
					w.WriteInt((int)(uint)obj);
					break;

				case EntryKind.Long:
					w.WriteKind(kind);
					w.WriteLong((long)obj);
					break;

				case EntryKind.ULong:
					w.WriteKind(kind);
					w.WriteLong((long)(ulong)obj);
					break;

				case EntryKind.Char:
					w.WriteKind(kind);
					w.WriteChar((char)obj);
					break;

				case EntryKind.Float:
					w.WriteKind(kind);
					w.WriteFloat((float)obj);
					break;

				case EntryKind.Double:
					w.WriteKind(kind);
					w.WriteDouble((double)obj);
					break;

				case EntryKind.Decimal:
					w.WriteKind(kind);

					var dec = (decimal)obj;
					w.WriteInt(GetFieldValue<decimal, int>(dec, "lo"));
					w.WriteInt(GetFieldValue<decimal, int>(dec, "mid"));
					w.WriteInt(GetFieldValue<decimal, int>(dec, "hi"));
					w.WriteInt(GetFieldValue<decimal, int>(dec, "flags"));
					break;

				case EntryKind.DateTime:
					w.WriteKind(kind);
					var data = GetFieldValue<DateTime, ulong>((DateTime)obj, "dateData");
					w.WriteLong((long)data);
					break;

				case EntryKind.Guid:
					w.WriteKind(kind);
					w.WriteBytes(((Guid)obj).ToByteArray());
					break;

				case EntryKind.String:
					w.WriteKind(kind);
					w.WriteString((string)obj);
					break;

				case EntryKind.Array:
					w.WriteKind(kind);

					var arr = (Array)obj;
					var len = arr.Length;
					w.WriteTypeName(entry.ElementType);
					w.WriteInt(len);

					for (int i = 0; i < len; i++)
					{
						WriteObject(w, arr.GetValue(i));
					}
					break;

				case EntryKind.Collection:
					w.WriteKind(kind);
					w.WriteTypeName(entry.ElementType);
					var enu = (IEnumerable<object>)obj;
					foreach (var o in enu)
					{
						WriteObject(w, o);
					}
					w.WriteKind(EntryKind.ObjectEnd);
					break;

				case EntryKind.Object:
					var memberNames = entry.MemberNames;
					//var idx = _cache.IndexOf(obj);
					//if (idx == -1)
					//{
						//_cache.Add(obj);
						w.WriteKind(kind);
						w.WriteTypeName(type);
						foreach (var name in memberNames)
						{
							WriteObject(w, GetMemberValue(obj, type, name));
							w.WriteString(name);
						}
						w.WriteKind(EntryKind.ObjectEnd);
					//}
					//else
					//{
					//    w.WriteKind(EntryKind.ObjectRef);
					//    w.WriteInt(idx);
					//}
					break;

				default:
					throw new NotSupportedException(String.Format("Unable to serialize {0}: {1}", type.Name, obj));
			}
		}

		private static object ReadObject(StreamReader r)
		{
			var kind = r.ReadKind();

			switch (kind)
			{
				case EntryKind.Null:
					return null;

				case EntryKind.Bool:
					return r.ReadByte() == 1;

				case EntryKind.Byte:
					return r.ReadByte();

				case EntryKind.SByte:
					return (sbyte)r.ReadByte();

				case EntryKind.Short:
					return r.ReadShort();

				case EntryKind.UShort:
					return (ushort)r.ReadShort();

				case EntryKind.Int:
					return r.ReadInt();

				case EntryKind.UInt:
					return (uint)r.ReadInt();

				case EntryKind.Long:
					return r.ReadLong();

				case EntryKind.ULong:
					return (ulong)r.ReadLong();

				case EntryKind.Char:
					return r.ReadChar();

				case EntryKind.Float:
					return r.ReadFloat();

				case EntryKind.Double:
					return r.ReadDouble();

				case EntryKind.Decimal:
					var constructors = typeof(decimal).GetConstructors(BindingFlags.Instance | BindingFlags.NonPublic);
					foreach (var constr in constructors)
					{
						var pars = constr.GetParameters();
						var @int = typeof(int);

						if (pars.Length == 4 && pars[0].ParameterType == @int
												&& pars[1].ParameterType == @int
												&& pars[2].ParameterType == @int
												&& pars[3].ParameterType == @int)
						{
							return constr.Invoke(new object[]
							                     	{
							                     		r.ReadInt(),
							                     		r.ReadInt(),
							                     		r.ReadInt(),
							                     		r.ReadInt()
							                     	});
						}
					}
					throw new InvalidOperationException();

				case EntryKind.DateTime:
					constructors = typeof(DateTime).GetConstructors(BindingFlags.Instance | BindingFlags.NonPublic);
					foreach (var constr in constructors)
					{
						var pars = constr.GetParameters();
						var @ulong = typeof(ulong);

						if (pars.Length == 1 && pars[0].ParameterType == @ulong)
						{
							return constr.Invoke(new object[] { (ulong)r.ReadLong() });
						}
					}
					throw new InvalidOperationException();

				case EntryKind.Guid:
					return new Guid(r.ReadBytes(16));

				case EntryKind.String:
					return r.ReadString();

				case EntryKind.Array:
					var arrElType = r.ReadType();
					var len = r.ReadInt();
					var arr = Array.CreateInstance(arrElType, len);
					for (int i = 0; i < len; i++)
					{
						arr.SetValue(ReadObject(r), i);
					}
					return arr;

				case EntryKind.Collection:
					var elType = r.ReadType();
					var listType = typeof(List<>).MakeGenericType(elType);
					var list = Activator.CreateInstance(listType);
					var add = listType.GetMethod("Add", new[] { elType });

					object res;
					while ((res = ReadObject(r)) != ObjectEnd.Value)
					{
						add.Invoke(list, new[] { res });
					}
					return list;

				case EntryKind.Object:
					var type = r.ReadType();
					var ctor = type.GetConstructors(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public)
									.FirstOrDefault(c => c.GetParameters().Length == 0);
					if (ctor == null)
					{
						throw new NotSupportedException();
					}

					var obj = ctor.Invoke(null);
					object innerVal;
					while ((innerVal = ReadObject(r)) != ObjectEnd.Value)
					{
						var name = r.ReadString();
						SetMemberValue(obj, type, name, innerVal);
					}

					return obj;

				case EntryKind.ObjectEnd:
					return ObjectEnd.Value;

				default:
					throw new NotSupportedException(String.Format("Unable to deserialize!"));
			}
		}

		#region get/set field

		private static TOut GetFieldValue<TIn, TOut>(TIn obj, string fieldName)
		{
			var field = typeof(TIn).GetField(fieldName, BindingFlags.NonPublic | BindingFlags.Instance);
			return (TOut)field.GetValue(obj);
		}

		//private static void SetFieldValue<TIn>(TIn obj, string fieldName, object value)
		//{
		//    var field = typeof(TIn).GetField(fieldName, BindingFlags.NonPublic | BindingFlags.Instance);
		//    field.SetValue(obj, value);
		//}

		private static object GetMemberValue(object obj, Type type, string memberName)
		{
			object result;
			var prop = type.GetProperty(memberName);
			if (prop != null)
			{
				result = prop.GetValue(obj, null);
			}
			else
			{
				var field = type.GetField(memberName);
				if (field != null)
				{
					result = field.GetValue(obj);
				}
				else
				{
					throw new InvalidOperationException();
				}
			}

			return result;
		}

		private static void SetMemberValue(object obj, Type type, string memberName, object value)
		{
			var prop = type.GetProperty(memberName);
			if (prop != null)
			{
				prop.SetValue(obj, value, null);
			}
			else
			{
				var field = type.GetField(memberName);
				if (field != null)
				{
					field.SetValue(obj, value);
				}
				else
				{
					throw new InvalidOperationException();
				}
			}
		}

		#endregion
	}
}
