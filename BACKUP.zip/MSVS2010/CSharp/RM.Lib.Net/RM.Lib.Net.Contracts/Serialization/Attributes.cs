﻿using System;

namespace RM.Lib.Net.Contracts.Serialization
{
	[AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = false)]
	public class BinarizableAttribute : Attribute
	{
	}

	[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, Inherited = false, AllowMultiple = false)]
	public class NonBinarizedAttribute : Attribute
	{
	}
}