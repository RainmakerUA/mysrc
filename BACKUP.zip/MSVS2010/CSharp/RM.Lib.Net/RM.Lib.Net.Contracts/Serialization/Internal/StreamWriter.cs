﻿using System;
using System.IO;
using System.Reflection;
using System.Text;

namespace RM.Lib.Net.Contracts.Serialization.Internal
{
	internal sealed class StreamWriter
	{
		private readonly Stream _stream;

		public StreamWriter(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}

			if (!stream.CanWrite)
			{
				throw new NotSupportedException("Stream does not support writing!");
			}

			_stream = stream;
		}

		public void WriteKind(EntryKind kind)
		{
			_stream.WriteByte((byte)kind);
		}

		public void WriteByte(byte b)
		{
			_stream.WriteByte(b);
		}

		public void WriteShort(short s)
		{
			Write(BitConverter.GetBytes(s));
		}

		public void WriteInt(int i)
		{
			Write(BitConverter.GetBytes(i));
		}

		public void WriteLong(long l)
		{
			Write(BitConverter.GetBytes(l));
		}

		public void WriteChar(char c)
		{
			WriteInt(c);
		}

		public void WriteFloat(float f)
		{
			Write(BitConverter.GetBytes(f));
		}

		public void WriteDouble(double d)
		{
			Write(BitConverter.GetBytes(d));
		}

		public void WriteString(string str)
		{
			var bytes = Encoding.UTF8.GetBytes(str);
			WriteInt(bytes.Length);
			Write(bytes);
		}

		public void WriteTypeName(Type type)
		{
			var name = type.Assembly == Assembly.GetExecutingAssembly() || type.Assembly.FullName.Contains("mscorlib")
						? type.FullName
						: type.AssemblyQualifiedName;
			WriteString(name);
		}

		public void WriteBytes(byte[] bytes)
		{
			Write(bytes);
		}

		private void Write(byte[] bytes)
		{
			_stream.Write(bytes, 0, bytes.Length);
		}
	}
}
