﻿using System;
using System.Collections.Generic;

namespace RM.Lib.Net.Contracts.Serialization.Internal
{
	internal sealed class ObjectCache
	{
		private readonly List<object> _list = new List<object>();

		public int Count
		{
			get { return _list.Count; }
		}

		public int Add(object obj, bool throwIfContained = true)
		{
			var index = IndexOf(obj);
			if (index == -1)
			{
				_list.Add(obj);
				return _list.Count - 1;
			}

			if (!throwIfContained)
			{
				return index;
			}

			throw new ArgumentException("Object already exists!");
		}

		public bool Contains(object obj)
		{
			return IndexOf(obj) > -1;
		}

		public int IndexOf(object obj)
		{
			return _list.IndexOf(obj);
		}
	}
}
