﻿
namespace RM.Lib.Net.Contracts.Serialization.Internal
{
	internal sealed class ObjectEnd
	{
		public static readonly ObjectEnd Value = new ObjectEnd();

		private ObjectEnd()
		{
		}
	}
}
