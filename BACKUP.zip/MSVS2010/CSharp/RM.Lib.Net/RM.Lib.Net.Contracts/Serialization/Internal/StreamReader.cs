﻿using System;
using System.IO;
using System.Text;

namespace RM.Lib.Net.Contracts.Serialization.Internal
{
	internal sealed class StreamReader
	{
		private const int _SHORT = 2;
		private const int _INT = 4;
		private const int _LONG = 8;

		private const int _FLOAT = _INT;
		private const int _DOUBLE = _LONG;

		private readonly Stream _stream;

		public StreamReader(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException("stream");
			}

			if (!stream.CanRead)
			{
				throw new NotSupportedException("Stream does not support reading!");
			}

			_stream = stream;
		}

		public EntryKind ReadKind()
		{
			return (EntryKind)ReadByte();
		}

		public byte ReadByte()
		{
			var res = _stream.ReadByte();
			if (res < -1)
			{
				throw new InvalidOperationException("End of stream!");
			}

			return (byte)res;
		}

		public short ReadShort()
		{
			return BitConverter.ToInt16(Read(_SHORT), 0);
		}

		public int ReadInt()
		{
			return BitConverter.ToInt32(Read(_INT), 0);
		}

		public long ReadLong()
		{
			return BitConverter.ToInt64(Read(_LONG), 0);
		}

		public char ReadChar()
		{
			return (char)ReadInt();
		}

		public float ReadFloat()
		{
			return BitConverter.ToSingle(Read(_FLOAT), 0);
		}

		public double ReadDouble()
		{
			return BitConverter.ToDouble(Read(_DOUBLE), 0);
		}

		public string ReadString()
		{
			var len = ReadInt();
			return Encoding.UTF8.GetString(Read(len), 0, len);
		}

		public Type ReadType()
		{
			return Type.GetType(ReadString(), true);
		}

		public byte[] ReadBytes(int count)
		{
			return Read(count);
		}

		private byte[] Read(int count)
		{
			var buffer = new byte[count];
			if (count > _stream.Read(buffer, 0, count))
			{
				throw new InvalidOperationException(String.Format("Cannot read {0} bytes", count));
			}

			return buffer;
		}
	}
}
