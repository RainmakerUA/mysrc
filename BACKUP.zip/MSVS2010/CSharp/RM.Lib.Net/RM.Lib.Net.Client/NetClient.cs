﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RM.Lib.Net.Client
{
	public class NetClient : IDisposable
	{
		#region Disposable

		private bool _isDisposed;

		~NetClient()
		{
			Dispose(false);
		}

		protected virtual void Dispose(bool disposing)
		{
			if (!_isDisposed)
			{
				if (disposing)
				{
					// Free other state (managed objects).
				}

				// Free your own state (unmanaged objects).
				// Set large fields to null.

				_isDisposed = true;
			}
		}

		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		#endregion
	}
}
