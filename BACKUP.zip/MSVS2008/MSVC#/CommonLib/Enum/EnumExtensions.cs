﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace RM.CommonLib.Enum
{
	public static class EnumExtensions
	{
		public static string GetDescription( this System.Enum enumValue )
		{
			var enumType = enumValue.GetType();
			var attrs = enumType.GetCustomAttributes( typeof( HasDescriptionsAttribute ) , false );

			if ( attrs.Length > 0 )
			{
				var values = enumType.GetFields( BindingFlags.Public | BindingFlags.Static );
				foreach ( var value in values )
				{
					if ( enumValue.Equals( value.GetValue( null ) ) )
					{
						var valueAttrs = value.GetCustomAttributes( typeof( ValueDescriptionAttribute ) , false );
						if ( valueAttrs.Length > 0 )
						{
							var desc = valueAttrs[ 0 ] as ValueDescriptionAttribute;
							return desc == null || String.IsNullOrEmpty( desc.Description )
									? ValueDescriptionAttribute.Empty
									: desc.Description;
						}
					}
				}
			}
			return enumValue.ToString();
		}
	}
}