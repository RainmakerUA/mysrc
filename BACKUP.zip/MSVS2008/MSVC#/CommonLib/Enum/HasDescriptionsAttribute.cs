﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RM.CommonLib.Enum
{
	[AttributeUsage( AttributeTargets.Enum , AllowMultiple = false , Inherited = false )]
	public sealed class HasDescriptionsAttribute : Attribute
	{
	}
}
