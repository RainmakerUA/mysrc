﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RM.CommonLib.Enum
{
	[AttributeUsage( AttributeTargets.Field , AllowMultiple = false , Inherited = false )]
	public sealed class ValueDescriptionAttribute : Attribute
	{
		internal const string Empty = "[no description provided]";

		private readonly string _description;

		public ValueDescriptionAttribute( string description )
			: base()
		{
			_description = description;
		}

		public string Description
		{
			get
			{
				return _description;
			}
		}
	}
}