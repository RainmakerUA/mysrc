﻿using System;
using System.ComponentModel;
using System.Windows;

namespace BspWadResolver
{
    /// <summary>
    /// Interaction logic for ExceptionWindow.xaml
    /// </summary>
    public partial class ExceptionWindow : Window
    {
        private class ExceptionWrapper : INotifyPropertyChanged
        {
            private Exception exception;

            public Exception Exception
            {
                get
                {
                    return exception;
                }
                set
                {
                    exception = value;
                    OnPropertyChanged( "Exception" );
                }
            }

            private void OnPropertyChanged( string propName )
            {
                if ( PropertyChanged != null )
                {
                    PropertyChanged( this , new PropertyChangedEventArgs( propName ) );
                }
            }

            #region INotifyPropertyChanged Members

            public event PropertyChangedEventHandler PropertyChanged;

            #endregion
        }

        private readonly ExceptionWrapper exception;

        public ExceptionWindow()
        {
            exception = new ExceptionWrapper();
            InitializeComponent();
            DataContext = exception;
        }

        public static void ShowException(Exception e)
        {
            ExceptionWindow window = new ExceptionWindow();
            window.exception.Exception = e;
            window.ShowDialog();
        }


        private void OnShowInnerException( object sender , RoutedEventArgs e )
        {
            if ( exception.Exception.InnerException != null )
            {
                ShowException( exception.Exception.InnerException );
            }
        }

        private void OnClose( object sender , RoutedEventArgs e )
        {
            Close();
        }
    }
}
