using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Reflection;

namespace RM.CommonLib
{
	/// <summary>
	/// Provides XML serialization with gzip compression.
	/// </summary>
	public static class XmlZ
	{
		/// <summary>
		/// XML-Z Serialization Exception.
		/// </summary>
		public class XmlZException : Exception
		{
			public XmlZException()
				: base( "XmlZ exception thrown!" )
			{
				// Do nothing.
			}

			public XmlZException( string message )
				: base( message )
			{
				// Do nothing.
			}

			public XmlZException( string message , Exception innerException )
				: base( message , innerException )
			{
				// Do nothing.
			}

			protected XmlZException( SerializationInfo info , StreamingContext context )
				: base( info , context )
			{
				// Do nothing.
			}
		}

		public static void Serialize( this object obj , string filename )
		{
			Serialize( obj , filename , true );
		}

		public static void Serialize( this object obj , string filename , bool overwrite )
		{
			if ( String.IsNullOrEmpty( filename ) )
			{
				throw new ArgumentException( "Filename cannot be null or empty!" , "filename" );
			}

			if ( File.Exists( filename ) && !overwrite )
			{
				throw new InvalidOperationException( "File already exists. Cannot overwrite it!" );
			}

			try
			{
				using ( var fs = File.Open( filename , overwrite ? FileMode.Create : FileMode.CreateNew , FileAccess.Write , FileShare.Read ) )
				{
					using ( var cs = new GZipStream( fs , CompressionMode.Compress ) )
					{
						var ser = new XmlSerializer( obj.GetType() );
						ser.Serialize( cs , obj );
					}
				}
			}
			catch ( Exception e )
			{
				throw new XmlZException( "Serialization failed!" , e );
			}
		}


		public static T Deserialize<T>( string filename )
		{
			return Deserialize<T>( filename , true );
		}

		public static T Deserialize<T>( string filename , bool useDefault )
		{
			return (T) Deserialize( typeof( T ) , filename , useDefault );
		}

		public static object Deserialize( Type targetType , string filename , bool useDefault )
		{
			object obj;

			if ( String.IsNullOrEmpty( filename ) )
			{
				throw new ArgumentException( "Filename cannot be null or empty!" , "filename" );
			}

			ConstructorInfo[] ctors = targetType.GetConstructors( BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic );

			ConstructorInfo defCtor = ctors.FirstOrDefault( ctor => ctor.GetParameters().Length == 0 );

			if ( ctors.Length == 0 || defCtor == null )
			{
				throw new ArgumentException( "TargetType must have default constructor!" , "targetType" );
			}

			if ( !File.Exists( filename ) && useDefault )
			{
				obj = defCtor.Invoke( new object[ 0 ] );
			}
			else
			{
				try
				{
					using ( var fs = File.Open( filename , FileMode.Open , FileAccess.Read , FileShare.Read ) )
					{
						using ( var cs = new GZipStream( fs , CompressionMode.Decompress ) )
						{
							var ser = new XmlSerializer( targetType );
							obj = ser.Deserialize( cs );
						}
					}
				}
				catch ( Exception e )
				{
					if ( useDefault )
					{
						obj = defCtor.Invoke( new object[ 0 ] );
					}
					else
					{
						throw new XmlZException( "Deserialization failed!" , e );
					}
				}
			}

			return obj;
		}
	}
}
