﻿namespace ManilaHash
{
    partial class FMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtBoxName = new System.Windows.Forms.TextBox();
            this.txtBoxHash = new System.Windows.Forms.TextBox();
            this.chkBoxNameStart = new System.Windows.Forms.CheckBox();
            this.chkBoxAddManila = new System.Windows.Forms.CheckBox();
            this.btnHash = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnCopy = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtBoxName
            // 
            this.txtBoxName.Location = new System.Drawing.Point(13, 13);
            this.txtBoxName.Name = "txtBoxName";
            this.txtBoxName.Size = new System.Drawing.Size(259, 20);
            this.txtBoxName.TabIndex = 0;
            this.txtBoxName.WordWrap = false;
            // 
            // txtBoxHash
            // 
            this.txtBoxHash.Location = new System.Drawing.Point(12, 93);
            this.txtBoxHash.Name = "txtBoxHash";
            this.txtBoxHash.ReadOnly = true;
            this.txtBoxHash.Size = new System.Drawing.Size(217, 20);
            this.txtBoxHash.TabIndex = 1;
            // 
            // chkBoxNameStart
            // 
            this.chkBoxNameStart.AutoSize = true;
            this.chkBoxNameStart.Location = new System.Drawing.Point(13, 40);
            this.chkBoxNameStart.Name = "chkBoxNameStart";
            this.chkBoxNameStart.Size = new System.Drawing.Size(184, 17);
            this.chkBoxNameStart.TabIndex = 2;
            this.chkBoxNameStart.Text = "&Prepend \"\\windows\" to the name";
            this.chkBoxNameStart.UseVisualStyleBackColor = true;
            // 
            // chkBoxAddManila
            // 
            this.chkBoxAddManila.AutoSize = true;
            this.chkBoxAddManila.Location = new System.Drawing.Point(13, 64);
            this.chkBoxAddManila.Name = "chkBoxAddManila";
            this.chkBoxAddManila.Size = new System.Drawing.Size(168, 17);
            this.chkBoxAddManila.TabIndex = 3;
            this.chkBoxAddManila.Text = "&Append \"_manila\" to the hash";
            this.chkBoxAddManila.UseVisualStyleBackColor = true;
            // 
            // btnHash
            // 
            this.btnHash.Location = new System.Drawing.Point(203, 40);
            this.btnHash.Name = "btnHash";
            this.btnHash.Size = new System.Drawing.Size(68, 23);
            this.btnHash.TabIndex = 4;
            this.btnHash.Text = "&Hash";
            this.btnHash.UseVisualStyleBackColor = true;
            this.btnHash.Click += new System.EventHandler(this.btnHash_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(203, 64);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(68, 23);
            this.btnQuit.TabIndex = 5;
            this.btnQuit.Text = "E&xit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnCopy
            // 
            this.btnCopy.Location = new System.Drawing.Point(235, 93);
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(37, 20);
            this.btnCopy.TabIndex = 6;
            this.btnCopy.Text = "^C";
            this.btnCopy.UseVisualStyleBackColor = true;
            this.btnCopy.Click += new System.EventHandler(this.btnCopy_Click);
            // 
            // FMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 122);
            this.Controls.Add(this.btnCopy);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnHash);
            this.Controls.Add(this.chkBoxAddManila);
            this.Controls.Add(this.chkBoxNameStart);
            this.Controls.Add(this.txtBoxHash);
            this.Controls.Add(this.txtBoxName);
            this.Name = "FMain";
            this.Text = "Manila Filename Hasher";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtBoxName;
        private System.Windows.Forms.TextBox txtBoxHash;
        private System.Windows.Forms.CheckBox chkBoxNameStart;
        private System.Windows.Forms.CheckBox chkBoxAddManila;
        private System.Windows.Forms.Button btnHash;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Button btnCopy;
    }
}

