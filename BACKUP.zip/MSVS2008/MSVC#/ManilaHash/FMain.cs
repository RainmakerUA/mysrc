﻿using System;
using System.Windows.Forms;

namespace ManilaHash
{
    public partial class FMain : Form
    {
        public FMain()
        {
            InitializeComponent();
        }

        private static uint CountHash(string name)
        {
            string nameStr = name.ToLower();
            uint hash = 0x1505;

            for (int c = 0; c < nameStr.Length; c++)
            {
                hash += hash << 5;
                hash += nameStr[c];
            }
            hash %= 0x80000000;
            return hash;
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            txtBoxHash.SelectAll();
            txtBoxHash.Copy();
            txtBoxHash.SelectionStart = 0;
            txtBoxHash.SelectionLength = 0;
        }

        private void btnHash_Click(object sender, EventArgs e)
        {
            string filename = (chkBoxNameStart.Checked ? @"\windows" : "") + txtBoxName.Text;
            txtBoxHash.Text = CountHash(filename).ToString("x8") + ( chkBoxAddManila.Checked ? "_manila" : "" );
        }
    }
}
