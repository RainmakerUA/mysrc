﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RM.CommonLib.Enum;

namespace CommonLibTest
{
	[HasDescriptions]
	internal enum EnumTest
	{
		[ValueDescription("Empty value of EnumTest")]
		Empty = 0,

		[ValueDescription( "First value of EnumTest" )]
		Value1,

		[ValueDescription( "Second value of EnumTest" )]
		Value2,

		[ValueDescription( "Third value of EnumTest" )]
		Value3
	}
}
