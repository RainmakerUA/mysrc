﻿using System;
using System.ComponentModel;
using System.IO;
using System.Security.Cryptography;

namespace FileHasher
{
    internal class Hasher : IDisposable
    {
        private const int CHUNKS = 99;

        private BackgroundWorker worker;
        private FileStream stream;
        private long fileSize;
        private long chunkSize;

        public Hasher( string filename )
        {
            stream = File.OpenRead( filename );
            fileSize = stream.Length;
            chunkSize = fileSize / CHUNKS;
            worker = new BackgroundWorker
            {
                WorkerSupportsCancellation = true ,
                WorkerReportsProgress = true
            };
            worker.DoWork += new DoWorkEventHandler( DoHash );
            worker.ProgressChanged += new ProgressChangedEventHandler( RaiseProgressChanged );
            worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler( WorkerCompleted );
        }

        #region IDisposable Members

        void IDisposable.Dispose()
        {
            if ( worker != null )
            {
                if ( worker.IsBusy )
                {
                    worker.CancelAsync();
                }

                worker.Dispose();
            }

            if ( stream != null )
            {
                stream.Dispose();
            }
        }

        #endregion

        public void StartHashing()
        {
            //if ...
            worker.RunWorkerAsync();
        }

        private void DoHash( object sender , DoWorkEventArgs e )
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            byte[] data = new byte[ chunkSize ];
            long total = 0;
            byte chunkNum = 0;
            int read = 0;

            md5.Initialize();
            while ( ( read = stream.Read( data , 0 , (int) chunkSize ) ) > 0 )
            {
                md5.TransformBlock( data , 0 , read , null , 0 );
                total += read;
                chunkNum++;
                worker.ReportProgress( chunkNum );
            }
            md5.TransformFinalBlock( new byte[ 0 ] , 0 , 0 );
            e.Result = new object[] { md5.Hash , total };
        }

        private void RaiseProgressChanged( object sender , ProgressChangedEventArgs e )
        {
            if ( ProgressChanged != null )
            {
                ProgressChanged( this , new HashProgressChangedEventArgs( e.ProgressPercentage ) );
            }
        }

        private void WorkerCompleted( object sender , RunWorkerCompletedEventArgs e )
        {
            object[] results;

            if ( Completed != null )
            {
                results = (object[]) e.Result;
                Completed( this , new HashCompletedEventArgs( (byte[]) results[ 0 ] , (long) results[ 1 ] ) );
            }
        }


        public event EventHandler<HashProgressChangedEventArgs> ProgressChanged;

        public event EventHandler<HashCompletedEventArgs> Completed;
    }

    internal class HashProgressChangedEventArgs : EventArgs
    {
        public HashProgressChangedEventArgs( int percentage /*, long bytesProcessed , long bytesTotal*/ )
        {
            Percentage = percentage;
            //BytesProcessed = bytesProcessed;
            //BytesTotal = bytesTotal;
        }

        public int Percentage
        {
            get;
            private set;
        }

        //public long BytesProcessed
        //{
        //    get;
        //    private set;
        //}

        //public long BytesTotal
        //{
        //    get;
        //    private set;
        //}
    }

    internal class HashCompletedEventArgs : EventArgs
    {
        public HashCompletedEventArgs( byte[] hash , long fileSize )
        {
            Hash = hash;
            FileSize = fileSize;
        }

        public byte[] Hash
        {
            get;
            private set;
        }

        public long FileSize
        {
            get;
            private set;
        }
    }
}
