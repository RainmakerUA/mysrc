﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace FileHasher
{
    /// <summary>
    /// Interaction logic for FileHasherWnd.xaml
    /// </summary>
    public partial class FileHasherWnd : Window
    {
        private const string FILEDROPDATAFORMAT = "FileDrop";

        private OpenFileDialog openDialog;
        private bool neverRendered;

        public FileHasherWnd()
        {
            InitializeComponent();

            neverRendered = true;

            openDialog = new OpenFileDialog
            {
                Filter = "All files(*.*)|*.*" ,
                CheckFileExists = true ,
                CheckPathExists = true ,
                AddExtension = true ,
                FilterIndex = 0 ,
                Multiselect = false ,
                ShowReadOnly = false ,
                ValidateNames = true ,
                Title = "Select a file"
            };

            SourceInitialized += new EventHandler(
                    ( sender , e ) =>
                    {
                        Point top = labelTopText.TranslatePoint( new Point( 0 , 0 ) , this );
                        Point bottom = labelBottomText.TranslatePoint( new Point( 0 , 0 ) , this );

                        GlassHelper.ExtendGlassFrame( this , new Thickness(
                                top.X ,
                                top.Y + labelTopText.ActualHeight ,
                                ActualWidth - ( bottom.X + labelBottomText.ActualWidth ) ,
                                ActualHeight - ( bottom.Y )
                            ) );
                    }
                );
        }

        protected override void OnContentRendered( EventArgs e )
        {
            if ( this.neverRendered )
            {
                // The window takes the size of its content because SizeToContent
                // is set to WidthAndHeight in the markup. We then allow
                // it to be set by the user, and have the content take the size
                // of the window.

                this.SizeToContent = SizeToContent.Manual;
                FrameworkElement root = this.Content as FrameworkElement;

                if ( root != null )
                {
                    root.Width = double.NaN;
                    root.Height = double.NaN;
                }

                this.neverRendered = false;
            }
            base.OnContentRendered( e );
        }

        private bool IsDataContainSingleFileName( IDataObject data )
        {
            return data.GetDataPresent( FILEDROPDATAFORMAT , true )
                && ( ( string[] ) data.GetData( FILEDROPDATAFORMAT ) ).Length == 1;
        }

        private void buttonFileSelect_Click( object sender , RoutedEventArgs e )
        {
            bool? result = openDialog.ShowDialog();
            if ( result.HasValue && result.Value )
            {
                textBoxFileName.Text = openDialog.FileName;
            }
        }

        private void HashPrgChanged( object sender , HashProgressChangedEventArgs e )
        {
            progressBarProgress.Value = e.Percentage;
        }

        private void HashComplete( object sender , HashCompletedEventArgs e )
        {
            var hasher = sender as Hasher;
            textBoxHash.Text = String.Format( "MD5 Sum: {0} | Size: {1} bytes." , String.Join( String.Empty , e.Hash.Select( b => String.Format( "{0:X2}" , b ) ).ToArray() ) , e.FileSize );
            progressBarProgress.Value = 0D;

            hasher.ProgressChanged -= HashPrgChanged;
            hasher.Completed -= HashComplete;
            ( hasher as IDisposable ).Dispose();
        }

        private void buttonHash_Click( object sender , RoutedEventArgs e )
        {
            textBoxHash.Text = String.Empty;
            var hasher = new Hasher( textBoxFileName.Text );
            hasher.ProgressChanged += HashPrgChanged;
            hasher.Completed += HashComplete;
            hasher.StartHashing();
        }

        private void Window_DragEnter( object sender , DragEventArgs e )
        {
            e.Effects = DragDropEffects.Link;
        }

        private void Window_Drop( object sender , DragEventArgs e )
        {
            if ( IsDataContainSingleFileName( e.Data ) )
            {
                textBoxFileName.Text = ( e.Data.GetData( FILEDROPDATAFORMAT , true ) as string[] )[ 0 ];
            }
        }
    }
}
