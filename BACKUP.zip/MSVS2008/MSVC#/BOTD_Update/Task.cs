﻿using System;
using System.ComponentModel;

namespace RMDevel.Task
{
    internal enum TaskState
    {
        Waiting = 0 ,
        Running ,
        Finished ,
        Failed ,
        Cancelled
    }

    internal class Task<TArg , TResult>
    {
        #region Fields
        private BackgroundWorker worker;
        private TaskState state;
        private Func<TArg , TResult> taskAction;
        #endregion

        public Task( Func<TArg , TResult> action )
        {
            taskAction = action;
            worker = new BackgroundWorker();
            worker.DoWork += new DoWorkEventHandler( OnWorkerDoWork );
            worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler( OnWorkerRunWorkerCompleted );
        }

        public TaskState State
        {
            get
            {
                if ( worker.IsBusy )
                {
                    return TaskState.Running;
                }
                else
                {
                    return state;
                }
            }
        }

        void OnWorkerDoWork( object sender , DoWorkEventArgs e )
        {
            state = TaskState.Running;
            if ( taskAction != null )
            {
                e.Result = taskAction( e.Argument is TArg ? (TArg) e.Argument : default( TArg ) );
            }
        }

        void OnWorkerRunWorkerCompleted( object sender , RunWorkerCompletedEventArgs e )
        {
            if ( e.Cancelled )
            {
                state = TaskState.Cancelled;
            }
        }


    }
}
