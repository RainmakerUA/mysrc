﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Threading;
using RMDevel;
using RMDevel.Console;

namespace BOTD_Update
{
    class Program
    {
        const string url1 = "";
        const string url2 = "";

        private static Log _log;
        private static string _dir;
        private static DateTime _now;
        private static byte _days;
        private static List<String> _files;
        private static List<String> _newfiles;

        static Program()
        {
            _log = new Log( Properties.Settings.Default.LogFile , Properties.Settings.Default.MaxLogSize );
            _now = DateTime.Today;
            _newfiles = new List<String>();
        }

        static string FormatNum( int number , byte maxChar )
        {
            string s = number.ToString();
            if ( s.Length < maxChar )
            {
                switch ( s.Length )
                {
                    case 1:
                        return " 0" + s + " ";
                    case 2:
                        return " " + s + " ";
                    case 3:
                        return "0" + s;
                    default:
                        return s;
                }
            }
            else
            {
                return s;
            }
        }

        static void HandleException(Exception exc , bool silent)
        {
            string msg = exc.GetType().ToString() + ": " + exc.Message;
            _log.WriteLog( msg );
            if ( !silent )
            {
                Console.WriteLine( "\n" + msg );
            }
        }

        static int Main(string[] args)
        {
            ResultFuncBool checkDir;
            ResultFuncStr countDays;
            ResultFuncBool makeFList;
            ResultFuncStrCol getFile;
            ResultFuncBool delFile;
            ResultFuncStr b4Sleep;

            checkDir = arg =>
                {
                    _dir = ( string ) arg;
                    try
                    {
                        Directory.CreateDirectory( _dir );
                        _log.WriteLog( "Directory OK!" );
                        return true;
                    }
                    catch ( Exception exc )
                    {
                        HandleException( exc , true );
                        return false;
                    }
                };

            countDays = arg =>
                {
                    _days = ( byte ) arg;
                    _log.WriteLog( String.Format( "Days count: {0}" , _days ) );
                    return FormatNum( _days , 4 );
                };

            makeFList = arg =>
                {
                    try
                    {
                        StringCollection formats = arg as StringCollection;
                        int urlCount = formats.Count;
                        _files = new List<String>( _days * urlCount );

                        _log.WriteLog( "Generating:" );
                        for ( int i = 0; i < _days; i++ )
                        {
                            DateTime date = _now.AddDays(-i);
                            for ( int j = 0; j < urlCount; j++ )
                            {
                                string name = String.Format( formats[ j ] , date.Month , date.Day , date.Year % 100 , date.Year / 100 );
                                _log.WriteLog( name );
                                _files.Add( name );
                            }
                        }

                        _log.WriteLog( "Done." );
                        return true;
                    }
                    catch ( Exception exc )
                    {
                        HandleException( exc , true );
                        return false;
                    }
                };

            getFile = arg =>
                {
                    string url = ( string ) arg;
                    string filename = _dir + url.Substring( url.LastIndexOf( '/' ) + 1 );
                    WebClient wc = new WebClient();
                    _log.WriteLog( url + " -> " + filename );
                    _newfiles.Add( filename );
                    try
                    {
                        if ( File.Exists( filename ) )
                        {
                            _log.WriteLog( "File exists, skipped" );
                            return new ConOutStruct { Text = "SKIP" , Color = ConsoleColor.DarkGray };
                        }
                        else
                        {
                            wc.DownloadFile( url , filename );
                            _log.WriteLog( "File fetched" );
                            return new ConOutStruct { Text = "DONE" , Color = ConsoleColor.Green };
                        }
                    }
                    catch ( Exception exc )
                    {
                        HandleException( exc , true );
                        return new ConOutStruct { Text = "FAIL" , Color = ConsoleColor.Red };
                    }
                };

            delFile = arg =>
                {
                    string filename = (string) arg;
                    try
                    {
                        File.Delete( filename );
                        _log.WriteLog( "Deleted: \"" + filename + "\"" );
                        return true;
                    }
                    catch ( Exception exc )
                    {
                        HandleException( exc , true );
                        return false;
                    }
                };

            b4Sleep = arg =>
                {
                    return FormatNum( (int) arg , 4 );
                };

            _log.WriteLog( "Update started..." );

            ConsoleOut.OutResult( checkDir , Properties.Settings.Default.ImgPath , "Checking path:" );
            ConsoleOut.OutResult( countDays ,  Properties.Settings.Default.DaysCount , "Downloading photos for days:" );
            ConsoleOut.OutResult( makeFList , Properties.Settings.Default.UrlFormats , "Generating file names:" );

            _log.WriteLog( "Downloading files" );
            Console.WriteLine( "Downloading:" );
            foreach ( string file in _files )
            {
                ConsoleOut.OutResult( getFile , file , file );
            }

            _log.WriteLog( "Deleting old files" );
            Console.WriteLine( "Deleting old files:" );
            foreach ( string file in Directory.GetFiles( _dir ) )
            {
                if ( _newfiles.Find( str => str == file ) == null )
                {
                    ConsoleOut.OutResult( delFile , file , file );
                }
            }

            _log.WriteLog(".:: LOG END ::.");
            _log.WriteLog("[======================================]");

            int sleep = Properties.Settings.Default.Sleep;
            ConsoleOut.OutResult( b4Sleep , sleep , "Waiting to exit (sec) :" );
            Thread.Sleep( sleep * 1000 );
            return 0;
        }
    }
}
