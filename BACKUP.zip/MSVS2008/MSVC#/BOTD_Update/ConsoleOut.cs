﻿using System;

namespace RMDevel.Console
{
    /// <summary>
    /// Method, returning result as text and its color
    /// </summary>
    /// <param name="arg">Method argument</param>
    /// <returns>Text and color as <see cref="ConOutStruct">ConOutStruct</see></returns>
    internal delegate ConOutStruct ResultFuncStrCol( object arg );

    /// <summary>
    /// Method, returning result as text
    /// </summary>
    /// <param name="arg">Method argument</param>
    /// <returns>Text, representing result</returns>
    internal delegate string ResultFuncStr( object arg );

    /// <summary>
    /// Method, returning boolean result
    /// </summary>
    /// <param name="arg">Method argument</param>
    /// <returns>Boolean result</returns>
    internal delegate bool ResultFuncBool( object arg );

    /// <summary>
    /// Structure, representing text and its color
    /// </summary>
    internal struct ConOutStruct
    {
        public string Text;
        public ConsoleColor Color;
    }

    /// <summary>
    /// Static class for action result printing
    /// </summary>
    internal static class ConsoleOut
    {
        private const string RES_PRE = "[";
        private const string RES_POST = "]";
        private const string S_OK = " OK ";
        private const string S_FAIL = "FAIL";
        
        private const char SPACE = '\u0020';

        private static int _ncol;
        private static System.ConsoleColor _cc_def;

        static ConsoleOut()
        {
            _ncol = System.Console.WindowWidth;
            _cc_def = System.Console.ForegroundColor;
        }

        /// <summary>
        /// Calls method and prints its result
        /// </summary>
        /// <param name="strcolFunc">Method</param>
        /// <param name="message">Caption message</param>
        public static void OutResult( ResultFuncStrCol strcolFunc , object arg , string message )
        {
            ConOutStruct result;
            int spaceCount;

            System.Console.Write( message );
            result = strcolFunc( arg );
            spaceCount = _ncol - message.Length - ( result.Text.Length + RES_PRE.Length + RES_POST.Length );
            if ( spaceCount < 0 )
            {
                spaceCount = _ncol -
                        ( result.Text.Length + message.Length + RES_PRE.Length + RES_POST.Length ) % _ncol;
            }
            System.Console.Write( new String( SPACE , spaceCount ) );
            System.Console.Write( RES_PRE );
            System.Console.ForegroundColor = result.Color;
            System.Console.Write( result.Text );
            System.Console.ForegroundColor = _cc_def;
            System.Console.Write( RES_POST );
        }

        /// <summary>
        /// Calls method and prints its result
        /// </summary>
        /// <param name="strFunc">Method</param>
        /// <param name="message">Caption message</param>
        public static void OutResult( ResultFuncStr strFunc , object arg , string message )
        {
            ResultFuncStrCol strcolFunc = a =>
            {
                return new ConOutStruct
                {
                    Text = strFunc( a ) ,
                    Color = _cc_def
                };
            };
            OutResult( strcolFunc , arg , message );
        }

        /// <summary>
        /// Calls method and prints its result
        /// </summary>
        /// <param name="boolFunc">Method</param>
        /// <param name="message">Caption message</param>
        public static void OutResult( ResultFuncBool boolFunc , object arg , string message )
        {
            ResultFuncStrCol strcolFunc = a =>
            {
                return boolFunc( a )
                    ?
                    new ConOutStruct
                    {
                        Text = S_OK ,
                        Color = ConsoleColor.Green
                    }
                    :
                    new ConOutStruct
                    {
                        Text = S_FAIL ,
                        Color = ConsoleColor.Red
                    };
            };
            OutResult( strcolFunc , arg , message );
        }
    }
}
