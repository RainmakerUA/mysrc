﻿using System;
using System.IO;
using System.Text;

namespace RMDevel
{
    /// <summary>
    /// Class, which performs logging messages to file
    /// </summary>
    internal sealed class Log
    {
        private string _logfile;

        /// <summary>
        /// Creates new Log instance
        /// </summary>
        /// <param name="filename">Log file name</param>
        public Log( string filename )
        {
            _logfile = filename;
        }

        /// <summary>
        /// Creates new Log instance and checks log file size
        /// </summary>
        /// <param name="filename">Log file name</param>
        /// <param name="maxSize">Log file maximum size</param>
        public Log( string filename , uint maxSize )
            : this( filename )
        {
            CheckClearLog( maxSize );
        }

        /// <summary>
        /// Checks log file size and clears its, if exceedes specified size
        /// </summary>
        /// <param name="maxLogSize">File size in bytes</param>
        public void CheckClearLog( uint maxLogSize )
        {
            using ( FileStream logfs = File.Open( _logfile , FileMode.OpenOrCreate ) )
            {
                if ( logfs.Length > maxLogSize )
                {
                    logfs.Close();
                    File.Delete( _logfile );
                }
            }
        }

        /// <summary>
        /// Writes message to log file
        /// </summary>
        /// <param name="log">Message to write</param>
        public void WriteLog( string log )
        {
            DateTime now;
            string s;

            if ( String.IsNullOrEmpty( _logfile ) )
            {
                throw new FieldAccessException( "Specified log file name is null or empty!" );
            }

            if ( String.IsNullOrEmpty( log ) )
            {
                throw new ArgumentNullException( "log" , "Specified log text is null or empty!" );
            }

            now = DateTime.Now;
            s = String.Format( "{0:D2}.{1:D2}.{2:D4} {3:D2}:{4:D2}:{5:D2} :: {6}\r\n" ,
                    now.Day , now.Month , now.Year , now.Hour , now.Minute , now.Second , log
                );
            File.AppendAllText( _logfile , s , Encoding.UTF8 );
        }
    }
}
