﻿using System;
using System.ComponentModel;
using System.IO;
using System.Windows;
using HLLauncher.Services;
using System.Collections.ObjectModel;

namespace HLLauncher
{
    internal class WindowMainViewModel : INotifyPropertyChanged
    {
        private const string _EXENAME = "hl.exe";
        private const string _CMDCONHEADERFMT = "Command line & console commands{0}";
        private const string _CMDCONHEADERVALUE = " ( ‼ )";

        private readonly string _hlExe;
        private readonly Game[] _games;
        private StartParameter _selectedGameStartParameter;
        private string _commandLineAdd;
        private string _consoleCommands;

		private readonly ReadOnlyCollection<IPlugin> _plugins;

        public WindowMainViewModel()
        {
            string path = LauncherService.GetExePath();

            _hlExe = Path.Combine( path , _EXENAME );
            _games = File.Exists( _hlExe ) ? LauncherService.GetFromPath( path ) : new Game[ 0 ];
            _commandLineAdd = String.Empty;
            _consoleCommands = String.Empty;

            _plugins = PluginService.GetPlugins();
        }

    	public string HlExe
        {
            get
            {
                return _hlExe;
            }
        }

        public Game[] Games
        {
            get
            {
                return _games;
            }
        }

        public Visibility ErrorTextVisibility
        {
            get
            {
                return _games.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
            }
        }

        public string CommandLineAdd
        {
            get
            {
                return _commandLineAdd;
            }
            set
            {
                _commandLineAdd = value ?? String.Empty;
                RaisePropertyChanged( "CommandLineAdd" );
                RaisePropertyChanged( "CmdConHeader" );
                UpdateStartParameter();
            }
        }

        public string ConsoleCommands
        {
            get
            {
                return _consoleCommands;
            }
            set
            {
                _consoleCommands = value ?? String.Empty;
                RaisePropertyChanged( "ConsoleCommands" );
                RaisePropertyChanged( "CmdConHeader" );
                UpdateStartParameter();
            }
        }

        public string CmdConHeader
        {
            get
            {
                return String.Format( _CMDCONHEADERFMT ,
                        String.IsNullOrEmpty( _commandLineAdd ) && String.IsNullOrEmpty( _consoleCommands )
                        ? String.Empty : _CMDCONHEADERVALUE
                    );
            }
        }

        public Game SelectedGame
        {
            get
            {
                return _selectedGameStartParameter != null ? _selectedGameStartParameter.Game : null;
            }
            set
            {
                UpdateStartParameter( value , _commandLineAdd , _consoleCommands );
                RaisePropertyChanged( "StartVisibility" );
            }
        }

        public Visibility StartVisibility
        {
            get
            {
                return ( _selectedGameStartParameter != null && _selectedGameStartParameter.Game != null )
                           ? Visibility.Visible
                           : Visibility.Hidden;
            }
        }

        public StartParameter SelectedParameter
        {
            get
            {
                return _selectedGameStartParameter;
            }
		}

		public ReadOnlyCollection<IPlugin> Plugins
		{
			get
			{
				return _plugins;
			}
		}

        private void UpdateStartParameter()
        {
            UpdateStartParameter( _selectedGameStartParameter.Game , _commandLineAdd , _consoleCommands );
        }

        private void UpdateStartParameter( Game game , string commandLine , string consoleCommands )
        {
            _selectedGameStartParameter = game == null ? null : new StartParameter( game , commandLine , consoleCommands , _hlExe );
            RaisePropertyChanged( "SelectedGame" );
            RaisePropertyChanged( "SelectedParameter" );
        }

        private void RaisePropertyChanged( string propertyName )
        {
            if ( PropertyChanged != null )
            {
                PropertyChanged( this , new PropertyChangedEventArgs( propertyName ) );
            }
        }

        public void StartGame()
        {
            LauncherService.StartGame( _selectedGameStartParameter );
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }
}
