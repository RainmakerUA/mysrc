﻿using System.Windows;

namespace HLLauncher
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private string[] _args;

        public string[] Args
        {
            get
            {
                return _args;
            }
        }

        protected override void OnStartup( StartupEventArgs e )
        {
            _args = e.Args;
            base.OnStartup( e );
        }
    }
}
