﻿using System.Windows.Media;

namespace HLLauncher
{
    internal class Game
    {
        private readonly string _name;
        private readonly ImageSource _icon;
        private readonly string _dirName;

        public string Name
        {
            get
            {
                return _name;
            }
        }

        public ImageSource Icon
        {
            get
            {
                return _icon;
            }
        }
        public string DirName
        {
            get
            {
                return _dirName;
            }
        }

        public Game(string name , ImageSource icon , string dirName )
        {
            _name = name;
            _icon = icon;
            _dirName = dirName;
        }
    }
}
