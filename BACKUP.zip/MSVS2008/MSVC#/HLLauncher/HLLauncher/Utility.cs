﻿using System;

namespace HLLauncher
{
	internal static class Utility
	{
		public static T CreateInstanceAs<T>( this Type type )
		{
			return (T) Activator.CreateInstance( type );
		}

		public static bool ImplementsInterface<TI>( this Type type )
		{
			return type.FindInterfaces( ( t , criteria ) => t == typeof( TI ) , null ).Length > 0;
		}
	}
}
