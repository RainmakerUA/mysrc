﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Diagnostics;

namespace HLLauncher.Services
{
	internal static class LauncherService
	{
		private const string _GAMFILENAME = "liblist.gam";
		private const string _UNNAMEDMODFORMAT = "Unnamed mod: {0}";
		private const string _GAMICONNAME = "game.ico";
		private const string _ICOMASK = "*.ico";
		private const string _NOICONURI = "pack://application:,,/img/no.png";

		private static readonly Regex _gamNameRegex = new Regex( "^game\\s+\"(?'name'[^\"]+)\"" , RegexOptions.Multiline );

		private static BitmapImage ImageFromUriString( string uriString )
		{
			return uriString == null ? null : new BitmapImage( new Uri( uriString ) );
		}

		private static string GetGameNameFromGamFile( string gamFile )
		{
			Match m = _gamNameRegex.Match( File.ReadAllText( gamFile ) );
			return m.Success ? m.Groups[ "name" ].Value : null;
		}

		private static string GetGameIcon( string gameDir )
		{
			string iconFile = null;
			string[] files = Directory.GetFiles( gameDir , _GAMICONNAME );

			if ( files.Length > 0 )
			{
				iconFile = files[ 0 ];
			}
			else
			{
				files = Directory.GetFiles( gameDir , _ICOMASK );
				if ( files.Length > 0 )
				{
					iconFile = files[ 0 ];
				}
			}

			return iconFile;
		}

		public static string GetExePath()
		{
			string[] args = ( Application.Current as App ).Args;
			return args.Length > 0 ? args[ 0 ] : Directory.GetCurrentDirectory();
		}

		public static Game[] GetFromPath( string path )
		{
			const string INVALID_PATH = "Path should be an absolute or relative path of existing directory!";

			if ( String.IsNullOrEmpty( path ) )
			{
				throw new ArgumentException( INVALID_PATH , "path" );
			}

			if ( !Directory.Exists( path ) )
			{
				throw new InvalidOperationException( INVALID_PATH );
			}

			return ( from dir in Directory.GetDirectories( path )
					 let files = Directory.GetFiles( dir , _GAMFILENAME )
					 where files.Length > 0
					 let dirName = new DirectoryInfo( dir ).Name
					 let gameName = GetGameNameFromGamFile( files[ 0 ] ) ?? String.Format( _UNNAMEDMODFORMAT , dirName )
					 orderby gameName
					 select new Game( gameName , ImageFromUriString( GetGameIcon( dir ) ?? _NOICONURI ) , dirName ) ).ToArray();
		}

		public static void StartGame( StartParameter parameter )
		{
			Process.Start( parameter.HlExe , parameter.CommandLine );
		}
	}
}