﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Collections.ObjectModel;

namespace HLLauncher.Services
{
	internal static class PluginService
	{
		private const string _PLUGINSUFFIX = "HLLPlugin";

		public static ReadOnlyCollection<IPlugin> GetPlugins()
		{

			string[] dlls = Directory.GetFiles(
								Path.GetDirectoryName( Assembly.GetExecutingAssembly().Location ) ,
								"*.dll"
							);

			var plugins = new List<IPlugin>();
			foreach ( string dll in dlls )
			{
				try
				{
					Assembly assembly = Assembly.LoadFile( dll );
					Type[] types = assembly.GetExportedTypes();
					plugins.AddRange( from type in types
					                  where type.FullName.EndsWith( _PLUGINSUFFIX ) && type.ImplementsInterface< IPlugin >()
					                  select type.CreateInstanceAs< IPlugin >() );
				}
				catch ( Exception )
				{
					System.Diagnostics.Debug.Assert( false );
				}
			}

			return plugins.AsReadOnly();
		}
	}
}
