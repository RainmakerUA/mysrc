﻿using System.Windows;

namespace HLLauncher
{
    public partial class WindowMain : Window
    {
        private readonly WindowMainViewModel _viewModel;

        public WindowMain()
        {
            InitializeComponent();
            _viewModel = new WindowMainViewModel();
            DataContext = _viewModel;
        }

        private void OnStart( object sender , RoutedEventArgs e )
        {
            _viewModel.StartGame();
            Close();
        }

        private void OnQuit( object sender , RoutedEventArgs e )
        {
            Close();
        }
    }
}
