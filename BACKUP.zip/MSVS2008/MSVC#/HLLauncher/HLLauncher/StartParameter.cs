﻿using System;
using System.Linq;
using System.Windows.Media;

namespace HLLauncher
{
    internal class StartParameter
    {
        private const string _SPACE = "\x20";
        private const string _GAMEARG = "-game";

        private readonly string _hlExe;
        private readonly Game _game;
        private readonly string _name;
        private readonly ImageSource _icon;
        private readonly string _commandLine;
        private readonly string _displayCommandLine;

        public StartParameter( Game game , string commandLine , string consoleCommands , string hlExe )
        {
            _hlExe = hlExe;
            _game = game;
            _name = game.Name;
            _icon = game.Icon;
            _commandLine = String.Join( _SPACE ,
                    new[]
                    {
                        _GAMEARG ,
                        game.DirName ,
                        commandLine
                    }.Concat(
                        from s in consoleCommands.Split( new[] { ';' } , StringSplitOptions.RemoveEmptyEntries )
                        where s.Trim().Length > 0
                        select "+" + s.Trim()
                    ).ToArray()
                );
            _displayCommandLine = hlExe + _SPACE + _commandLine;
        }

        public string HlExe
        {
            get
            {
                return _hlExe;
            }
        }

        public Game Game
        {
            get
            {
                return _game;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }
        }

        public ImageSource Icon
        {
            get
            {
                return _icon;
            }
        }

        public string DisplayCommandLine
        {
            get
            {
                return _displayCommandLine;
            }
        }

        public string CommandLine
        {
            get
            {
                return _commandLine;
            }
        }

    }
}
