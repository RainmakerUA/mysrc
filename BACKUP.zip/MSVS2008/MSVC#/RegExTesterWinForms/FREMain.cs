﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Drawing;
using System.IO;
using System.Net;
using System.Xml.Serialization;

namespace RegExTester
{
    public partial class FREMain : Form
    {
        private readonly RegexOptions[] _optionsList =
               {
                   RegexOptions.IgnoreCase, RegexOptions.Multiline, RegexOptions.ExplicitCapture,
                   RegexOptions.Compiled, RegexOptions.Singleline, RegexOptions.IgnorePatternWhitespace,
                   RegexOptions.RightToLeft
               };

        private const string _regexoptHelp = "RegEx Options help:\n\n"
                + "• Ignore case - Case-insensitive matching ([A-Z] matches a-z too)\n\n"
                + "• Multiline - Changes the meaning of \"^\" and \"$\" so they match at the beginning and end of any line,\n"
                + "   and not just the beginning and end of the entire text\n\n"
                + "• Explicit capture - The only valid captures are explicitly named or numbered groups of the form (?<name>…)\n"
                + "   This allows unnamed parentheses to act as noncapturing groups\n\n"
                + "• Singleline - Dot \".\" matches newline \"\\n\" as well\n\n"
                + "• Ignore whitespace - Unescaped white space in the pattern is ignored (except for character classes)\n\n"
                + "• Right to left - Search will be from right to left";

        List<MatchItem> _matches;

        public FREMain()
        {
            InitializeComponent();
            comboBoxEncoding.Items.AddRange(
                    new object[] {
                        new EncodingWrapper(Encoding.Unicode),
                        new EncodingWrapper(Encoding.BigEndianUnicode),
                        new EncodingWrapper(Encoding.UTF8),
                        new EncodingWrapper(Encoding.GetEncoding(1251)),
                        new EncodingWrapper(Encoding.GetEncoding("ISO-8859-1")),
                        new EncodingWrapper(Encoding.GetEncoding("ISO-8859-5"))
                    }
                );
            comboBoxEncoding.SelectedIndex = 0;
            treeViewMatches.Nodes.Clear();
        }

        private void ShowException( Exception exc )
        {
            MessageBox.Show( exc.Message , exc.GetType().ToString() ,
                MessageBoxButtons.OK , MessageBoxIcon.Error );
        }

        private void UpdateTreeView()
        {
            treeViewMatches.Nodes.Clear();

            foreach ( MatchItem mi in _matches )
            {
                TreeNode mnode = new TreeNode( mi.ToString() , 0 , 0 );
                mnode.Tag = mi;

                for ( int i = 1 ; i < mi.Groups.Count ; i++ )
                {
                    GroupItem gi = mi.Groups[ i ];
                    TreeNode gnode = new TreeNode( gi.ToString() , 1 , 1 );
                    gnode.Tag = gi;
                    mnode.Nodes.Add( gnode );
                }
                treeViewMatches.Nodes.Add( mnode );
            }
        }

        #region SourceText

        #region RadioButtons

        private void radioBtnURL_Click( object sender , EventArgs e )
        {
            txtBoxSrc.ReadOnly = false;
            txtBoxSrc.Text = "";
            txtBoxSrc.Enabled = comboBoxEncoding.Enabled = true;
            comboBoxEncoding.SelectedIndex = 2;
        }

        private void radioBtnFile_Click( object sender , EventArgs e )
        {
            txtBoxSrc.ReadOnly = txtBoxSrc.Enabled = comboBoxEncoding.Enabled = true;
            // Get filename
            if ( openFileDlg.ShowDialog() == DialogResult.OK )
            {
                txtBoxSrc.Text = openFileDlg.FileName;
            }
            else
            {
                txtBoxSrc.Text = "(no file selected)";
            }
            comboBoxEncoding.SelectedIndex = 3;
        }

        private void radioBtnClipboard_Click( object sender , EventArgs e )
        {
            txtBoxSrc.Enabled = comboBoxEncoding.Enabled = false;
            txtBoxSrc.Text = "";
            comboBoxEncoding.SelectedIndex = 0;
        }

        #endregion


        private void btnLoad_Click( object sender , EventArgs e )
        {
            try
            {
                if ( radioBtnURL.Checked )
                {
                    WebClient wc = new WebClient();
                    byte[] data = wc.DownloadData( txtBoxSrc.Text );
                    Encoding enc = ( comboBoxEncoding.Items[ comboBoxEncoding.SelectedIndex ]
                            as EncodingWrapper ).EncodingValue;
                    txtBoxText.Clear();
                    txtBoxText.Text = enc.GetString( data );
                    return;
                }

                if ( radioBtnFile.Checked )
                {
                    Encoding enc = ( comboBoxEncoding.Items[ comboBoxEncoding.SelectedIndex ]
                            as EncodingWrapper ).EncodingValue;
                    byte[] bytes = File.ReadAllBytes( txtBoxSrc.Text );
                    txtBoxText.Clear();
                    txtBoxText.Text = enc.GetString( bytes );
                    return;
                }

                if ( radioBtnClipboard.Checked )
                {
                    txtBoxText.Clear();
                    txtBoxText.Paste();
                    return;
                }
            }
            catch ( Exception exc )
            {
                ShowException( exc );
            }
        }

        #endregion

        #region Buttons

        private void btnREMatch_Click( object sender , EventArgs e )
        {
            RegexOptions reo = RegexOptions.None;
            for ( int i = 0 ; i < chkListBoxREOpt.CheckedIndices.Count ; i++ )
            {
                int idx = chkListBoxREOpt.CheckedIndices[ i ];
                reo |= _optionsList[ idx ];
            }

            Regex re = new Regex( txtBoxRegExp.Text , reo );
            MatchCollection mc = re.Matches( txtBoxText.Text );

            _matches = MatchItem.MatchCollectionToItemList( re , mc );
            UpdateTreeView();
        }

        private void btnOptHelp_Click( object sender , EventArgs e )
        {
            MessageBox.Show( _regexoptHelp , Text , MessageBoxButtons.OK , MessageBoxIcon.Information );
        }

        private void btnExit_Click( object sender , EventArgs e )
        {
            Close();
        }

        #endregion

        #region Save/Load state

        private void btnSaveState_Click( object sender , EventArgs e )
        {
            if ( saveFileDlgState.ShowDialog() == DialogResult.OK )
            {
                try
                {
                    string fname = saveFileDlgState.FileName;
                    XmlSerializer ser = new XmlSerializer( typeof( SaveState ) );

                    SaveState save = new SaveState
                    {
                        Regex = txtBoxRegExp.Text ,
                        TextSource = txtBoxSrc.Text ,
                        EncodingIndex = comboBoxEncoding.SelectedIndex ,
                        Text = txtBoxText.Text
                    };

                    List<int> opts = new List<int>();
                    for ( int i = 0 ; i < chkListBoxREOpt.CheckedIndices.Count ; i++ )
                        opts.Add( chkListBoxREOpt.CheckedIndices[ i ] );
                    save.RegexOptions = opts.ToArray();
                    if ( radioBtnURL.Checked )
                        save.SourceType = TextSourceType.Url;
                    else
                        if ( radioBtnFile.Checked )
                            save.SourceType = TextSourceType.File;
                        else
                            if ( radioBtnClipboard.Checked )
                                save.SourceType = TextSourceType.Clipboard;
                            else
                                throw new Exception( "So What???" );

                    using ( FileStream fs = File.OpenWrite( fname ) )
                    {
                        ser.Serialize( fs , save );
                    }
                }
                catch ( Exception exc )
                {
                    ShowException( exc );
                }
            }
        }

        private void btnLoadState_Click( object sender , EventArgs e )
        {
            if ( openFileDlgState.ShowDialog() == DialogResult.OK )
            {
                try
                {
                    SaveState save = null;
                    using ( FileStream fs = File.OpenRead( openFileDlgState.FileName ) )
                    {
                        XmlSerializer ser = new XmlSerializer( typeof( SaveState ) );
                        save = (SaveState) ser.Deserialize( fs );
                    }

                    txtBoxRegExp.Text = save.Regex;
                    for ( int i = 0 ; i < chkListBoxREOpt.Items.Count ; i++ )
                    {
                        bool found = false;
                        foreach ( int ii in save.RegexOptions )
                            if ( found = ( ii == i ) )
                                break;
                        chkListBoxREOpt.SetItemChecked( i , found );
                    }
                    switch ( save.SourceType )
                    {
                        case TextSourceType.Url:
                            radioBtnURL.Checked = true;
                            radioBtnURL_Click( this , EventArgs.Empty );
                            break;
                        case TextSourceType.File:
                            radioBtnFile.Checked = true;
                            radioBtnFile_Click( this , EventArgs.Empty );
                            break;
                        case TextSourceType.Clipboard:
                            radioBtnClipboard.Checked = true;
                            radioBtnClipboard_Click( this , EventArgs.Empty );
                            break;
                        default:
                            throw new Exception( "So what???" );
                        //break;
                    }
                    txtBoxSrc.Text = save.TextSource;
                    comboBoxEncoding.SelectedIndex = save.EncodingIndex;
                    txtBoxText.Text = save.Text;
                }
                catch ( Exception exc )
                {
                    ShowException( exc );
                }
            }
        }

        #endregion

        private void treeViewMatches_AfterSelect( object sender , TreeViewEventArgs e )
        {
            object tag = e.Node.Tag;
            if ( tag == null )
                return;

            if ( tag is MatchItem )
            {
                MatchItem mi = tag as MatchItem;

                txtBoxMatchText.Text = mi.Text;
                txtBoxMatchStart.Text = mi.StartIndex.ToString();
                txtBoxMatchLength.Text = mi.TextLength.ToString();

                txtBoxText.Select( mi.StartIndex , mi.TextLength );
                txtBoxText.ScrollToCaret();
                return;
            }

            if ( tag is GroupItem )
            {
                GroupItem gi = tag as GroupItem;

                txtBoxMatchText.Text = gi.Text;
                txtBoxMatchStart.Text = gi.StartIndex.ToString();
                txtBoxMatchLength.Text = gi.TextLength.ToString();

                txtBoxText.Select( gi.StartIndex , gi.TextLength );
                txtBoxText.ScrollToCaret();
                return;
            }
        }
    }
}
