﻿namespace RegExTester
{
    partial class FREMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.GroupBox grpBoxRegExp;
            System.Windows.Forms.GroupBox grpBoxText;
            System.Windows.Forms.Label lblText;
            System.Windows.Forms.Label lblTextLength;
            System.Windows.Forms.Label lblTextStart;
            System.Windows.Forms.GroupBox grpBoxMatches;
            System.Windows.Forms.GroupBox grpBoxState;
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Node1");
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Node2");
            System.Windows.Forms.TreeNode treeNode11 = new System.Windows.Forms.TreeNode("Node3");
            System.Windows.Forms.TreeNode treeNode12 = new System.Windows.Forms.TreeNode("Node0", new System.Windows.Forms.TreeNode[] {
            treeNode9,
            treeNode10,
            treeNode11});
            System.Windows.Forms.TreeNode treeNode13 = new System.Windows.Forms.TreeNode("Node9");
            System.Windows.Forms.TreeNode treeNode14 = new System.Windows.Forms.TreeNode("Node10");
            System.Windows.Forms.TreeNode treeNode15 = new System.Windows.Forms.TreeNode("Node11");
            System.Windows.Forms.TreeNode treeNode16 = new System.Windows.Forms.TreeNode("Node6", new System.Windows.Forms.TreeNode[] {
            treeNode13,
            treeNode14,
            treeNode15});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FREMain));
            this.btnExit = new System.Windows.Forms.Button();
            this.chkListBoxREOpt = new System.Windows.Forms.CheckedListBox();
            this.btnREMatch = new System.Windows.Forms.Button();
            this.txtBoxRegExp = new System.Windows.Forms.TextBox();
            this.comboBoxEncoding = new System.Windows.Forms.ComboBox();
            this.lblEncoding = new System.Windows.Forms.Label();
            this.txtBoxText = new System.Windows.Forms.TextBox();
            this.btnLoad = new System.Windows.Forms.Button();
            this.radioBtnClipboard = new System.Windows.Forms.RadioButton();
            this.radioBtnFile = new System.Windows.Forms.RadioButton();
            this.txtBoxSrc = new System.Windows.Forms.TextBox();
            this.radioBtnURL = new System.Windows.Forms.RadioButton();
            this.btnLoadState = new System.Windows.Forms.Button();
            this.btnSaveState = new System.Windows.Forms.Button();
            this.txtBoxMatchStart = new System.Windows.Forms.TextBox();
            this.txtBoxMatchLength = new System.Windows.Forms.TextBox();
            this.txtBoxMatchText = new System.Windows.Forms.TextBox();
            this.treeViewMatches = new System.Windows.Forms.TreeView();
            this.imgLstTree = new System.Windows.Forms.ImageList(this.components);
            this.openFileDlg = new System.Windows.Forms.OpenFileDialog();
            this.openFileDlgState = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDlgState = new System.Windows.Forms.SaveFileDialog();
            this.btnOptHelp = new System.Windows.Forms.Button();
            grpBoxRegExp = new System.Windows.Forms.GroupBox();
            grpBoxText = new System.Windows.Forms.GroupBox();
            lblText = new System.Windows.Forms.Label();
            lblTextLength = new System.Windows.Forms.Label();
            lblTextStart = new System.Windows.Forms.Label();
            grpBoxMatches = new System.Windows.Forms.GroupBox();
            grpBoxState = new System.Windows.Forms.GroupBox();
            grpBoxRegExp.SuspendLayout();
            grpBoxText.SuspendLayout();
            grpBoxMatches.SuspendLayout();
            grpBoxState.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpBoxRegExp
            // 
            grpBoxRegExp.Controls.Add(this.btnOptHelp);
            grpBoxRegExp.Controls.Add(this.btnExit);
            grpBoxRegExp.Controls.Add(this.chkListBoxREOpt);
            grpBoxRegExp.Controls.Add(this.btnREMatch);
            grpBoxRegExp.Controls.Add(this.txtBoxRegExp);
            grpBoxRegExp.Location = new System.Drawing.Point(5, 3);
            grpBoxRegExp.Name = "grpBoxRegExp";
            grpBoxRegExp.Size = new System.Drawing.Size(533, 86);
            grpBoxRegExp.TabIndex = 3;
            grpBoxRegExp.TabStop = false;
            grpBoxRegExp.Text = "Regular Expression";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(469, 45);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(56, 34);
            this.btnExit.TabIndex = 7;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // chkListBoxREOpt
            // 
            this.chkListBoxREOpt.BackColor = System.Drawing.SystemColors.Control;
            this.chkListBoxREOpt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.chkListBoxREOpt.CheckOnClick = true;
            this.chkListBoxREOpt.FormattingEnabled = true;
            this.chkListBoxREOpt.Items.AddRange(new object[] {
            "Ignore case",
            "Multiline",
            "Explicit capture",
            "Singleline",
            "Ignore whitespaces",
            "Right to left"});
            this.chkListBoxREOpt.Location = new System.Drawing.Point(7, 45);
            this.chkListBoxREOpt.MultiColumn = true;
            this.chkListBoxREOpt.Name = "chkListBoxREOpt";
            this.chkListBoxREOpt.Size = new System.Drawing.Size(361, 30);
            this.chkListBoxREOpt.TabIndex = 6;
            // 
            // btnREMatch
            // 
            this.btnREMatch.Location = new System.Drawing.Point(408, 45);
            this.btnREMatch.Name = "btnREMatch";
            this.btnREMatch.Size = new System.Drawing.Size(57, 34);
            this.btnREMatch.TabIndex = 4;
            this.btnREMatch.Text = "Match";
            this.btnREMatch.UseVisualStyleBackColor = true;
            this.btnREMatch.Click += new System.EventHandler(this.btnREMatch_Click);
            // 
            // txtBoxRegExp
            // 
            this.txtBoxRegExp.Location = new System.Drawing.Point(6, 19);
            this.txtBoxRegExp.Name = "txtBoxRegExp";
            this.txtBoxRegExp.Size = new System.Drawing.Size(519, 20);
            this.txtBoxRegExp.TabIndex = 3;
            // 
            // grpBoxText
            // 
            grpBoxText.Controls.Add(this.comboBoxEncoding);
            grpBoxText.Controls.Add(this.lblEncoding);
            grpBoxText.Controls.Add(this.txtBoxText);
            grpBoxText.Controls.Add(this.btnLoad);
            grpBoxText.Controls.Add(this.radioBtnClipboard);
            grpBoxText.Controls.Add(this.radioBtnFile);
            grpBoxText.Controls.Add(this.txtBoxSrc);
            grpBoxText.Controls.Add(this.radioBtnURL);
            grpBoxText.Location = new System.Drawing.Point(5, 95);
            grpBoxText.Name = "grpBoxText";
            grpBoxText.Size = new System.Drawing.Size(532, 191);
            grpBoxText.TabIndex = 4;
            grpBoxText.TabStop = false;
            grpBoxText.Text = "Text";
            // 
            // comboBoxEncoding
            // 
            this.comboBoxEncoding.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxEncoding.Enabled = false;
            this.comboBoxEncoding.FormattingEnabled = true;
            this.comboBoxEncoding.Location = new System.Drawing.Point(300, 44);
            this.comboBoxEncoding.Name = "comboBoxEncoding";
            this.comboBoxEncoding.Size = new System.Drawing.Size(154, 21);
            this.comboBoxEncoding.TabIndex = 7;
            // 
            // lblEncoding
            // 
            this.lblEncoding.AutoSize = true;
            this.lblEncoding.Location = new System.Drawing.Point(239, 47);
            this.lblEncoding.Name = "lblEncoding";
            this.lblEncoding.Size = new System.Drawing.Size(55, 13);
            this.lblEncoding.TabIndex = 6;
            this.lblEncoding.Text = "&Encoding:";
            // 
            // txtBoxText
            // 
            this.txtBoxText.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtBoxText.Font = new System.Drawing.Font("Arial Unicode MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtBoxText.HideSelection = false;
            this.txtBoxText.Location = new System.Drawing.Point(3, 71);
            this.txtBoxText.Multiline = true;
            this.txtBoxText.Name = "txtBoxText";
            this.txtBoxText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtBoxText.Size = new System.Drawing.Size(526, 117);
            this.txtBoxText.TabIndex = 5;
            this.txtBoxText.WordWrap = false;
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(460, 17);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(65, 23);
            this.btnLoad.TabIndex = 4;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // radioBtnClipboard
            // 
            this.radioBtnClipboard.AutoSize = true;
            this.radioBtnClipboard.Checked = true;
            this.radioBtnClipboard.Location = new System.Drawing.Point(113, 45);
            this.radioBtnClipboard.Name = "radioBtnClipboard";
            this.radioBtnClipboard.Size = new System.Drawing.Size(69, 17);
            this.radioBtnClipboard.TabIndex = 3;
            this.radioBtnClipboard.TabStop = true;
            this.radioBtnClipboard.Text = "Clipboard";
            this.radioBtnClipboard.UseVisualStyleBackColor = true;
            this.radioBtnClipboard.Click += new System.EventHandler(this.radioBtnClipboard_Click);
            // 
            // radioBtnFile
            // 
            this.radioBtnFile.AutoSize = true;
            this.radioBtnFile.Location = new System.Drawing.Point(60, 45);
            this.radioBtnFile.Name = "radioBtnFile";
            this.radioBtnFile.Size = new System.Drawing.Size(47, 17);
            this.radioBtnFile.TabIndex = 2;
            this.radioBtnFile.Text = "File…";
            this.radioBtnFile.UseVisualStyleBackColor = true;
            this.radioBtnFile.Click += new System.EventHandler(this.radioBtnFile_Click);
            // 
            // txtBoxSrc
            // 
            this.txtBoxSrc.Enabled = false;
            this.txtBoxSrc.Location = new System.Drawing.Point(6, 19);
            this.txtBoxSrc.Name = "txtBoxSrc";
            this.txtBoxSrc.Size = new System.Drawing.Size(448, 20);
            this.txtBoxSrc.TabIndex = 1;
            // 
            // radioBtnURL
            // 
            this.radioBtnURL.AutoSize = true;
            this.radioBtnURL.Location = new System.Drawing.Point(7, 45);
            this.radioBtnURL.Name = "radioBtnURL";
            this.radioBtnURL.Size = new System.Drawing.Size(47, 17);
            this.radioBtnURL.TabIndex = 0;
            this.radioBtnURL.Text = "URL";
            this.radioBtnURL.UseVisualStyleBackColor = true;
            this.radioBtnURL.Click += new System.EventHandler(this.radioBtnURL_Click);
            // 
            // lblText
            // 
            lblText.AutoSize = true;
            lblText.Location = new System.Drawing.Point(360, 17);
            lblText.Name = "lblText";
            lblText.Size = new System.Drawing.Size(31, 13);
            lblText.TabIndex = 4;
            lblText.Text = "Text:";
            // 
            // lblTextLength
            // 
            lblTextLength.AutoSize = true;
            lblTextLength.Location = new System.Drawing.Point(453, 61);
            lblTextLength.Name = "lblTextLength";
            lblTextLength.Size = new System.Drawing.Size(43, 13);
            lblTextLength.TabIndex = 5;
            lblTextLength.Text = "Length:";
            // 
            // lblTextStart
            // 
            lblTextStart.AutoSize = true;
            lblTextStart.Location = new System.Drawing.Point(360, 61);
            lblTextStart.Name = "lblTextStart";
            lblTextStart.Size = new System.Drawing.Size(72, 13);
            lblTextStart.TabIndex = 6;
            lblTextStart.Text = "Start Position:";
            // 
            // grpBoxMatches
            // 
            grpBoxMatches.Controls.Add(grpBoxState);
            grpBoxMatches.Controls.Add(lblTextStart);
            grpBoxMatches.Controls.Add(lblTextLength);
            grpBoxMatches.Controls.Add(lblText);
            grpBoxMatches.Controls.Add(this.txtBoxMatchStart);
            grpBoxMatches.Controls.Add(this.txtBoxMatchLength);
            grpBoxMatches.Controls.Add(this.txtBoxMatchText);
            grpBoxMatches.Controls.Add(this.treeViewMatches);
            grpBoxMatches.Location = new System.Drawing.Point(5, 292);
            grpBoxMatches.Name = "grpBoxMatches";
            grpBoxMatches.Size = new System.Drawing.Size(532, 176);
            grpBoxMatches.TabIndex = 5;
            grpBoxMatches.TabStop = false;
            grpBoxMatches.Text = "Matches";
            // 
            // grpBoxState
            // 
            grpBoxState.Controls.Add(this.btnLoadState);
            grpBoxState.Controls.Add(this.btnSaveState);
            grpBoxState.Location = new System.Drawing.Point(361, 120);
            grpBoxState.Name = "grpBoxState";
            grpBoxState.Size = new System.Drawing.Size(163, 50);
            grpBoxState.TabIndex = 7;
            grpBoxState.TabStop = false;
            grpBoxState.Text = "Save/Load State";
            // 
            // btnLoadState
            // 
            this.btnLoadState.Location = new System.Drawing.Point(82, 19);
            this.btnLoadState.Name = "btnLoadState";
            this.btnLoadState.Size = new System.Drawing.Size(75, 23);
            this.btnLoadState.TabIndex = 1;
            this.btnLoadState.Text = "Load…";
            this.btnLoadState.UseVisualStyleBackColor = true;
            this.btnLoadState.Click += new System.EventHandler(this.btnLoadState_Click);
            // 
            // btnSaveState
            // 
            this.btnSaveState.Location = new System.Drawing.Point(6, 19);
            this.btnSaveState.Name = "btnSaveState";
            this.btnSaveState.Size = new System.Drawing.Size(75, 23);
            this.btnSaveState.TabIndex = 0;
            this.btnSaveState.Text = "Save…";
            this.btnSaveState.UseVisualStyleBackColor = true;
            this.btnSaveState.Click += new System.EventHandler(this.btnSaveState_Click);
            // 
            // txtBoxMatchStart
            // 
            this.txtBoxMatchStart.Location = new System.Drawing.Point(361, 77);
            this.txtBoxMatchStart.Name = "txtBoxMatchStart";
            this.txtBoxMatchStart.ReadOnly = true;
            this.txtBoxMatchStart.Size = new System.Drawing.Size(70, 20);
            this.txtBoxMatchStart.TabIndex = 3;
            // 
            // txtBoxMatchLength
            // 
            this.txtBoxMatchLength.Location = new System.Drawing.Point(453, 77);
            this.txtBoxMatchLength.Name = "txtBoxMatchLength";
            this.txtBoxMatchLength.ReadOnly = true;
            this.txtBoxMatchLength.Size = new System.Drawing.Size(71, 20);
            this.txtBoxMatchLength.TabIndex = 2;
            // 
            // txtBoxMatchText
            // 
            this.txtBoxMatchText.Location = new System.Drawing.Point(361, 33);
            this.txtBoxMatchText.Name = "txtBoxMatchText";
            this.txtBoxMatchText.ReadOnly = true;
            this.txtBoxMatchText.Size = new System.Drawing.Size(163, 20);
            this.txtBoxMatchText.TabIndex = 1;
            // 
            // treeViewMatches
            // 
            this.treeViewMatches.Dock = System.Windows.Forms.DockStyle.Left;
            this.treeViewMatches.ImageIndex = 0;
            this.treeViewMatches.ImageList = this.imgLstTree;
            this.treeViewMatches.Location = new System.Drawing.Point(3, 16);
            this.treeViewMatches.Name = "treeViewMatches";
            treeNode9.ImageIndex = 1;
            treeNode9.Name = "Node1";
            treeNode9.Text = "Node1";
            treeNode10.ImageIndex = 1;
            treeNode10.Name = "Node2";
            treeNode10.Text = "Node2";
            treeNode11.ImageIndex = 1;
            treeNode11.Name = "Node3";
            treeNode11.Text = "Node3";
            treeNode12.Name = "Node0";
            treeNode12.Text = "Node0";
            treeNode13.ImageIndex = 1;
            treeNode13.Name = "Node9";
            treeNode13.Text = "Node9";
            treeNode14.ImageIndex = 1;
            treeNode14.Name = "Node10";
            treeNode14.Text = "Node10";
            treeNode15.ImageIndex = 1;
            treeNode15.Name = "Node11";
            treeNode15.Text = "Node11";
            treeNode16.Name = "Node6";
            treeNode16.Text = "Node6";
            this.treeViewMatches.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode12,
            treeNode16});
            this.treeViewMatches.SelectedImageIndex = 2;
            this.treeViewMatches.Size = new System.Drawing.Size(352, 157);
            this.treeViewMatches.TabIndex = 0;
            this.treeViewMatches.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeViewMatches_AfterSelect);
            // 
            // imgLstTree
            // 
            this.imgLstTree.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgLstTree.ImageStream")));
            this.imgLstTree.TransparentColor = System.Drawing.Color.Transparent;
            this.imgLstTree.Images.SetKeyName(0, "match.png");
            this.imgLstTree.Images.SetKeyName(1, "group.png");
            this.imgLstTree.Images.SetKeyName(2, "selected.png");
            // 
            // openFileDlg
            // 
            this.openFileDlg.DefaultExt = "txt";
            this.openFileDlg.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            // 
            // openFileDlgState
            // 
            this.openFileDlgState.DefaultExt = "ret";
            this.openFileDlgState.Filter = "RETester savestate files (*.ret; *.xml)|*.ret; *.xml |All files (*.*)|*.*";
            // 
            // saveFileDlgState
            // 
            this.saveFileDlgState.DefaultExt = "ret";
            this.saveFileDlgState.Filter = "RETester savestate files (*.ret; *.xml)|*.ret; *.xml |All files (*.*)|*.*";
            // 
            // btnOptHelp
            // 
            this.btnOptHelp.Location = new System.Drawing.Point(374, 45);
            this.btnOptHelp.Name = "btnOptHelp";
            this.btnOptHelp.Size = new System.Drawing.Size(28, 34);
            this.btnOptHelp.TabIndex = 8;
            this.btnOptHelp.Text = "?";
            this.btnOptHelp.UseVisualStyleBackColor = true;
            this.btnOptHelp.Click += new System.EventHandler(this.btnOptHelp_Click);
            // 
            // FREMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(544, 475);
            this.Controls.Add(grpBoxMatches);
            this.Controls.Add(grpBoxText);
            this.Controls.Add(grpBoxRegExp);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FREMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Regular Expressions Tester";
            grpBoxRegExp.ResumeLayout(false);
            grpBoxRegExp.PerformLayout();
            grpBoxText.ResumeLayout(false);
            grpBoxText.PerformLayout();
            grpBoxMatches.ResumeLayout(false);
            grpBoxMatches.PerformLayout();
            grpBoxState.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckedListBox chkListBoxREOpt;
        private System.Windows.Forms.Button btnREMatch;
        private System.Windows.Forms.TextBox txtBoxRegExp;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.RadioButton radioBtnClipboard;
        private System.Windows.Forms.RadioButton radioBtnFile;
        private System.Windows.Forms.TextBox txtBoxSrc;
        private System.Windows.Forms.RadioButton radioBtnURL;
        private System.Windows.Forms.TextBox txtBoxText;
        private System.Windows.Forms.ComboBox comboBoxEncoding;
        private System.Windows.Forms.Label lblEncoding;
        private System.Windows.Forms.OpenFileDialog openFileDlg;
        private System.Windows.Forms.TreeView treeViewMatches;
        private System.Windows.Forms.ImageList imgLstTree;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtBoxMatchStart;
        private System.Windows.Forms.TextBox txtBoxMatchLength;
        private System.Windows.Forms.TextBox txtBoxMatchText;
        private System.Windows.Forms.Button btnLoadState;
        private System.Windows.Forms.Button btnSaveState;
        private System.Windows.Forms.OpenFileDialog openFileDlgState;
        private System.Windows.Forms.SaveFileDialog saveFileDlgState;
        private System.Windows.Forms.Button btnOptHelp;

    }
}

