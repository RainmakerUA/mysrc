﻿using System;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;

namespace RM.AsmCrypter
{
	internal static class AsmCrypto
	{
		private static readonly RijndaelManaged _rinjdael;

		static AsmCrypto()
		{
			_rinjdael = new RijndaelManaged
			{
				Mode = CipherMode.ECB ,
				Padding = PaddingMode.PKCS7
			};
		}

		private static byte[] GetBytes( string password )
		{
			return Encoding.ASCII.GetBytes( password );
		}

		private static ICryptoTransform CreateCrypto( bool decrypt , byte[] key )
		{
			_rinjdael.Key = key;
			return decrypt ? _rinjdael.CreateDecryptor() : _rinjdael.CreateEncryptor();
		}

		public static string EncryptName( string name )
		{
			MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
			byte[] hash = md5.ComputeHash( Encoding.UTF8.GetBytes( name ) );
			return String.Join( String.Empty , Array.ConvertAll( hash , b => String.Format( "{0:x2}" , b ) ) );
		}

		public static byte[] Encrypt( byte[] asmData , string encName )
		{
			ICryptoTransform crypt = CreateCrypto( false , GetBytes( encName ) );
			return crypt.TransformFinalBlock( asmData , 0 , asmData.Length );
		}

		public static byte[] Decrypt( byte[] encData , string encName )
		{
			ICryptoTransform crypt = CreateCrypto( true , GetBytes( encName ) );
			return crypt.TransformFinalBlock( encData , 0 , encData.Length );
		}

		public static void EncryptFile( string inFile , string outDir )
		{
			string asmName = Path.GetFileNameWithoutExtension( inFile );
			string asmNameSecret = EncryptName( asmName );

			byte[] inData = File.ReadAllBytes( inFile );
			byte[] outData = Encrypt( inData , asmNameSecret );
#if DEBUG
			Console.WriteLine( "{0} $=> {1}" , Path.GetFullPath( inFile ) , Path.GetFullPath( outDir ) );
#endif
			File.WriteAllBytes( Path.Combine( outDir , asmNameSecret ) , outData );
		}
	}
}
