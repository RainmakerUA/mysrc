﻿using System;

namespace RM.AsmCrypter
{
	class Program
	{
		static void Main( string[] args )
		{
			switch ( args.Length )
			{
				case 0:
					Console.WriteLine( "Usage:\n{0} <asm_in_file> <asm_out_dir>" , Environment.GetCommandLineArgs()[ 0 ] );
					break;

				case 1:
					AsmCrypto.EncryptFile( args[ 0 ] , "." );
					break;

				default:
					AsmCrypto.EncryptFile( args[ 0 ] , args[ 1 ] );
					break;
			}
		}
	}
}
