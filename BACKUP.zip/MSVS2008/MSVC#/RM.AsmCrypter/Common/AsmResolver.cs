﻿using System;
using System.IO;
using System.Reflection;
using RM.AsmCrypter;

namespace Testing.Common
{
	public static class AsmResolver
	{
		public static void ResolveEncryptedResource()
		{
			AppDomain.CurrentDomain.AssemblyResolve += OnCryptoResolve;
		}

		internal static Assembly OnCryptoResolve( object sender , ResolveEventArgs e )
		{
			string asmName = e.Name;
			Assembly currentAsm = Assembly.GetExecutingAssembly();
			string encName = AsmCrypto.EncryptName( asmName.Substring( 0 , asmName.IndexOf( ',' ) ) );
			Stream resStream = currentAsm.GetManifestResourceStream(
					String.Format( "{0}.Resources.{1}" , currentAsm.GetName().Name , encName )
				);

			if ( resStream == null )
			{
				return null;
			}

			long len = resStream.Length;
			byte[] encData = new byte[ len ];
			resStream.Read( encData , 0 , (int) len );
			byte[] asm = AsmCrypto.Decrypt( encData , encName );
			return Assembly.Load( asm );
		}
	}
}


