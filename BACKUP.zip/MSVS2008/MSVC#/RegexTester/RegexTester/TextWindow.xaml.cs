﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RegexTester
{
    /// <summary>
    /// Interaction logic for TextWindow.xaml
    /// </summary>
    public partial class TextWindow : Window
    {
        public TextWindow()
        {
            InitializeComponent();
        }

        private void buttonClose_Click( object sender , RoutedEventArgs e )
        {
            Close();
        }

        public static void Show( Window owner , string windowTitle , string caption , string description , ImageSource image , string closeButtonText )
        {
            var window = new TextWindow
            {
                Title = windowTitle ?? caption ,
                Owner = owner ?? Application.Current.MainWindow
            };

            window.textBlockCaption.Text = caption;
            window.textBoxDescription.Text = description;
            window.image.Source = image;

            if ( !String.IsNullOrEmpty( closeButtonText ) )
            {
                window.buttonClose.Content = closeButtonText;
            }
            window.WindowStartupLocation = window.Owner == null ? WindowStartupLocation.CenterScreen : WindowStartupLocation.CenterOwner;

            window.ShowDialog();
        }

        public static void Show( string caption , string description , ImageSource image )
        {
            Show( null , null , caption , description , image , null );
        }
    }
}
