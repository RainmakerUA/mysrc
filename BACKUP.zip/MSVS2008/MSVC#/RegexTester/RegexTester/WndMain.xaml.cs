﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Data;
using System.Globalization;
using System.Text;
using Microsoft.Win32;
using System.Net;
using System.IO;
using System.Windows.Media;

namespace RegexTester
{
    /// <summary>
    /// Interaction logic for WndMain.xaml
    /// </summary>
    public partial class WndMain : Window
    {
        private const string REOPTIONSHELP = "RegEx Options help:\n\n"
                + "• Ignore Case - Case-insensitive matching ([A-Z] matches a-z too)\n\n"
                + "• Multiline - Changes the meaning of \"^\" and \"$\" so they match at the beginning and end of any line,\n"
                + "   and not just the beginning and end of the entire text\n\n"
                + "• Explicit Capture - The only valid captures are explicitly named or numbered groups of the form (?<name>…)\n"
                + "   This allows unnamed parentheses to act as noncapturing groups\n\n"
                + "• Singleline - Dot \".\" matches newline \"\\n\" as well\n\n"
                + "• Ignore Pattern Whitespace = IgnorePatternWhitespace - Unescaped white space in the pattern is ignored (except for character classes)\n\n"
                + "• Right To Left - Search will be from right to left";

        private static readonly Encoding[] ENCODINGS = {
                                                            Encoding.Unicode ,
                                                            Encoding.BigEndianUnicode ,
                                                            Encoding.UTF8 ,
                                                            Encoding.GetEncoding( 1251 ) ,
                                                            Encoding.GetEncoding( "ISO-8859-1" ) ,
                                                            Encoding.GetEncoding( "ISO-8859-5" )
                                                       };

        private OpenFileDialog openDialog;

        public WndMain()
        {
            InitializeComponent();
            SetCheckBoxTexts();

            comboBoxEncoding.Items.Clear();
            foreach ( var enc in ENCODINGS )
            {
                comboBoxEncoding.Items.Add( new EncodingWrapper( enc ) );
            }
            comboBoxEncoding.SelectedIndex = 0;
            treeViewMatches.Items.Clear();

            radioButtonClipboard.IsChecked = true;
        }

        private void SetCheckBoxTexts()
        {
            CheckBox chkBox;
            foreach ( var c in ( groupBoxRegex.Content as Grid ).Children )
            {
                if ( c is CheckBox )
                {
                    chkBox = c as CheckBox;
                    chkBox.Content = Utility.CamelCaseToMultiWord( chkBox.Name.Substring( "checkBox".Length ) );
                }
            }
        }

        private RegexOptions GetRegexOptions()
        {
            CheckBox chkBox;
            RegexOptions result = RegexOptions.None;

            foreach ( var c in ( groupBoxRegex.Content as Grid ).Children )
            {
                if ( c is CheckBox )
                {
                    chkBox = c as CheckBox;
                    if ( chkBox.IsChecked.HasValue && chkBox.IsChecked.Value )
                    {
                        result |= (RegexOptions) Enum.Parse( typeof( RegexOptions ) , chkBox.Name.Substring( "checkBox".Length ) , true );
                    }
                }
            }

            return result;
        }

        private void UpdateTreeView( List<MatchItem> matches )
        {
            treeViewMatches.Items.Clear();

            foreach ( var match in matches )
            {
                TreeViewItem item = new TreeViewItem
                {
                    Header = match.ToString() ,
                    Tag = match
                };

                treeViewMatches.Items.Add( item );

                for ( int i = 1 ; i < match.Groups.Count ; i++ )
                {
                    GroupItem gi = match.Groups[ i ];
                    TreeViewItem groupItem = new TreeViewItem
                            {
                                Header = gi.ToString() ,
                                Tag = gi
                            };
                    TreeViewItemProps.SetIsGroupNode( groupItem , true );
                    item.Items.Add( groupItem );
                }
            }
        }

        private void buttonHelp_Click( object sender , RoutedEventArgs e )
        {
            TextWindow.Show( "Regex options help" , REOPTIONSHELP , Utility.GetResourceImageSource( "Resources/MainIcon.ico" ) );
            //MessageBox.Show( REOPTIONSHELP , Title , MessageBoxButton.OK , MessageBoxImage.Information );
        }

        private void buttonMatch_Click( object sender , RoutedEventArgs e )
        {
            Regex re = new Regex( textBoxRegex.Text , GetRegexOptions() );
            MatchCollection mc = re.Matches( textBoxText.Text );
            UpdateTreeView( MatchItem.MatchCollectionToItemList( re , mc ) );
        }

        private void radioButtonUrl_Checked( object sender , RoutedEventArgs e )
        {
            textBoxSource.IsReadOnly = false;
            textBoxSource.Text = String.Empty;
            textBoxSource.IsEnabled = comboBoxEncoding.IsEnabled = true;
            comboBoxEncoding.SelectedIndex = 2;
        }

        private void radioButtonFile_Checked( object sender , RoutedEventArgs e )
        {
            bool? dlgResult;
            textBoxSource.IsReadOnly = textBoxSource.IsEnabled = comboBoxEncoding.IsEnabled = true;
            if ( openDialog == null )
            {
                openDialog = new OpenFileDialog
                {
                    DefaultExt = "txt" ,
                    Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*"
                };
            }

            dlgResult = openDialog.ShowDialog();

            if ( dlgResult.HasValue && dlgResult.Value )
            {
                textBoxSource.Text = openDialog.FileName;
            }
            else
            {
                textBoxSource.Text = "(no file selected)";
            }

            comboBoxEncoding.SelectedIndex = 3;
        }

        private void radioButtonClipboard_Checked( object sender , RoutedEventArgs e )
        {
            textBoxSource.Text = String.Empty;
            comboBoxEncoding.SelectedIndex = 0;
            textBoxSource.IsEnabled = comboBoxEncoding.IsEnabled = false;
        }

        private void buttonLoad_Click( object sender , RoutedEventArgs e )
        {
            if ( radioButtonUrl.IsChecked.IsTrue() )
            {
                WebClient wc = new WebClient();
                byte[] data = wc.DownloadData( textBoxSource.Text );
                textBoxText.Clear();
                textBoxText.Text = ( comboBoxEncoding.SelectedItem as EncodingWrapper ).Value.GetString( data );
                return;
            }
            else if ( radioButtonFile.IsChecked.IsTrue() )
            {
                textBoxText.Text = File.ReadAllText( textBoxSource.Text , ( comboBoxEncoding.SelectedItem as EncodingWrapper ).Value );
                return;
            }
            else if ( radioButtonClipboard.IsChecked.IsTrue() )
            {
                textBoxText.Clear();
                textBoxText.Paste();
                return;
            }
        }

        private void treeViewMatches_SelectedItemChanged( object sender , RoutedPropertyChangedEventArgs<object> e )
        {
            object tag;
            ITextBlock block;

            if ( e.NewValue is TreeViewItem )
            {
                tag = ( e.NewValue as TreeViewItem ).Tag;
                if ( tag is ITextBlock )
                {
                    block = tag as ITextBlock;
                    textBoxMatchText.Text = block.Text;
                    textBoxStartPos.Text = block.StartIndex.ToString();
                    textBoxLength.Text = block.TextLength.ToString();

                    //textBoxText.Focus();
                    //textBoxText.Select( block.StartIndex , block.TextLength );
                    textBoxText.Highlight( block.StartIndex , block.TextLength );
                    //textBoxText.ScrollToCaret();
                    return;
                }
            }
        }

        private void button1_Click( object sender , RoutedEventArgs e )
        {
            ( new TextWindow() ).ShowDialog();
        }
    }

    public static class TreeViewItemProps
    {
        public static bool GetIsGroupNode( DependencyObject obj )
        {
            return (bool) obj.GetValue( IsGroupNodeProperty );
        }

        public static void SetIsGroupNode( DependencyObject obj , bool value )
        {
            obj.SetValue( IsGroupNodeProperty , value );
        }

        public static readonly DependencyProperty IsGroupNodeProperty =
            DependencyProperty.RegisterAttached(
                "IsGroupNode" ,
                typeof( bool ) ,
                typeof( TreeViewItemProps ) ,
                new UIPropertyMetadata( false )
            );
    }
}
