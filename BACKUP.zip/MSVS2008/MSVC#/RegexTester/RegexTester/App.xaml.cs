﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace RegexTester
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private static void ShowException( Exception exc )
        {
            MessageBox.Show( exc.Message , exc.GetType().ToString() , MessageBoxButton.OK , MessageBoxImage.Error );
        }

        private void OnDispatcherUnhandledException( object sender , System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e )
        {
            ShowException( e.Exception );
            e.Handled = true;
        }
    }
}
