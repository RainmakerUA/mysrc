﻿using System;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using FrameworkElement = System.Windows.FrameworkElement;
using Rect = System.Windows.Rect;
using System.Windows.Documents;

namespace RegexTester
{
    internal static class Utility
    {
        private static readonly Regex UNCAMELRE = new Regex( "([a-z])([A-Z])" , RegexOptions.Compiled );

        private static readonly Action<FrameworkElement , object> AddLogicalChildMethod = CreateAddLogicalChildMethod();

        private static Action<FrameworkElement , object> CreateAddLogicalChildMethod()
        {
            ParameterExpression instance = Expression.Parameter( typeof( FrameworkElement ) , "element" );
            ParameterExpression parameter = Expression.Parameter( typeof( object ) , "child" );

            MethodInfo methodInfo = typeof( FrameworkElement ).GetMethod(
                "AddLogicalChild" , BindingFlags.NonPublic | BindingFlags.Instance );
            MethodCallExpression method = Expression.Call( instance , methodInfo , parameter );

            Expression<Action<FrameworkElement , object>> lambda =
                Expression.Lambda<Action<FrameworkElement , object>>( method , instance , parameter );

            return lambda.Compile();
        }

        internal static void AddLogicalChild( this FrameworkElement element , object child )
        {
            AddLogicalChildMethod( element , child );
        }

        public static string CamelCaseToMultiWord( string str )
        {
            return UNCAMELRE.Replace( str , "$1 $2" );
        }

        public static bool IsTrue( this bool? value )
        {
            return value.HasValue && value.Value;
        }

        public static BitmapImage GetResourceImageSource( string path )
        {
            return new BitmapImage( new Uri( "application:,,," + path , UriKind.Relative ) );
        }

        public static void Highlight( this TextBox textbox , int start , int length )
        {
            Rect r1 = textbox.GetRectFromCharacterIndex( start );
            Rect r2 = textbox.GetRectFromCharacterIndex( start + length , true );
            Rect r = new Rect( r1.Left , r1.Top , r2.Right - r1.Left , r2.Bottom - r1.Top );
            AdornerLayer al = AdornerLayer.GetAdornerLayer( textbox );
            Adorner[] ads = al.GetAdorners( textbox );
            if ( ads != null )
            {
                for ( int i = 0 ; i < ads.Length ; i++ )
                {
                    al.Remove( ads[ i ] );
                }
            }
            textbox.ScrollToVerticalOffset( r.Top );
            al.Add( new HighlightAdorner( textbox , r ) );
        }
    }
}
