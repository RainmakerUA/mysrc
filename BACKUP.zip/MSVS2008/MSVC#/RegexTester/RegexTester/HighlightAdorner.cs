﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Documents;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows;

namespace RegexTester
{
    public class HighlightAdorner : Adorner
    {
        Brush b;
        Pen p;

        public HighlightAdorner( UIElement parent , Rect bounds )
            : base( parent )
        {
            b = new SolidColorBrush( Colors.Yellow );
            b.Opacity = .7;
            p = new Pen( b , 1 );
            b.Freeze();
            p.Freeze();
            Bounds = bounds;
        }



        public Rect Bounds
        {
            get
            {
                return (Rect) GetValue( BoundsProperty );
            }
            set
            {
                SetValue( BoundsProperty , value );
            }
        }
        public static readonly DependencyProperty BoundsProperty =
            DependencyProperty.Register( "Bounds" , typeof( Rect ) , typeof( HighlightAdorner ) , new UIPropertyMetadata( default( Rect ) ) );


        protected override void OnRender( DrawingContext drawingContext )
        {
            drawingContext.DrawRectangle( b , p , Bounds );
        }
    }
}
