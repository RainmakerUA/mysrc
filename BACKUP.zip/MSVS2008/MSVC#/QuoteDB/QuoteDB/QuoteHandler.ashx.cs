﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QuoteDB
{
    public class QuoteHandler : IHttpHandler
    {
        public void ProcessRequest( HttpContext context )
        {
            long id;
            string idStr;
            string quoteText;

            context.Response.ContentType = "text/html";
            

            idStr = context.Request.QueryString["id"];
            if ( !String.IsNullOrEmpty( idStr ) && Int64.TryParse( idStr, out id ) )
            {
                quoteText = ( from qt in ( new DataDataContext() ).Contents where qt.Id == id select qt.Text ).FirstOrDefault();
                if ( !String.IsNullOrEmpty( quoteText ) )
                {
                    
                    context.Response.Cache.SetExpires( DateTime.Now.AddDays( 10 ) );
                    context.Response.Cache.SetCacheability( HttpCacheability.Public );

                    context.Response.Write( quoteText );
                    context.Response.End();
                }
            }

            context.Response.Cache.SetCacheability( HttpCacheability.NoCache );
            context.Response.Write( "<strong>Invalid request or quote not found!</strong>" );
            context.Response.End();
        }

        public bool IsReusable
        {
            get
            {
                return true;
            }
        }
    }
}
