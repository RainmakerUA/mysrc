﻿using System;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;

namespace UniCode
{
    public partial class FMain : Form
    {
        public FMain()
        {
            InitializeComponent();
        }

        private string GetCharDescription(char Char)
        {
            string Description = null;
            int index = (int)Char;
            try
            {
                ResourceManager rm = new ResourceManager("UniCode.CharNames", Assembly.GetExecutingAssembly());
                Description = rm.GetString(index.ToString());
            }
            catch (Exception e)
            {
                MessageBox.Show(
                        String.Format("Исключение: {0}\nТекст: {1}", e.GetType().ToString(), e.Message),
                        "Исключение",
                        MessageBoxButtons.OK, MessageBoxIcon.Error
                        );
            }
            return Description ?? "No description found";
        }
        
        private void TxtBoxHex_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
                BtnShow_Click(TxtBoxHex, new EventArgs());
            if (e.KeyChar < '\x20' || (e.KeyChar >= '0' && e.KeyChar <= '9') || (e.KeyChar.ToString().ToUpper()[0] >= 'A' && e.KeyChar.ToString().ToUpper()[0] <= 'F'))
                return;
            else
                e.KeyChar = '\x00';
        }

        private void BtnShow_Click(object sender, EventArgs e)
        {
            if (TxtBoxHex.Text.Length == 0)
                return;
            char ch = (char) Convert.ToInt16(TxtBoxHex.Text, 16);
            LblCharShow.Text = ch.ToString();
            LblCharDesc.Text = GetCharDescription(ch);
        }

        private void ChkBoxAutoShow_CheckedChanged(object sender, EventArgs e)
        {
            BtnShow.Enabled = !ChkBoxAutoShow.Checked;
        }

        private void TxtBoxHex_TextChanged(object sender, EventArgs e)
        {
            if (ChkBoxAutoShow.Checked)
                BtnShow_Click(TxtBoxHex, new EventArgs());
        }
    }
}
