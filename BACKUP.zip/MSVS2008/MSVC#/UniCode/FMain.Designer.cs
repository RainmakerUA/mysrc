﻿namespace UniCode
{
    partial class FMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblHex = new System.Windows.Forms.Label();
            this.TxtBoxHex = new System.Windows.Forms.TextBox();
            this.ChkBoxAutoShow = new System.Windows.Forms.CheckBox();
            this.BtnShow = new System.Windows.Forms.Button();
            this.LblCharShow = new System.Windows.Forms.Label();
            this.LblShowChar = new System.Windows.Forms.Label();
            this.LblCharDesc = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LblHex
            // 
            this.LblHex.BackColor = System.Drawing.Color.Transparent;
            this.LblHex.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblHex.Font = new System.Drawing.Font("Sylfaen", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblHex.Location = new System.Drawing.Point(12, 12);
            this.LblHex.Name = "LblHex";
            this.LblHex.Size = new System.Drawing.Size(224, 20);
            this.LblHex.TabIndex = 1;
            this.LblHex.Text = "Код Unicode-символа в HEX (BE) -->";
            // 
            // TxtBoxHex
            // 
            this.TxtBoxHex.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TxtBoxHex.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TxtBoxHex.Location = new System.Drawing.Point(242, 12);
            this.TxtBoxHex.MaxLength = 4;
            this.TxtBoxHex.Name = "TxtBoxHex";
            this.TxtBoxHex.Size = new System.Drawing.Size(80, 21);
            this.TxtBoxHex.TabIndex = 2;
            this.TxtBoxHex.TextChanged += new System.EventHandler(this.TxtBoxHex_TextChanged);
            this.TxtBoxHex.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBoxHex_KeyPress);
            // 
            // ChkBoxAutoShow
            // 
            this.ChkBoxAutoShow.AutoSize = true;
            this.ChkBoxAutoShow.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ChkBoxAutoShow.Location = new System.Drawing.Point(223, 43);
            this.ChkBoxAutoShow.Name = "ChkBoxAutoShow";
            this.ChkBoxAutoShow.Size = new System.Drawing.Size(13, 12);
            this.ChkBoxAutoShow.TabIndex = 3;
            this.ChkBoxAutoShow.UseVisualStyleBackColor = true;
            this.ChkBoxAutoShow.CheckedChanged += new System.EventHandler(this.ChkBoxAutoShow_CheckedChanged);
            // 
            // BtnShow
            // 
            this.BtnShow.Font = new System.Drawing.Font("Sylfaen", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BtnShow.Location = new System.Drawing.Point(242, 38);
            this.BtnShow.Name = "BtnShow";
            this.BtnShow.Size = new System.Drawing.Size(80, 24);
            this.BtnShow.TabIndex = 4;
            this.BtnShow.Text = "Показать";
            this.BtnShow.UseVisualStyleBackColor = true;
            this.BtnShow.Click += new System.EventHandler(this.BtnShow_Click);
            // 
            // LblCharShow
            // 
            this.LblCharShow.BackColor = System.Drawing.Color.White;
            this.LblCharShow.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblCharShow.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LblCharShow.Font = new System.Drawing.Font("Sylfaen", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblCharShow.Location = new System.Drawing.Point(12, 38);
            this.LblCharShow.Name = "LblCharShow";
            this.LblCharShow.Size = new System.Drawing.Size(100, 75);
            this.LblCharShow.TabIndex = 5;
            this.LblCharShow.Text = "Ա";
            this.LblCharShow.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LblShowChar
            // 
            this.LblShowChar.BackColor = System.Drawing.Color.Transparent;
            this.LblShowChar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LblShowChar.Font = new System.Drawing.Font("Sylfaen", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblShowChar.Location = new System.Drawing.Point(117, 38);
            this.LblShowChar.Name = "LblShowChar";
            this.LblShowChar.Size = new System.Drawing.Size(100, 24);
            this.LblShowChar.TabIndex = 6;
            this.LblShowChar.Text = "<-- Uni-символ";
            this.LblShowChar.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LblCharDesc
            // 
            this.LblCharDesc.BackColor = System.Drawing.Color.LightGray;
            this.LblCharDesc.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.LblCharDesc.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LblCharDesc.Location = new System.Drawing.Point(117, 65);
            this.LblCharDesc.Name = "LblCharDesc";
            this.LblCharDesc.Size = new System.Drawing.Size(205, 48);
            this.LblCharDesc.TabIndex = 7;
            // 
            // FMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 119);
            this.Controls.Add(this.LblCharDesc);
            this.Controls.Add(this.LblShowChar);
            this.Controls.Add(this.LblCharShow);
            this.Controls.Add(this.BtnShow);
            this.Controls.Add(this.ChkBoxAutoShow);
            this.Controls.Add(this.TxtBoxHex);
            this.Controls.Add(this.LblHex);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FMain";
            this.ShowInTaskbar = false;
            this.Text = "Hex2Unicode";
            this.TopMost = true;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblHex;
        private System.Windows.Forms.TextBox TxtBoxHex;
        private System.Windows.Forms.CheckBox ChkBoxAutoShow;
        private System.Windows.Forms.Button BtnShow;
        private System.Windows.Forms.Label LblCharShow;
        private System.Windows.Forms.Label LblShowChar;
        private System.Windows.Forms.Label LblCharDesc;
    }
}

