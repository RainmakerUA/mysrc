﻿namespace FullflashComparer
{
    partial class FFCMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label lblSizeSrc;
            System.Windows.Forms.Label lblOffsetSrc;
            System.Windows.Forms.Label lblSizeTarg;
            System.Windows.Forms.Label lblOffsetTarg;
            System.Windows.Forms.Label lblPatchAlign;
            System.Windows.Forms.Label lbl1NoAlign;
            System.Windows.Forms.Label lblPatchText;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FFCMain));
            this.grpBoxSrc = new System.Windows.Forms.GroupBox();
            this.btnLoadSrc = new System.Windows.Forms.Button();
            this.txtBoxSizeSrc = new System.Windows.Forms.TextBox();
            this.txtBoxOffsetSrc = new System.Windows.Forms.TextBox();
            this.txtBoxSrc = new System.Windows.Forms.TextBox();
            this.grpBoxTarg = new System.Windows.Forms.GroupBox();
            this.btnLoadTarg = new System.Windows.Forms.Button();
            this.txtBoxSizeTarg = new System.Windows.Forms.TextBox();
            this.txtBoxOffsetTarg = new System.Windows.Forms.TextBox();
            this.txtBoxTarg = new System.Windows.Forms.TextBox();
            this.numUpDnPatchOffset = new System.Windows.Forms.NumericUpDown();
            this.txtBoxPatch = new System.Windows.Forms.TextBox();
            this.btnMakePatch = new System.Windows.Forms.Button();
            this.btnSavePatch = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.openFileDlg = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDlg = new System.Windows.Forms.SaveFileDialog();
            this.statusStripInfo = new System.Windows.Forms.StatusStrip();
            this.toolStripProgress = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatLblInfo = new System.Windows.Forms.ToolStripStatusLabel();
            lblSizeSrc = new System.Windows.Forms.Label();
            lblOffsetSrc = new System.Windows.Forms.Label();
            lblSizeTarg = new System.Windows.Forms.Label();
            lblOffsetTarg = new System.Windows.Forms.Label();
            lblPatchAlign = new System.Windows.Forms.Label();
            lbl1NoAlign = new System.Windows.Forms.Label();
            lblPatchText = new System.Windows.Forms.Label();
            this.grpBoxSrc.SuspendLayout();
            this.grpBoxTarg.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnPatchOffset)).BeginInit();
            this.statusStripInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblSizeSrc
            // 
            lblSizeSrc.AutoSize = true;
            lblSizeSrc.Location = new System.Drawing.Point(198, 52);
            lblSizeSrc.Name = "lblSizeSrc";
            lblSizeSrc.Size = new System.Drawing.Size(30, 13);
            lblSizeSrc.TabIndex = 10;
            lblSizeSrc.Text = "Size:";
            // 
            // lblOffsetSrc
            // 
            lblOffsetSrc.AutoSize = true;
            lblOffsetSrc.Location = new System.Drawing.Point(15, 52);
            lblOffsetSrc.Name = "lblOffsetSrc";
            lblOffsetSrc.Size = new System.Drawing.Size(38, 13);
            lblOffsetSrc.TabIndex = 8;
            lblOffsetSrc.Text = "Offset:";
            // 
            // lblSizeTarg
            // 
            lblSizeTarg.AutoSize = true;
            lblSizeTarg.Location = new System.Drawing.Point(198, 52);
            lblSizeTarg.Name = "lblSizeTarg";
            lblSizeTarg.Size = new System.Drawing.Size(30, 13);
            lblSizeTarg.TabIndex = 10;
            lblSizeTarg.Text = "Size:";
            // 
            // lblOffsetTarg
            // 
            lblOffsetTarg.AutoSize = true;
            lblOffsetTarg.Location = new System.Drawing.Point(15, 52);
            lblOffsetTarg.Name = "lblOffsetTarg";
            lblOffsetTarg.Size = new System.Drawing.Size(38, 13);
            lblOffsetTarg.TabIndex = 8;
            lblOffsetTarg.Text = "Offset:";
            // 
            // lblPatchAlign
            // 
            lblPatchAlign.AutoSize = true;
            lblPatchAlign.Location = new System.Drawing.Point(314, 170);
            lblPatchAlign.Name = "lblPatchAlign";
            lblPatchAlign.Size = new System.Drawing.Size(33, 13);
            lblPatchAlign.TabIndex = 14;
            lblPatchAlign.Text = "Align:";
            // 
            // lbl1NoAlign
            // 
            lbl1NoAlign.AutoSize = true;
            lbl1NoAlign.Location = new System.Drawing.Point(314, 209);
            lbl1NoAlign.Name = "lbl1NoAlign";
            lbl1NoAlign.Size = new System.Drawing.Size(68, 13);
            lbl1NoAlign.TabIndex = 15;
            lbl1NoAlign.Text = "(1 = no align)";
            // 
            // lblPatchText
            // 
            lblPatchText.AutoSize = true;
            lblPatchText.Location = new System.Drawing.Point(15, 170);
            lblPatchText.Name = "lblPatchText";
            lblPatchText.Size = new System.Drawing.Size(192, 13);
            lblPatchText.TabIndex = 17;
            lblPatchText.Text = "Patch to turn Source FF into Target FF:";
            // 
            // grpBoxSrc
            // 
            this.grpBoxSrc.Controls.Add(this.btnLoadSrc);
            this.grpBoxSrc.Controls.Add(lblSizeSrc);
            this.grpBoxSrc.Controls.Add(this.txtBoxSizeSrc);
            this.grpBoxSrc.Controls.Add(lblOffsetSrc);
            this.grpBoxSrc.Controls.Add(this.txtBoxOffsetSrc);
            this.grpBoxSrc.Controls.Add(this.txtBoxSrc);
            this.grpBoxSrc.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpBoxSrc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grpBoxSrc.Location = new System.Drawing.Point(0, 0);
            this.grpBoxSrc.Name = "grpBoxSrc";
            this.grpBoxSrc.Size = new System.Drawing.Size(392, 83);
            this.grpBoxSrc.TabIndex = 0;
            this.grpBoxSrc.TabStop = false;
            this.grpBoxSrc.Text = "Source FF file";
            // 
            // btnLoadSrc
            // 
            this.btnLoadSrc.Location = new System.Drawing.Point(345, 19);
            this.btnLoadSrc.Name = "btnLoadSrc";
            this.btnLoadSrc.Size = new System.Drawing.Size(34, 21);
            this.btnLoadSrc.TabIndex = 11;
            this.btnLoadSrc.Text = "...";
            this.btnLoadSrc.UseVisualStyleBackColor = true;
            this.btnLoadSrc.Click += new System.EventHandler(this.btnLoadSrc_Click);
            // 
            // txtBoxSizeSrc
            // 
            this.txtBoxSizeSrc.Location = new System.Drawing.Point(239, 49);
            this.txtBoxSizeSrc.Name = "txtBoxSizeSrc";
            this.txtBoxSizeSrc.Size = new System.Drawing.Size(100, 20);
            this.txtBoxSizeSrc.TabIndex = 9;
            this.txtBoxSizeSrc.Text = "0x00000000";
            this.txtBoxSizeSrc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtBoxOffsetSrc
            // 
            this.txtBoxOffsetSrc.Location = new System.Drawing.Point(59, 50);
            this.txtBoxOffsetSrc.Name = "txtBoxOffsetSrc";
            this.txtBoxOffsetSrc.Size = new System.Drawing.Size(100, 20);
            this.txtBoxOffsetSrc.TabIndex = 7;
            this.txtBoxOffsetSrc.Text = "0x00000000";
            this.txtBoxOffsetSrc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtBoxSrc
            // 
            this.txtBoxSrc.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtBoxSrc.Location = new System.Drawing.Point(14, 19);
            this.txtBoxSrc.Name = "txtBoxSrc";
            this.txtBoxSrc.ReadOnly = true;
            this.txtBoxSrc.Size = new System.Drawing.Size(325, 20);
            this.txtBoxSrc.TabIndex = 6;
            this.txtBoxSrc.Text = "Press \"...\" button to load source file";
            // 
            // grpBoxTarg
            // 
            this.grpBoxTarg.Controls.Add(this.btnLoadTarg);
            this.grpBoxTarg.Controls.Add(lblSizeTarg);
            this.grpBoxTarg.Controls.Add(this.txtBoxSizeTarg);
            this.grpBoxTarg.Controls.Add(lblOffsetTarg);
            this.grpBoxTarg.Controls.Add(this.txtBoxOffsetTarg);
            this.grpBoxTarg.Controls.Add(this.txtBoxTarg);
            this.grpBoxTarg.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpBoxTarg.Location = new System.Drawing.Point(0, 83);
            this.grpBoxTarg.Name = "grpBoxTarg";
            this.grpBoxTarg.Size = new System.Drawing.Size(392, 83);
            this.grpBoxTarg.TabIndex = 12;
            this.grpBoxTarg.TabStop = false;
            this.grpBoxTarg.Text = "Target FF file";
            // 
            // btnLoadTarg
            // 
            this.btnLoadTarg.Location = new System.Drawing.Point(345, 19);
            this.btnLoadTarg.Name = "btnLoadTarg";
            this.btnLoadTarg.Size = new System.Drawing.Size(34, 21);
            this.btnLoadTarg.TabIndex = 11;
            this.btnLoadTarg.Text = "...";
            this.btnLoadTarg.UseVisualStyleBackColor = true;
            this.btnLoadTarg.Click += new System.EventHandler(this.btnLoadTarg_Click);
            // 
            // txtBoxSizeTarg
            // 
            this.txtBoxSizeTarg.Location = new System.Drawing.Point(239, 49);
            this.txtBoxSizeTarg.Name = "txtBoxSizeTarg";
            this.txtBoxSizeTarg.Size = new System.Drawing.Size(100, 20);
            this.txtBoxSizeTarg.TabIndex = 9;
            this.txtBoxSizeTarg.Text = "0x00000000";
            this.txtBoxSizeTarg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtBoxOffsetTarg
            // 
            this.txtBoxOffsetTarg.Location = new System.Drawing.Point(59, 50);
            this.txtBoxOffsetTarg.Name = "txtBoxOffsetTarg";
            this.txtBoxOffsetTarg.Size = new System.Drawing.Size(100, 20);
            this.txtBoxOffsetTarg.TabIndex = 7;
            this.txtBoxOffsetTarg.Text = "0x00000000";
            this.txtBoxOffsetTarg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtBoxTarg
            // 
            this.txtBoxTarg.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtBoxTarg.Location = new System.Drawing.Point(14, 19);
            this.txtBoxTarg.Name = "txtBoxTarg";
            this.txtBoxTarg.ReadOnly = true;
            this.txtBoxTarg.Size = new System.Drawing.Size(325, 20);
            this.txtBoxTarg.TabIndex = 6;
            this.txtBoxTarg.Text = "Press \"...\" button to load target file";
            // 
            // numUpDnPatchOffset
            // 
            this.numUpDnPatchOffset.Location = new System.Drawing.Point(317, 186);
            this.numUpDnPatchOffset.Maximum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.numUpDnPatchOffset.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numUpDnPatchOffset.Name = "numUpDnPatchOffset";
            this.numUpDnPatchOffset.Size = new System.Drawing.Size(62, 20);
            this.numUpDnPatchOffset.TabIndex = 13;
            this.numUpDnPatchOffset.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numUpDnPatchOffset.Value = new decimal(new int[] {
            16,
            0,
            0,
            0});
            // 
            // txtBoxPatch
            // 
            this.txtBoxPatch.Font = new System.Drawing.Font("Courier New", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxPatch.Location = new System.Drawing.Point(18, 186);
            this.txtBoxPatch.Multiline = true;
            this.txtBoxPatch.Name = "txtBoxPatch";
            this.txtBoxPatch.ReadOnly = true;
            this.txtBoxPatch.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtBoxPatch.Size = new System.Drawing.Size(293, 154);
            this.txtBoxPatch.TabIndex = 16;
            this.txtBoxPatch.WordWrap = false;
            // 
            // btnMakePatch
            // 
            this.btnMakePatch.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnMakePatch.ForeColor = System.Drawing.Color.Olive;
            this.btnMakePatch.Location = new System.Drawing.Point(318, 226);
            this.btnMakePatch.Name = "btnMakePatch";
            this.btnMakePatch.Size = new System.Drawing.Size(64, 34);
            this.btnMakePatch.TabIndex = 18;
            this.btnMakePatch.Text = "Make\r\nPatch";
            this.btnMakePatch.UseVisualStyleBackColor = true;
            this.btnMakePatch.Click += new System.EventHandler(this.btnMakePatch_Click);
            // 
            // btnSavePatch
            // 
            this.btnSavePatch.Location = new System.Drawing.Point(318, 267);
            this.btnSavePatch.Name = "btnSavePatch";
            this.btnSavePatch.Size = new System.Drawing.Size(64, 23);
            this.btnSavePatch.TabIndex = 19;
            this.btnSavePatch.Text = "Save...";
            this.btnSavePatch.UseVisualStyleBackColor = true;
            this.btnSavePatch.Click += new System.EventHandler(this.btnSavePatch_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnExit.ForeColor = System.Drawing.Color.Red;
            this.btnExit.Location = new System.Drawing.Point(318, 297);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(64, 43);
            this.btnExit.TabIndex = 20;
            this.btnExit.Text = "Exit...";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // openFileDlg
            // 
            this.openFileDlg.DefaultExt = "*.bin";
            this.openFileDlg.DereferenceLinks = false;
            this.openFileDlg.FileName = "openFileDialog1";
            this.openFileDlg.Filter = "Fullflash files (*.bin; *.fls)|*.bin;*.fls|All files (*.*)|*.*";
            // 
            // saveFileDlg
            // 
            this.saveFileDlg.DefaultExt = "*.vkp";
            this.saveFileDlg.Filter = "V-Klay Patch files (*.vkp)|*.vkp|Text files (*.txt)|*.txt|All files (*.*)|*.*";
            this.saveFileDlg.Title = "Save generated patch as...";
            // 
            // statusStripInfo
            // 
            this.statusStripInfo.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripProgress,
            this.toolStripStatLblInfo});
            this.statusStripInfo.Location = new System.Drawing.Point(0, 345);
            this.statusStripInfo.Name = "statusStripInfo";
            this.statusStripInfo.Size = new System.Drawing.Size(392, 22);
            this.statusStripInfo.SizingGrip = false;
            this.statusStripInfo.TabIndex = 21;
            // 
            // toolStripProgress
            // 
            this.toolStripProgress.Name = "toolStripProgress";
            this.toolStripProgress.Size = new System.Drawing.Size(160, 16);
            this.toolStripProgress.Step = 1;
            this.toolStripProgress.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.toolStripProgress.Value = 100;
            // 
            // toolStripStatLblInfo
            // 
            this.toolStripStatLblInfo.Name = "toolStripStatLblInfo";
            this.toolStripStatLblInfo.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatLblInfo.Text = "Ready";
            // 
            // FFCMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 367);
            this.Controls.Add(this.statusStripInfo);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSavePatch);
            this.Controls.Add(this.btnMakePatch);
            this.Controls.Add(lblPatchText);
            this.Controls.Add(this.txtBoxPatch);
            this.Controls.Add(lbl1NoAlign);
            this.Controls.Add(lblPatchAlign);
            this.Controls.Add(this.numUpDnPatchOffset);
            this.Controls.Add(this.grpBoxTarg);
            this.Controls.Add(this.grpBoxSrc);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FFCMain";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "[RM®] Fullflash Comparer™";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FFCMain_FormClosing);
            this.grpBoxSrc.ResumeLayout(false);
            this.grpBoxSrc.PerformLayout();
            this.grpBoxTarg.ResumeLayout(false);
            this.grpBoxTarg.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDnPatchOffset)).EndInit();
            this.statusStripInfo.ResumeLayout(false);
            this.statusStripInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpBoxSrc;
        private System.Windows.Forms.Button btnLoadSrc;
        private System.Windows.Forms.TextBox txtBoxSizeSrc;
        private System.Windows.Forms.TextBox txtBoxOffsetSrc;
        private System.Windows.Forms.TextBox txtBoxSrc;
        private System.Windows.Forms.GroupBox grpBoxTarg;
        private System.Windows.Forms.Button btnLoadTarg;
        private System.Windows.Forms.TextBox txtBoxSizeTarg;
        private System.Windows.Forms.TextBox txtBoxOffsetTarg;
        private System.Windows.Forms.TextBox txtBoxTarg;
        private System.Windows.Forms.NumericUpDown numUpDnPatchOffset;
        private System.Windows.Forms.TextBox txtBoxPatch;
        private System.Windows.Forms.Button btnMakePatch;
        private System.Windows.Forms.Button btnSavePatch;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.OpenFileDialog openFileDlg;
        private System.Windows.Forms.SaveFileDialog saveFileDlg;
        private System.Windows.Forms.StatusStrip statusStripInfo;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgress;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatLblInfo;

    }
}

