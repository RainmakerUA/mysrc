﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace FullflashComparer
{
    internal partial class FFCMain : Form
    {
        FileStream fs_src , fs_targ;
        string name_src = "";
        string name_targ = "";

        public FFCMain()
        {
            InitializeComponent();
            CheckForIllegalCrossThreadCalls = false;
            btnLoadSrc.Focus();
        }

        private void btnExit_Click( object sender , EventArgs e )
        {
            Close();
        }

        private void FFCMain_FormClosing( object sender , FormClosingEventArgs e )
        {
            e.Cancel = MessageBox.Show( "Are you sure to exit?" , Text ,
                    MessageBoxButtons.YesNo , MessageBoxIcon.Question , MessageBoxDefaultButton.Button1 )
                    != DialogResult.Yes;
        }

        private void btnLoadSrc_Click( object sender , EventArgs e )
        {
            openFileDlg.Title = "Open Source FF File...";
            openFileDlg.FileName = "";
            if ( openFileDlg.ShowDialog() == DialogResult.OK )
            {
                name_src = openFileDlg.FileName;
                txtBoxSrc.Text = name_src;
                fs_src = File.Open( name_src , FileMode.Open , FileAccess.Read , FileShare.Read );
                txtBoxSizeSrc.Text = "0x" + fs_src.Length.ToString( "x8" );
            }
            openFileDlg.Title = "";
        }

        private void btnLoadTarg_Click( object sender , EventArgs e )
        {
            openFileDlg.Title = "Open Target FF File...";
            openFileDlg.FileName = "";
            if ( openFileDlg.ShowDialog() == DialogResult.OK )
            {
                name_targ = openFileDlg.FileName;
                txtBoxTarg.Text = name_targ;
                fs_targ = File.Open( name_targ , FileMode.Open , FileAccess.Read , FileShare.Read );
                txtBoxSizeTarg.Text = "0x" + fs_targ.Length.ToString( "x8" );
            }
            openFileDlg.Title = "";
        }

        private void btnSavePatch_Click( object sender , EventArgs e )
        {
            saveFileDlg.FileName = "";
            if ( saveFileDlg.ShowDialog() == DialogResult.OK )
            {
                Encoding encCP1251 = Encoding.GetEncoding( 1251 );
                byte[] CP1251Text = encCP1251.GetBytes( txtBoxPatch.Text );
                FileStream fs = File.Open( saveFileDlg.FileName , FileMode.Create ,
                        FileAccess.Write , FileShare.None );
                fs.Write( CP1251Text , 0 , CP1251Text.Length );
                fs.Close();
            }
        }

        private void btnMakePatch_Click( object sender , EventArgs e )
        {
            btnMakePatch.Enabled = false;
            btnExit.Enabled = false;
            Thread genThread = new Thread( new ThreadStart( GeneratePatch ) );
            genThread.Start();
            Thread waitThread = new Thread( new ParameterizedThreadStart( WaitGenerate ) );
            waitThread.Start( genThread );
        }

        private void WaitGenerate( object thr )
        {
            ( thr as Thread ).Join();
            btnMakePatch.Enabled = true;
            btnExit.Enabled = true;
            toolStripProgress.Value = 100;
            toolStripStatLblInfo.Text = "Ready";
        }

        private void GeneratePatch()
        {
            #region fs_check
            if ( fs_src == null && fs_targ == null )
            {
                MessageBox.Show( "First you must open Source ant Target FF files!" );
                return;
            }
            if ( fs_src == null )
            {
                MessageBox.Show( "First you must open Source FF file!" );
                return;
            }
            if ( fs_targ == null )
            {
                MessageBox.Show( "First you must open Target FF file!" );
                return;
            }
            #endregion

            if ( name_src == name_targ )
            {
                MessageBox.Show( "You are trying to compare file with itself!" , Text , MessageBoxButtons.OK , MessageBoxIcon.Exclamation );
                return;
            }

            lock ( this )
            {
                toolStripProgress.Value = 0;
                toolStripStatLblInfo.Text = "Parsing...";
            }

            List<PatchItem> patch = new List<PatchItem>();

            const int MAXPATCH = 1024 * 1024;
            long SrcOffset , TargOffset;
            long BytesToRead;
            byte MaxBytesPerLine;

            #region Horrible Parsing
            try
            {
                lock ( this )
                {
                    long SrcSize , TargSize;
                    string strSrcOff , strTargOff , strSrcSize , strTargSize;

                    txtBoxOffsetSrc.Focus();
                    strSrcOff = ( txtBoxOffsetSrc.Text.Contains( "0x" ) ) ?
                            txtBoxOffsetSrc.Text.Replace( "0x" , "" ) : txtBoxOffsetSrc.Text;
                    SrcOffset = long.Parse( strSrcOff , NumberStyles.HexNumber );

                    txtBoxOffsetTarg.Focus();
                    strTargOff = ( txtBoxOffsetTarg.Text.Contains( "0x" ) ) ?
                            txtBoxOffsetTarg.Text.Replace( "0x" , "" ) : txtBoxOffsetTarg.Text;
                    TargOffset = long.Parse( strTargOff , NumberStyles.HexNumber );

                    txtBoxSizeSrc.Focus();
                    strSrcSize = ( txtBoxSizeSrc.Text.Contains( "0x" ) ) ?
                            txtBoxSizeSrc.Text.Replace( "0x" , "" ) : txtBoxSizeSrc.Text;
                    SrcSize = long.Parse( strSrcSize , NumberStyles.HexNumber );

                    txtBoxSizeTarg.Focus();
                    strTargSize = ( txtBoxSizeTarg.Text.Contains( "0x" ) ) ?
                            txtBoxSizeTarg.Text.Replace( "0x" , "" ) : txtBoxSizeTarg.Text;
                    TargSize = long.Parse( strTargSize , NumberStyles.HexNumber );

                    long BytesToReadSrc = Math.Min( SrcSize , fs_src.Length - SrcOffset );
                    long BytesToReadTarg = Math.Min( TargSize , fs_targ.Length - TargOffset );
                    BytesToRead = Math.Min( BytesToReadSrc , BytesToReadTarg );
                    if ( BytesToRead < 0 )
                    {
                        MessageBox.Show( "Range error!\nSome offset may be not in file" ,
                                Text , MessageBoxButtons.OK , MessageBoxIcon.Exclamation );
                        return;
                    }

                    numUpDnPatchOffset.Focus();
                    MaxBytesPerLine = (byte) numUpDnPatchOffset.Value;

                    btnSavePatch.Focus();
                }
            }
            catch ( Exception exc )
            {
                MessageBox.Show( exc.Message , Text , MessageBoxButtons.OK , MessageBoxIcon.Error );
                return;
            }
            #endregion

            lock ( this )
            {
                toolStripProgress.Value = 0;
                toolStripStatLblInfo.Text = "Comparing...";
            }

            // Compare
            fs_src.Position = SrcOffset;
            fs_targ.Position = TargOffset;
            for ( long i = 0; i < BytesToRead; i++ )
            {
                lock ( this )
                {
                    toolStripProgress.Value = (int) ( 100 * i / BytesToRead );
                }
                long addr = fs_src.Position;
                byte src = (byte) fs_src.ReadByte();
                byte targ = (byte) fs_targ.ReadByte();
                if ( src != targ )
                {
                    patch.Add(
                            new PatchItem
                            {
                                Address = addr ,
                                OldData = src.ToString( "x2" ) ,
                                NewData = targ.ToString( "x2" )
                            } );
                    if ( patch.Count > MAXPATCH )
                    {
                        MessageBox.Show( "Files are too different!\nNot enough memory to process all patch" ,
                                Text , MessageBoxButtons.OK , MessageBoxIcon.Exclamation );
                        return;
                    }
                }
            }

            if ( patch.Count == 0 )
            {
                MessageBox.Show( "Files are identical in specified range!" , Text , MessageBoxButtons.OK , MessageBoxIcon.Information );
                lock ( this )
                {
                    txtBoxPatch.Clear();
                    txtBoxPatch.AppendText( "; Converted @ " + DateTime.Now.ToString() + "\r\n" );
                    txtBoxPatch.AppendText( "; Source file:\r\n; " + name_src + "\r\n" );
                    txtBoxPatch.AppendText( "; Target file:\r\n; " + name_targ + "\r\n\r\n" );
                    txtBoxPatch.AppendText( "; Files are identical!" );
                }
                return;
            }

            // Optimize

            lock ( this )
            {
                toolStripProgress.Value = 0;
                toolStripStatLblInfo.Text = "Optimizing...";
            }

            int ind = 0;
            while ( ind < patch.Count - 1 )
            {
                lock ( this )
                {
                    toolStripProgress.Value = 100 * ind / patch.Count;
                }
                if ( patch[ ind ].Concat( patch[ ind + 1 ] , MaxBytesPerLine ) )
                    patch.RemoveAt( ind + 1 );
                else
                    ind++;
            }
            // Fill TextBox

            lock ( this )
            {
                toolStripProgress.Value = 0;
                toolStripStatLblInfo.Text = "Writing...";
            }
            txtBoxPatch.Clear();
            txtBoxPatch.AppendText( "; Converted @ " + DateTime.Now.ToString() + "\r\n" );
            txtBoxPatch.AppendText( "; Source file:\r\n; " + name_src + "\r\n" );
            txtBoxPatch.AppendText( "; Target file:\r\n; " + name_targ + "\r\n\r\n" );

            for ( int c = 0; c < patch.Count; c++ )
            {
                lock ( this )
                {
                    toolStripProgress.Value = 100 * c / patch.Count;
                    txtBoxPatch.AppendText( patch[ c ].ToString().ToUpper() + "\r\n" );
                }
            }
        }
    }

    class PatchItem
    {
        public long Address;
        public string OldData;
        public string NewData;

        public bool Concat( PatchItem Next , int MaxLen )
        {
            if ( ( ( NewData.Length / 2 ) >= MaxLen ) || ( ( Address + NewData.Length / 2 ) != Next.Address ) )
                return false;
            OldData += Next.OldData;
            NewData += Next.NewData;
            return true;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat( "{0:x7}: " , Address );
            sb.Append( OldData );
            sb.Append( '\u0020' );
            sb.Append( NewData );
            return sb.ToString();
        }
    }
}
