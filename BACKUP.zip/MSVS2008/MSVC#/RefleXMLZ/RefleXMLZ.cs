﻿using System;
using System.Linq;
using System.Xml.Linq;
using System.Reflection;
using System.Text;
using System.Globalization;
using System.IO.Compression;
using System.Collections.Generic;


namespace RMDevel.RefleXMLZ
{
    /// <summary>
    /// Special exception type
    /// </summary>
    public class ReflException : Exception
    {
        public ReflException()
            : base("RefleXML Exception thrown!")
        {
        }

        public ReflException(string message)
            : base(message)
        {
        }

        public ReflException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }

    /// <summary>
    /// Contains extension methods for
    /// reading and writing objects' properties into XML
    /// with GZIP compression
    /// </summary>
    public static class RefleXMLZ
    {
        private const string PropertyNodeName = "prop";
        private const string PropertyNameAttribute = "name";
        private const string PropertyValueAttribute = "value";

        private static CultureInfo _culture;
        private static Type[] _types;

        /// <summary>
        /// RefleXML class static constructor
        /// </summary>
        static RefleXMLZ()
        {
            _culture = new CultureInfo("en-US");
            _types = new Type[]
                {
                    typeof(Boolean),
                    typeof(Byte),
                    typeof(Char),
                    typeof(DateTime),
                    typeof(Decimal),
                    typeof(Double),
                    typeof(Int16),
                    typeof(Int32),
                    typeof(Int64),
                    typeof(SByte),
                    typeof(Single),
                    typeof(String),
                    typeof(UInt16),
                    typeof(UInt32),
                    typeof(UInt64)
                };
        }

        /// <summary>
        /// Determines, whether property type is supported
        /// and able to be serialized
        /// </summary>
        /// <param name="type">Property type</param>
        /// <returns>whether property type is supported</returns>
        internal static bool IsTypeSupported(Type type)
        {
            return type.IsEnum || _types.Any(t => t.Name == type.Name);
        }

        /// <summary>
        /// Loads object properties from specified XElement
        /// (an XML-element or document root)
        /// </summary>
        /// <param name="Object">Object instance, which properties to load</param>
        /// <param name="Node">XML Element with properties data</param>
        public static void LoadXML(this object Object, XElement Node)
        {
            Type t = Object.GetType();
            PropertyInfo[] props = t.GetProperties(BindingFlags.Public | BindingFlags.Instance);
            XElement[] xels = Node.Elements(PropertyNodeName).ToArray();

            foreach (XElement xe in xels)
            {
                try
                {
                    string name = xe.Attribute(PropertyNameAttribute).Value;
                    PropertyInfo prop = props.First(p => p.Name == name);
                    if (prop.CanWrite)
                    {
                        object value = xe.Attribute(PropertyValueAttribute).Value;
                        Type prop_type = prop.PropertyType;
                        if (prop_type.IsEnum)
                            value = Enum.Parse(prop_type, value.ToString());
                        else
                            value = Convert.ChangeType(value, prop.PropertyType, _culture);

                        prop.SetValue(Object, value, null);
                    }
                }
                catch
                {
                    continue;
                }
            }
        }

        public static XElement SaveXML<TElemType>(this IEnumerable<TElemType> enumerable, string ElementName)
        {
            XElement res = new XElement(ElementName);
            return res;
        }

        /// <summary>
        /// Saves object properties to XElement
        /// (an XML-element - part of XML-document)
        /// with specified name
        /// </summary>
        /// <param name="Object">Object instance, which properties to save</param>
        /// <param name="ElementName">Name of XML Element with properties data</param>
        /// <returns>XML Element with properties data</returns>
        public static XElement SaveXML(this object Object, string ElementName)
        {
            XElement res = new XElement(ElementName);
            Type t = Object.GetType();
            PropertyInfo[] props = t.GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in props)
            {
                try
                {
                    Type prop_type = prop.PropertyType;
                    if ((prop.CanRead && prop.CanWrite) && IsTypeSupported(prop_type))
                    {
                        object val = prop.GetValue(Object, null);
                        res.Add(
                                new XElement(PropertyNodeName,
                                        new XAttribute(PropertyNameAttribute, prop.Name),
                                        new XAttribute(PropertyValueAttribute, Convert.ToString(val, _culture))
                                    )
                            );
                    }
                }
                catch
                {
                    continue;
                }
            }
            return res;
        }
    }
}
