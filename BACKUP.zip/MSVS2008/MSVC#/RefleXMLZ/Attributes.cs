﻿using System;

namespace RMDevel.RefleXMLZ
{
    /// <summary>
    /// Attribute, showing that class will be serialized
    /// with RefleXMLZ library
    /// </summary>
    [AttributeUsage(AttributeTargets.Class)]
    public class StoredAttribute : Attribute
    {
    }

    /// <summary>
    /// Attribute, showing that class property
    /// should be serialized
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class StoreAtribute : Attribute
    {
        private const string NotSupportedError = "Property type {0} not supported for serialization!";

        /// <summary>
        /// Determines property type
        /// </summary>
        /// <param name="propertyType">Property type</param>
        public StoreAtribute(Type propertyType)
        {
            if (!RefleXMLZ.IsTypeSupported(propertyType))
                throw new ReflException(String.Format(NotSupportedError, propertyType.FullName));
        }
    }
}