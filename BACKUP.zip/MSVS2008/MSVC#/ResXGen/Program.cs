﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Resources;

namespace ResXGen
{
    class Program
    {
        static void Main(string[] args)
        {
            string s;
            int i = 0;
            int e = 0;
            ResXResourceWriter rw = new ResXResourceWriter("FontNames.resx");
            while (e <= 10)
            {
                s = Console.ReadLine();
                e++;
                if ( (s != null) && (s != "") && (s[0] >= '0') && (s[0] <= '9'))
                {
                    int comma_pos = s.IndexOf(',');
                    string s1 = s.Substring(0, comma_pos);
                    int quote_pos1 = s.IndexOf('"');
                    int quote_pos2 = s.LastIndexOf('"');
                    string s2 = s.Substring(quote_pos1 + 1, quote_pos2 - quote_pos1 - 1);
                    rw.AddResource(s1, s2);
                    i++;
                    e = 0;
                }
                Console.WriteLine("\r i = {0} e = {1}", i, e);
            }
            rw.Generate();
            rw.Close();
            Console.WriteLine("i = {0}", i);
        }
    }
}
