﻿using System.Drawing;
using System.Windows.Forms;
using RMDevel.TwoEditsClipbrd;
using System.Text;
using System.Text.RegularExpressions;
using System.Net;

namespace NOD32Keys
{
    public partial class FN32KMain : Form
    {
        private const string URL = "http://www.nod321.com/";
        private const string REGEXP = @"\s*Username:\s*(?<login>\S*?)\s*<br\s*/>\s*Password:\s*(?<passw>\S*?)\s*<";
        //private const string DEBUGSTR = "<div class=\"post-body\">Username:EAV-03512740<br/>Password:7f5c4w4u2s<br/><br/>Username:EAV-03512739<br/>Password:jmbh3r44r7<br/><br/>Username:EAV-03517725<br/>Password:u44wtmbpm6<br/><br/>Username:EAV-03517710<br/>Password:5nrss27f2f<br/><br/>Username:EAV-03517128<br/>Password:3585ur3tbt<br/><br/>Username:EAV-03512738<br/>Password:wtjp3h4afm<br/><br/>Username:EAV-03517689<br/>Password:fwurcnn4vc</div>";


        public FN32KMain()
        {
            InitializeComponent();

            string content = Encoding.UTF8.GetString((new WebClient()).DownloadData(URL));

            Regex reg = new Regex(REGEXP, RegexOptions.CultureInvariant | RegexOptions.IgnoreCase);
            //MatchCollection mtchs = reg.Matches(DEBUGSTR);
            MatchCollection mtchs = reg.Matches(content);

            for (int i = 0; i < mtchs.Count; i++)
            {
                TwoEditsClipbrd ctrl = new TwoEditsClipbrd();
                ctrl.ControlTextLogin = mtchs[i].Groups["login"].Value;
                ctrl.ControlTextPassword = mtchs[i].Groups["passw"].Value;
                ctrl.Location = new Point(0, i * (ctrl.Size.Height + 5));
                //ctrl.ControlFlatStyle = FlatStyle.Flat;

                panData.Controls.Add(ctrl);
            }
        }

        private void btnClose_Click(object sender, System.EventArgs e)
        {
            Close();
        }
    }
}
