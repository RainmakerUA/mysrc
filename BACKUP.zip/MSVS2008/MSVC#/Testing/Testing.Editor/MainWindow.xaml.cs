﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;
using Testing.Editor.Controls;
using Testing.Lib;
using System.Xml.Linq;
using Testing.Lib.XmlZ;

namespace Testing.Editor
{
	/// <summary>
	/// Логика взаимодействия для MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private ITestEditor _editor;

		public MainWindow()
		{
			InitializeComponent();

			ApplicationCommands.New.Text = "Создать";
			ApplicationCommands.Open.Text = "Открыть…";
			ApplicationCommands.Save.Text = "Сохранить";
			ApplicationCommands.SaveAs.Text = "Сохранить как…";

			CommandBindings.AddRange(
					new[]
					{
						new CommandBinding( ApplicationCommands.New , OnCreate ),
						new CommandBinding( ApplicationCommands.Open, OnOpen)
					}
				);
		}

		private bool CheckUnsavedData()
		{
			if ( _editor.IsChanged )
			{
				MessageBoxResult mbres = MessageBox.Show(
						"Существующие данные были изменены.\nСохранить изменения?" ,
						Title , MessageBoxButton.YesNoCancel ,
						MessageBoxImage.Question , MessageBoxResult.Cancel
					);

				switch ( mbres )
				{
					case MessageBoxResult.Yes:
						_editor.Save();
						return true;

					case MessageBoxResult.No:
						return true;

					case MessageBoxResult.Cancel:
						return false;
				}
			}

			return true;
		}

		private string GetOpenFileName()
		{
			return null;
		}

		private void LoadTestEditorControl( ITestEditor editor )
		{
			_editor = editor;
			DataContext = _editor;
		}

		#region Commands

		private void OnCreate( object sender , ExecutedRoutedEventArgs e )
		{
			if ( CheckUnsavedData() )
			{
				LoadTestEditorControl( new TestEditor( null ) );
			}
		}

		private void OnOpen( object sender , ExecutedRoutedEventArgs e )
		{
			if ( CheckUnsavedData() )
			{
				string filename = GetOpenFileName();
				if ( !String.IsNullOrEmpty( filename ) )
				{
					LoadTestEditorControl( new TestEditor( filename ) );
				}
			}
		}

		private void OnSave( object sender , ExecutedRoutedEventArgs e )
		{
			if(_editor !=null && _editor.IsChanged)
			{
				if(String.IsNullOrEmpty(  _editor.CurrentFilename))
				_editor.Save();
			}
		}

		private void OnSaveAs( object sender , ExecutedRoutedEventArgs e )
		{

		}

		#endregion
	}
}
