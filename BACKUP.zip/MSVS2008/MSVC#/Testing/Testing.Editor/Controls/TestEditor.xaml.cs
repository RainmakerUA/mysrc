﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Testing.Lib;
using Testing.Lib.XmlZ;

namespace Testing.Editor.Controls
{
	/// <summary>
	/// Логика взаимодействия для TestEditor.xaml
	/// </summary>
	public partial class TestEditor : UserControl , ITestEditor
	{
		private string _currentFilename;
		private Test _currentTest;
		private bool _isChanged;

		private TestEditor()
		{
			InitializeComponent();
		}

		public TestEditor( string filename )
			: this()
		{
			if ( !LoadFile( filename ) )
			{
				Clear();
			}
		}

		private void Clear()
		{
			_currentTest = new Test();
			DataContext = _currentTest;
			_currentFilename = null;
			_isChanged = false;
		}

		private bool LoadFile( string filename )
		{
			if ( String.IsNullOrEmpty( filename ) )
			{
				return false;
			}

			try
			{
				_currentTest = TestXmlZ.Deserialize( filename , false );
				_currentFilename = filename;
				_isChanged = false;
				DataContext = _currentTest;

				return true;
			}
			catch ( IOException )
			{
				return false;
			}
		}

		private bool SaveFile( string filename )
		{
			if ( String.IsNullOrEmpty( filename ) )
			{
				throw new ArgumentException( "filename cannot be null or empty string!" , "filename" );
			}

			if ( _currentTest == null )
			{
				Clear();
			}

			try
			{
				_currentTest.Serialize( filename );
				_currentFilename = filename;
				_isChanged = false;
				return true;
			}
			catch ( IOException )
			{
				return false;
			}
		}

		protected event EventHandler Changed;

		#region Члены ITestEditor

		string ITestEditor.CurrentFilename
		{
			get
			{
				return _currentFilename;
			}
		}

		bool ITestEditor.IsChanged
		{
			get
			{
				return _isChanged;
			}
		}

		Test ITestEditor.Current
		{
			get
			{
				return _currentTest;
			}
		}

		bool ITestEditor.Create()
		{
			Clear();
			return true;
		}

		bool ITestEditor.Open( string filename )
		{
			return LoadFile( filename );
		}

		bool ITestEditor.Save()
		{
			return SaveFile( _currentFilename );
		}

		bool ITestEditor.SaveAs( string filename )
		{
			return SaveFile( filename );
		}

		event EventHandler ITestEditor.Changed
		{
			add
			{
				Changed += value;
			}
			remove
			{
				Changed -= value;
			}
		}

		#endregion
	}
}
