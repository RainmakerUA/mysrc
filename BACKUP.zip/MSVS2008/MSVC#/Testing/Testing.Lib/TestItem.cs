﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using Testing.Lib.Common;

namespace Testing.Lib
{
	[Serializable]
	public sealed class TestItem : TestObject
	{
		private string _question;
		private ObservableCollection<TestItemOption> _answers;
		private byte[] _image;

		public TestItem()
		{
			// Do nothing.
		}

		public TestItem( string question , byte[] image , params TestItemOption[] answers )
			: this( question , image , answers as IEnumerable<TestItemOption> )
		{
			// Do nothing.
		}

		public TestItem( string question , byte[] image , IEnumerable<TestItemOption> answers )
		{
			_question = question;
			_answers = new ObservableCollection<TestItemOption>( answers );
			_image = image;
		}

		public string Question
		{
			get
			{
				return _question;
			}
			set
			{
				_question = value;
			}
		}

		public ObservableCollection<TestItemOption> Answers
		{
			get
			{
				return _answers;
			}
			set
			{
				_answers = value;
			}
		}

		public byte[] Image
		{
			get
			{
				return _image;
			}
			set
			{
				_image = value;
			}
		}

		public override string ToString()
		{
			return String.Format( "Test question \"{0}\" ({1} answers)" , _question , _answers.Count );
		}
	}
}
