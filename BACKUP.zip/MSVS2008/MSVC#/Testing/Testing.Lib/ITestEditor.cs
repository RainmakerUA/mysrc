﻿
using System;

namespace Testing.Lib
{
	public interface ITestEditor
	{
		string CurrentFilename { get; }
		bool IsChanged { get; }
		Test Current { get; }

		bool Create();
		bool Open( string filename );
		bool Save();
		bool SaveAs( string filename );

		event EventHandler Changed;
	}
}
