﻿using System;
using System.ComponentModel;
using Testing.Lib.Common;

namespace Testing.Lib
{
	[Serializable]
	public sealed class TestItemOption : TestObject
	{
		private string _answer;
		private bool _isCorrect;

		public TestItemOption()
		{
			// Do nothing.
		}

		public TestItemOption( string answer , bool isCorrect )
		{
			_answer = answer;
			_isCorrect = isCorrect;
		}

		public string Answer
		{
			get
			{
				return _answer;
			}
			set
			{
				_answer = value;
				OnPropertyChanged( "IsCorrect" );
			}
		}

		public bool IsCorrect
		{
			get
			{
				return _isCorrect;
			}
			set
			{
				_isCorrect = value;
				OnPropertyChanged( "IsCorrect" );
			}
		}

		public override string ToString()
		{
			return String.Format( " Test answer \"{0}\" [{1}]" , _answer , _isCorrect ? 'v' : 'x' );
		}
	}
}
