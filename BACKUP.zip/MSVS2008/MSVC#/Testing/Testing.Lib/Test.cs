﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Testing.Lib.Common;

namespace Testing.Lib
{
	[Serializable]
	public sealed class Test : TestObject
	{
		private string _title;
		private int _time;
		private ObservableCollection<TestItem> _questions;

		public Test()
		{
			// Do nothing.
		}

		public Test( string title , int time , IEnumerable<TestItem> questions )
		{
			_title = title;
			_time = time;
			_questions = new ObservableCollection<TestItem>( questions );
		}

		public Test( string title , int time , params TestItem[] questions )
			: this( title , time , questions as IEnumerable<TestItem> )
		{
			// Do nothing.
		}

		public string Title
		{
			get
			{
				return _title;
			}
			set
			{
				_title = value;
				OnPropertyChanged( "Title" );
			}
		}

		public int Time
		{
			get
			{
				return _time;
			}
			set
			{
				_time = value;
				OnPropertyChanged( "Time" );
			}
		}

		public ObservableCollection<TestItem> Questions
		{
			get
			{
				return _questions;
			}
			set
			{
				_questions = value;
				OnPropertyChanged( "Questions" );
			}
		}

		public override string ToString()
		{
			return String.Format( "Test \"{0}\" ({1} questions, {2} min)" , _title , _questions.Count , _time );
		}
	}
}
