﻿using System;
using System.ComponentModel;

namespace Testing.Lib.Common
{
	public abstract class TestObject : INotifyPropertyChanged
	{
		protected void OnPropertyChanged( string name )
		{
			if ( PropertyChanged != null && !String.IsNullOrEmpty( name ) )
			{
				PropertyChanged( this , new PropertyChangedEventArgs( name ) );
			}
		}

		#region Члены INotifyPropertyChanged

		public event PropertyChangedEventHandler PropertyChanged;

		#endregion
	}
}
