﻿using System;
using System.IO;
using System.IO.Compression;
using System.Xml.Serialization;

namespace Testing.Lib.XmlZ
{
	public static class TestXmlZ
	{
		private static readonly Type _testType = typeof( Test );

		public static void Serialize( this Test test , string filename , bool overwrite )
		{
			using ( var fs = File.Open( filename , overwrite ? FileMode.Create : FileMode.CreateNew , FileAccess.Write , FileShare.Read ) )
			{
				using ( var cs = new GZipStream( fs , CompressionMode.Compress ) )
				{
					var xser = new XmlSerializer( _testType );
					xser.Serialize( cs , test );
				}
			}
		}

		public static void Serialize( this Test test , string filename )
		{
			Serialize( test , filename , true );
		}

		public static Test Deserialize( string filename , bool silentErrors )
		{
			Test test = null;

			try
			{
				using ( var fs = File.Open( filename , FileMode.Open , FileAccess.Read , FileShare.Read ) )
				{
					using ( var cs = new GZipStream( fs , CompressionMode.Decompress ) )
					{
						var xser = new XmlSerializer( _testType );
						test = (Test) xser.Deserialize( cs );
					}
				}
			}
			catch ( Exception )
			{
				if ( !silentErrors )
				{
					throw;
				}
			}

			return test;
		}

		public static Test Deserialize( string filename )
		{
			return Deserialize( filename , false );
		}
	}
}
