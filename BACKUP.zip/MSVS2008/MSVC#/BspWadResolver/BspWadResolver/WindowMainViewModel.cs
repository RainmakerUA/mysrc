﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Windows.Data;
using System.Globalization;
using System.Windows;
using System.Timers;
using System.Text;
using System.Collections;

namespace BspWadResolver
{
    class WindowMainViewModel : INotifyPropertyChanged
    {
        private class BoolToVisibilityConverterClass : IValueConverter
        {
            private readonly Visibility _invisibilityValue;

            public BoolToVisibilityConverterClass( Visibility invisibilityValue )
            {
                _invisibilityValue = invisibilityValue;
            }

            private static Exception GetNonImplementedConvertionException( Type source , Type target )
            {
                return new NotImplementedException( String.Format( "Conversion from {0} to {1} not implemented!" , source , target ) );
            }

            #region IValueConverter Members

            public object Convert( object value , Type targetType , object parameter , CultureInfo culture )
            {
                if ( value is bool && targetType == typeof( Visibility ) )
                {
                    return ( (bool) value ) ? Visibility.Visible : _invisibilityValue;
                }
                else
                {
                    throw GetNonImplementedConvertionException( value.GetType() , targetType );
                }
            }

            public object ConvertBack( object value , Type targetType , object parameter , CultureInfo culture )
            {
                if ( value is Visibility && targetType == typeof( bool ) )
                {
                    return (Visibility) value == Visibility.Visible;
                }
                else
                {
                    throw GetNonImplementedConvertionException( value.GetType() , targetType );
                }
            }

            #endregion
        }

        private const string _APPTITLE = "[RM®] WAD from BSP Resolver ";
        private const string _IMAGESOURCEFORMAT = "/Resources/Games/{0}";
        private static BoolToVisibilityConverterClass _converter;
        private static readonly Random _rnd = new Random();
        private static readonly string[] _allIcons = {
                                                    "bs.png",
                                                    "cs.png",
                                                    "hl.png",
                                                    "hl2.png",
                                                    "hldm.png",
                                                    "of.png",
                                                    "steam.png",
                                                    "tfc.png"
                                                };

        private const char _ZEROCHAR = '-';
        private const char _ONECHAR = 'v';

        private readonly Timer _timer;
        private int _ticks;

        private string _folder;
        private WadResolver[] _results;
        private bool _showAllWads;
        private bool _showRelativePaths;
        private bool _isBusy;

        private readonly BackgroundWorker _worker;

        public WindowMainViewModel()
        {
            _folder = String.Empty;
            _results = new WadResolver[ 0 ];

            _ticks = 0;
            _timer = new Timer
                     {
                         Interval = 1000.0D ,
                         Enabled = true
                     };
            _timer.Elapsed += OnTimerElapsed;

            _worker = new BackgroundWorker
                      {
                          //WorkerReportsProgress = true ,
                          WorkerSupportsCancellation = true
                      };
            _worker.DoWork += OnWorkerDoWork;
            //_worker.ProgressChanged += OnWorkerProgressChanged;
            _worker.RunWorkerCompleted += OnWorkerRunWorkerCompleted;
            Application.Current.Exit += ( sender , e ) => _worker.Dispose();
        }

        public static IValueConverter BoolToVisibilityConverter
        {
            get
            {
                if ( _converter == null )
                {
                    _converter = new BoolToVisibilityConverterClass( Visibility.Collapsed );
                }

                return _converter;
            }
        }

        public string Folder
        {
            get
            {
                return _folder;
            }
            set
            {
                _folder = value ?? String.Empty;
                RaisePropertyChanged( "Folder" );
                RaisePropertyChanged( "GameImage" );
            }
        }

        public WadResolver[] Results
        {
            get
            {
                return ProcessResults( _results );
            }
            set
            {
                _results = value ?? new WadResolver[ 0 ];
                RaisePropertyChanged( "Results" );
            }
        }

        public bool ShowAllWads
        {
            get
            {
                return _showAllWads;
            }
            set
            {
                _showAllWads = value;
                RaisePropertyChanged( "Results" );
            }
        }

        public bool ShowRelativePaths
        {
            get
            {
                return _showRelativePaths;
            }
            set
            {
                _showRelativePaths = value;
                RaisePropertyChanged( "Results" );
            }
        }

        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            private set
            {
                _isBusy = value;
                RaisePropertyChanged( "IsBusy" );
            }
        }

        public string GameImage
        {
            get
            {
                string image = "steam.png";

                if ( !String.IsNullOrEmpty( _folder ) )
                {
                    if ( _folder.Contains( @"\bshift" ) )
                    {
                        image = "bs.png";
                    }
                    else if ( _folder.Contains( @"\cstrike" ) )
                    {
                        image = "cs.png";
                    }
                    else if ( _folder.Contains( @"\gearbox" ) )
                    {
                        image = "of.png";
                    }
                    else if ( _folder.Contains( @"\tfc" ) )
                    {
                        image = "tfc.png";
                    }
                    else if ( _folder.Contains( @"\valve" ) )
                    {
                        image = "hl.png";
                    }
                    else
                    {
                        image = ( new Random() ).Next( 100 ) % 2 == 0 ? "hl2.png" : "hldm.png";
                    }
                }

                return String.Format( _IMAGESOURCEFORMAT , image );
            }
        }

        public string WindowIcon
        {
            get
            {
                return "/Resources/Games/" + _allIcons[ _rnd.Next( _allIcons.Length ) ];
            }
        }

        public string WindowTitle
        {
            get
            {
                return _APPTITLE + '[' + FormatBinary( _ticks , _ZEROCHAR , _ONECHAR ) + ']';
            }
        }

        private static string FormatBinary( int number , char zeroChar , char oneChar )
        {
            return new String( ( new BitArray( new[] { number } ) ).Cast<bool>().Reverse().Select( b => b ? oneChar : zeroChar ).ToArray() );
        }

        private WadResolver[] ProcessResults( WadResolver[] results )
        {
            GC.Collect();
            GC.WaitForFullGCComplete();
            if ( _showAllWads )
            {
                var resList = new List<string>();

                foreach ( var result in results )
                {
                    foreach ( var wad in result.Wads )
                    {
                        if ( resList.IndexOf( wad ) < 0 )
                        {
                            resList.Add( wad );
                        }
                    }
                }

                resList.Sort();
                return new[] { new WadResolver( "<ALL>" , resList ) };
            }

            if ( _showRelativePaths )
            {
                return
                    results.Select(
                            wr =>
                                new WadResolver(
                                    wr.BspName.Replace( Folder + Path.DirectorySeparatorChar , String.Empty ) ,
                                    wr.Wads )
                        ).ToArray();
            }

            return results;
        }

        public void GetData()
        {
            if ( !_worker.IsBusy && !String.IsNullOrEmpty( _folder ) )
            {
                IsBusy = true;
                _worker.RunWorkerAsync();
            }
        }

        private void RaisePropertyChanged( string property )
        {
            if ( PropertyChanged != null )
            {
                PropertyChanged( this , new PropertyChangedEventArgs( property ) );
            }
        }

        private void OnTimerElapsed( object sender , ElapsedEventArgs e )
        {
            _ticks++;
            RaisePropertyChanged( "WindowIcon" );
            RaisePropertyChanged( "WindowTitle" );
        }

        private void OnWorkerDoWork( object sender , DoWorkEventArgs e )
        {
            e.Result = WadResolver.ScanDirectory( _folder , true );
        }

        //private void OnWorkerProgressChanged( object sender , ProgressChangedEventArgs e )
        //{

        //}

        private void OnWorkerRunWorkerCompleted( object sender , RunWorkerCompletedEventArgs e )
        {
            if ( e.Error == null && !e.Cancelled )
            {
                Results = e.Result as WadResolver[];
            }
            IsBusy = false;
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }
}
