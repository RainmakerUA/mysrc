﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;

namespace BspWadResolver
{
    internal sealed class WadResolver
    {
        public class WadResolveException : Exception
        {
            public WadResolveException()
            {
                // Do nothing. Implicitly call base class constructor.
            }

            public WadResolveException( string message )
                : base( message )
            {

            }

            public WadResolveException( string message , Exception innerException )
                : base( message , innerException )
            {

            }

            public WadResolveException( SerializationInfo info , StreamingContext context )
                : base( info , context )
            {

            }
        }

        private const string _BSP = "*.bsp";
        private const string _CSTRIKE = "cstrike";
        private const string _MAPS = "maps";

        private static Regex _wadParser;
        private string _bspName;
        private List<string> _wads;

        public string BspName
        {
            get
            {
                return _bspName;
            }
        }

        public ReadOnlyCollection<string> Wads
        {
            get
            {
                return _wads.AsReadOnly();
            }
        }

        private WadResolver()
        {
            if ( _wadParser == null )
            {
                _wadParser = new Regex( "\x0A\"wad\"\x20\"(?'wads'[^\"]*)\"" , RegexOptions.Compiled | RegexOptions.IgnoreCase );
            }
        }

        public WadResolver( string filename )
            : this()
        {
            Load( filename );
        }

        public WadResolver( string bspName , IEnumerable<string> wads )
            : this()
        {
            _bspName = bspName;
            _wads = new List<string>( wads );
        }

        private void Load( string filename )
        {
            string contents;

            if ( String.IsNullOrEmpty( filename ) )
            {
                throw new WadResolveException( "Filename cannot be null or empty string!" );
            }

            try
            {
                contents = File.ReadAllText( filename , Encoding.GetEncoding( 1252 ) );
            }
            catch ( IOException exception )
            {
                throw new WadResolveException( "Cannot read file " + filename , exception );
            }

            _bspName = filename;
            _wads = new List<string>();

            foreach ( Match m in _wadParser.Matches( contents ) )
            {
                _wads.AddRange(
                            from wad in m.Groups[ "wads" ].Value.Split( new[] { ';' } )
                            where !String.IsNullOrEmpty( wad )
                            select wad.Substring( wad.LastIndexOfAny( new[] { '/' , '\\' } ) + 1 )
                        );
            }
        }

        //public static WadResolver[] ScanDirectory( string path )
        //{
        //    return ScanDirectory( path , false );
        //}

        public static WadResolver[] ScanDirectory( string path , bool smartScan )
        {
            WadResolver[] result;

            try
            {
                string[] bsps = Directory.GetFiles( path , _BSP );
                if ( bsps.Length == 0 && smartScan )
                {
                    bool hasMaps = Array.IndexOf( Directory.GetDirectories( path ) , Path.Combine( path , _MAPS ) ) >= 0;
                    result = ScanDirectory( Path.Combine( path , hasMaps ? _MAPS : _CSTRIKE ) , !hasMaps );
                }
                else
                {
                    result = bsps.Select( file => new WadResolver( file ) ).ToArray();
                }
            }
            catch ( IOException exc )
            {
                throw new WadResolveException( String.Format( "Error processing directory '{0}'" , path ) , exc );
            }

            return result;
        }
    }
}
