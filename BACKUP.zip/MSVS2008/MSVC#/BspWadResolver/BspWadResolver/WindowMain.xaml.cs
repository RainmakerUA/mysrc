﻿using System;
using System.Windows;
using WinForms = System.Windows.Forms;

namespace BspWadResolver
{

    public partial class WindowMain : Window
    {
        private readonly WindowMainViewModel _viewModel;

        public WindowMain()
        {
            InitializeComponent();
            _viewModel = new WindowMainViewModel();
            DataContext = _viewModel;
        }

        private void OnDirectorySelect( object sender , RoutedEventArgs e )
        {
            var dlg = new WinForms.FolderBrowserDialog
                      {
                          SelectedPath = @"E:\Games\Half-Life" /*Environment.GetFolderPath( Environment.SpecialFolder.Desktop )*/ ,

                          Description = "Select a folder to scan" ,
                          ShowNewFolderButton = true
                      };
            if ( dlg.ShowDialog() == WinForms.DialogResult.OK )
            {
                _viewModel.Folder = dlg.SelectedPath;
            }
        }

        private void OnScan( object sender , RoutedEventArgs e )
        {
            try
            {
                _viewModel.GetData();
            }
            catch ( WadResolver.WadResolveException exc )
            {
                MessageBox.Show( String.Format( "Error processing folder:\n{0}\n{1}" , _viewModel.Folder , exc.Message ) );
            }
        }
    }
}
