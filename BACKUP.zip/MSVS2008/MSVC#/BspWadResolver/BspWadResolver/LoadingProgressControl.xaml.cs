﻿using System.Windows.Controls;

namespace BspWadResolver
{
    /// <summary>
    /// Interaction logic for LoadingProgressControl.xaml
    /// </summary>
    public partial class LoadingProgressControl : UserControl
    {
        public LoadingProgressControl()
        {
            InitializeComponent();
        }
    }
}
