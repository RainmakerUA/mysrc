﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.IO.Compression;
using System.Xml.Linq;

using RefleXML;
using System.Xml;

namespace XmlZ
{
    class TestClass
    {
        public int IntProp
        { get; set; }
        public string StrProp
        { get; set; }
        public DateTime DTProp
        { get; set; }
    }

    class Program
    {
        static void Main( string[] args )
        {
            var tc = new TestClass
                {
                    IntProp = 19 ,
                    StrProp = "String-bring-bring" ,
                    DTProp = DateTime.Now
                };
            XElement xr = new XElement( "testroot" );
            XDocument xdoc = new XDocument(
                    new XDeclaration( "1.0" , "utf-8" , "yes" ) ,
                    xr
                );
            xr.Add( tc.SaveXML( "test" ) );
            FileStream fstr = new FileStream( "test.xml.gz" , FileMode.Create );
            GZipStream gzstr = new GZipStream( fstr , CompressionMode.Compress );
            byte[] bt = Encoding.UTF8.GetBytes( xdoc.ToString() );
            gzstr.Write( bt , 0 , bt.Length );
            gzstr.Close();
        }
    }
}
