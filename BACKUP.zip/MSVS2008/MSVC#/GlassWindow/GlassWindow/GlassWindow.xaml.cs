﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RMDevel.GlassWindow
{
    /// <summary>
    /// Interaction logic for GlassWindow.xaml
    /// </summary>
    public partial class GlassWindow : Window
    {
        private readonly Thickness GLASSTHICKNESS = new Thickness( -1 );

        public GlassWindow()
        {
            if ( Environment.OSVersion.Version.Major < 6 )
            {
                MessageBox.Show( "Run me on Vista or newer OS!" , "Error" , MessageBoxButton.OK , MessageBoxImage.Error );
                Close();
            }
            InitializeComponent();
            DragHelper.RegisterWindowMoving( this );
        }

        protected override void OnSourceInitialized( EventArgs e )
        {
            base.OnSourceInitialized( e );
            GlassHelper.ExtendGlass( this , GLASSTHICKNESS );
        }

        private IntPtr WndProc( IntPtr hwnd , int msg , IntPtr wParam , IntPtr lParam , ref bool handled )
        {
            if ( msg == GlassHelper.WM_DWMCOMPOSITIONCHANGED )
            {
                GlassHelper.ExtendGlass( this , GLASSTHICKNESS );
                handled = true;
            }
            return IntPtr.Zero;
        }

        private void buttonClick_Click( object sender , RoutedEventArgs e )
        {
            Random rnd = new Random();
            Ellipse el = new Ellipse
            {
                Width = 32 ,
                Height = 32 ,
                Stroke = Brushes.Violet ,
                Fill = Brushes.SteelBlue ,
                Opacity = 0.5
            };

            Canvas.SetLeft( el , rnd.NextDouble() * canvas1.ActualWidth );
            Canvas.SetTop( el , rnd.NextDouble() * canvas1.ActualHeight );
            canvas1.Children.Add( el );
        }
    }
}
