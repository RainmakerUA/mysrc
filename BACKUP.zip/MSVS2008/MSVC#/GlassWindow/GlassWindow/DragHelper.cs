﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;

namespace RMDevel.GlassWindow
{
    internal static class DragHelper
    {
        private const int WM_NCLBUTTONDOWN = 0xA1;
        private const int HT_CAPTION = 0x2;

        private static Dictionary<Window , Func<MouseButtonEventArgs , bool>> callbacks = new Dictionary<Window , Func<MouseButtonEventArgs , bool>>();

        [DllImport( "User32.dll" )]
        private static extern bool ReleaseCapture();

        [DllImport( "user32.dll" , CharSet = CharSet.Auto )]
        private static extern int SendMessage( IntPtr hWnd , int Msg , IntPtr wParam , IntPtr lParam );

        private static void OnWindowMouseDown( object sender , MouseButtonEventArgs e )
        {
            Window win = sender as Window;
            var callback = callbacks[ win ];
            if ( callback != null && callback( e ) )
            {
                ReleaseCapture();
                SendMessage( ( new WindowInteropHelper( win ) ).Handle , WM_NCLBUTTONDOWN , new IntPtr( HT_CAPTION ) , IntPtr.Zero );
            }
        }

        public static void RegisterWindowMoving( Window win , Func<MouseButtonEventArgs , bool> testCallback )
        {
            if ( !callbacks.ContainsKey( win ) )
            {
                callbacks.Add( win , testCallback );
                win.MouseDown += new MouseButtonEventHandler( OnWindowMouseDown );
            }
        }

        public static void RegisterWindowMoving( Window win )
        {
            RegisterWindowMoving( win , e => e.ChangedButton == MouseButton.Left && e.Source == win );
        }

        public static void UnregisterWindowMoving( Window win )
        {
            if ( callbacks.ContainsKey( win ) )
            {
                callbacks.Remove( win );
                win.MouseDown -= new MouseButtonEventHandler( OnWindowMouseDown );
            }
        }
    }
}
