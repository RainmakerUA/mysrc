using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;

namespace RMDevel.GlassWindow
{
    internal class GlassHelper
    {
        public struct MARGINS
        {
            public MARGINS( Thickness t )
            {
                Left = (int) t.Left;
                Right = (int) t.Right;
                Top = (int) t.Top;
                Bottom = (int) t.Bottom;
            }
            public int Left;
            public int Right;
            public int Top;
            public int Bottom;
        }

        [DllImport( "dwmapi.dll" , PreserveSig = false )]
        private static extern int DwmExtendFrameIntoClientArea( IntPtr hwnd , ref MARGINS margins );

        [DllImport( "dwmapi.dll" , PreserveSig = false )]
        private static extern bool DwmIsCompositionEnabled();

        public const int WM_DWMCOMPOSITIONCHANGED = 0x031E;

/*
         void ActivateGlass()
        {
            PresentationSource p = PresentationSource.FromVisual(this);
            HwndSource s_hwndSource = p as HwndSource;

            if (s_hwndSource != null)
            {
                s_hwndSource.CompositionTarget.BackgroundColor = Color.FromArgb(0, 0, 0, 0);
                handle = s_hwndSource.Handle;
            }


            SafeNativeMethods.RECT r = new SafeNativeMethods.RECT();

            UnsafeNativeMethods.GetClientRect(handle, ref r);

            IntPtr hrgn = UnsafeNativeMethods.CreateRectRgn(0, 0, 1, 1);

            SafeNativeMethods.DWM_BLURBEHIND bb = new SafeNativeMethods.DWM_BLURBEHIND();
            bb.dwFlags = SafeNativeMethods.DwmBlurBehindDwFlags.DWM_BB_ENABLE | SafeNativeMethods.DwmBlurBehindDwFlags.DWM_BB_BLURREGION;
            bb.fEnable = true;
            bb.hRgnBlur = hrgn;

            UnsafeNativeMethods.DwmEnableBlurBehindWindow(handle, ref bb);

            SafeNativeMethods.MARGINS mar = new SafeNativeMethods.MARGINS();

            mar.cyTopHeight = 37;

            UnsafeNativeMethods.DwmExtendFrameIntoClientArea(handle, ref mar);

            //Need to make the Window size dirty.
            this.WindowState = WindowState.Minimized;
            this.WindowState = WindowState.Normal;
        }
*/
        /// <summary>
        /// Extends the glass area into the client area of the window
        /// </summary>
        /// <param name="window"></param>
        /// <param name="top"></param>
        public static void ExtendGlass( Window window , Thickness thikness )
        {
            try
            {
                bool isGlassEnabled = DwmIsCompositionEnabled();
                if ( Environment.OSVersion.Version.Major > 5 && isGlassEnabled )
                {
                    // Get the window handle
                    WindowInteropHelper helper = new WindowInteropHelper( window );
                    HwndSource mainWindowSrc = (HwndSource) HwndSource.FromHwnd( helper.Handle );
                    mainWindowSrc.CompositionTarget.BackgroundColor = Colors.Transparent;


                    // Set Margins
                    MARGINS margins = new MARGINS( thikness );

                    window.Background = Brushes.Transparent;

                    int hr = DwmExtendFrameIntoClientArea( mainWindowSrc.Handle , ref margins );
                }
                else
                {
                    window.Background = SystemColors.WindowBrush;
                }
            }
            catch ( DllNotFoundException )
            {

            }
        }
    }
}
