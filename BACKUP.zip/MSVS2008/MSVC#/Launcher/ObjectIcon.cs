﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Runtime.InteropServices;
using System.ComponentModel;

namespace Launcher
{
    public class IconData
    {
        public Icon Icon { get; set; }
        public string DisplayName { get; set; }
        public Bitmap Bitmap
        {
            get
            {
                return Bitmap.FromHicon( Icon.Handle );
            }
        }
    }
    
    public class ObjectIcon : PictureBox
    {
        private IconData data;
        private string objectPath;

        public string ObjectPath
        {
            get
            {
                return objectPath;
            }
            set
            {
                objectPath = value;
                UpdateIconData();
            }
        }

        public string DisplayName
        {
            get;
            private set;
        }

        public ObjectIcon()
        {
            SetDefaultData();
        }

        public ObjectIcon( string objectPath )
            : this()
        {
            ObjectPath = objectPath;
        }

        private void UpdateIconData()
        {
            data = ExtractAssociatedIcon( ObjectPath );
            if ( data != null )
            {
                Image = data.Bitmap;
                DisplayName = data.DisplayName;
            }
            else
            {
                SetDefaultData();
            }
        }

        private void SetDefaultData()
        {
            Image = Properties.Resources.icona_rocket_dark;
            DisplayName = "<no object>";
        }

        internal static IconData ExtractAssociatedIcon( string filename )
        {
            PInvoke.SHFILEINFO fi;

            fi = new PInvoke.SHFILEINFO();
            if ( PInvoke.SHGetFileInfo( filename , 0 , ref fi , (uint) Marshal.SizeOf( fi ) , PInvoke.SHGFI.SHGFI_ICON | PInvoke.SHGFI.SHGFI_DISPLAYNAME ) == 1 )
            {
                return new IconData { Icon = Icon.FromHandle( fi.hIcon ) , DisplayName = fi.szDisplayName };
            }
            else
            {
                return null;
            }
        }
    }
}
