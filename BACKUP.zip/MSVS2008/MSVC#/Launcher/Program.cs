﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Launcher
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault( false );
            FormMain formMain = new FormMain();
            formMain.FormClosed += delegate( object sender , FormClosedEventArgs e )
            {
                if ( ( new List<CloseReason> { CloseReason.UserClosing , CloseReason.None } ).IndexOf( e.CloseReason ) > -1 )
                {
                    Application.Exit();
                }
            };
            Application.Run();
        }
    }
}
