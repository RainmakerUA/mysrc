﻿namespace Launcher
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose();
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager( typeof( FormMain ) );
            this.notifyIconMain = new System.Windows.Forms.NotifyIcon( this.components );
            this.panelIconList = new System.Windows.Forms.Panel();
            this.objectIcon1 = new Launcher.ObjectIcon();
            this.panelIconList.SuspendLayout();
            ( (System.ComponentModel.ISupportInitialize) ( this.objectIcon1 ) ).BeginInit();
            this.SuspendLayout();
            // 
            // notifyIconMain
            // 
            resources.ApplyResources( this.notifyIconMain , "notifyIconMain" );
            this.notifyIconMain.MouseClick += new System.Windows.Forms.MouseEventHandler( this.notifyIconMain_MouseClick );
            // 
            // panelIconList
            // 
            this.panelIconList.BackColor = System.Drawing.Color.Transparent;
            this.panelIconList.Controls.Add( this.objectIcon1 );
            resources.ApplyResources( this.panelIconList , "panelIconList" );
            this.panelIconList.Name = "panelIconList";
            // 
            // objectIcon1
            // 
            resources.ApplyResources( this.objectIcon1 , "objectIcon1" );
            this.objectIcon1.Name = "objectIcon1";
            this.objectIcon1.ObjectPath = "C:\\Windows";
            this.objectIcon1.TabStop = false;
            // 
            // FormMain
            // 
            resources.ApplyResources( this , "$this" );
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Launcher.Properties.Resources.BG;
            this.Controls.Add( this.panelIconList );
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "FormMain";
            this.ShowInTaskbar = false;
            this.TopMost = true;
            this.panelIconList.ResumeLayout( false );
            ( (System.ComponentModel.ISupportInitialize) ( this.objectIcon1 ) ).EndInit();
            this.ResumeLayout( false );

        }

        #endregion

        private System.Windows.Forms.NotifyIcon notifyIconMain;
        private System.Windows.Forms.Panel panelIconList;
        private ObjectIcon objectIcon1;

    }
}

