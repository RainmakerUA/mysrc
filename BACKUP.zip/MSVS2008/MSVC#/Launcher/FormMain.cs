﻿using System;
using System.Windows.Forms;
using System.Drawing;

namespace Launcher
{
    public partial class FormMain : Form
    {
        private const double MAX_OPACITY = 0.8;

        private Timer timerShowHide;
        private Timer timerShowing;

        
        public FormMain()
        {
            InitializeComponent();
            Hide();
            AdjustPosition();
            SetRegion();
            panelIconList.HorizontalScroll.Enabled = false;
            panelIconList.HorizontalScroll.Visible = true;

            timerShowHide = new Timer()
            {
                Interval = 100 ,
                Enabled = false
            };
            timerShowing = new Timer()
            {
                Interval = 10000 ,
                Enabled = false
            };
        }

        protected override void WndProc( ref Message m )
        {
            base.WndProc( ref m );
            if ( m.Msg == PInvoke.WM.WM_DISPLAYCHANGE || m.Msg == PInvoke.WM.WM_SETTINGCHANGE )
            {
                AdjustPosition();
            }
        }

        private void AdjustPosition()
        {
            Left = SystemInformation.WorkingArea.Right - Width;
            Top = SystemInformation.WorkingArea.Bottom - Height;
        }

        private void SetRegion()
        {
            IntPtr hRgn = PInvoke.CreateRoundRectRgn( 2 , 2 , Width - 2 , Height - 2 , 15 , 15 );
            int res = PInvoke.SetWindowRgn( Handle , hRgn , true );
        }

        public void ShowPopup()
        {
            EventHandler onTick = null;

            if ( timerShowHide.Enabled )
            {
                return;
            }

            onTick = delegate( object sender , EventArgs e )
            {
                Opacity += 0.1;
                if ( Opacity >= MAX_OPACITY || !Visible )
                {
                    timerShowHide.Stop();
                    timerShowHide.Tick -= onTick;
                }
            };

            Opacity = 0;
            Show();

            timerShowHide.Tick += onTick;
            timerShowHide.Start();
        }

        public void HidePopup( bool close)
        {
            EventHandler onTick = null;

            if ( timerShowHide.Enabled )
            {
                return;
            }

            onTick = delegate( object sender , EventArgs e )
            {
                Opacity -= 0.1;
                if ( Opacity <= 0 || !Visible )
                {
                    Opacity = 0;
                    Hide();
                    timerShowHide.Stop();
                    timerShowHide.Tick -= onTick;
                    if ( close )
                    {
                        Close();
                    }
                }
            };
            Opacity = MAX_OPACITY;
            Show();
            timerShowHide.Tick += onTick;
            timerShowHide.Start();
        }

        private void HidePopup()
        {
            HidePopup( false );
        }

        private void notifyIconMain_MouseClick( object sender , MouseEventArgs e )
        {
            switch ( e.Button )
            {
                case MouseButtons.Left:
                    if ( Visible )
                    {
                        HidePopup();
                    }
                    else
                    {
                        ShowPopup();

                    }
                    break;

                case MouseButtons.Right:
                    break;

                case MouseButtons.Middle:
                    if ( Visible )
                    {
                        HidePopup( true );
                    }
                    else
                    {
                        Close();
                    }
                    break;

                default:
                    break;
            }
        }
    }
}
