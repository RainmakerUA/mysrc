﻿using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace ProHelper
{
    public class MyLinkLabel : LinkLabel
    {
        /// <summary>
        /// Link URL and text in label
        /// </summary>
        [PropertyTab( "Appearance" ) , Description( "Link URL and text in label" )]
        public new string Link
        {
            get
            {
                return base.Text;
            }

            set
            {
                base.Text = value;
            }
        }

        #region Hide props

        [Browsable( false )]
        public new string LinkArea { get; set; }

        [Browsable( false )]
        public new string Text { get; set; }

        [Browsable( false )]
        public new string Image { get; set; }

        [Browsable( false )]
        public new string ImageAlign { get; set; }

        [Browsable( false )]
        public new string ImageIndex { get; set; }

        [Browsable( false )]
        public new string ImageKey { get; set; }

        [Browsable( false )]
        public new string ImageList { get; set; }

        [Browsable( false )]
        public new string TextAlign { get; set; }

        #endregion

        public MyLinkLabel()
        {
            AutoSize = false;
            base.TextAlign = ContentAlignment.MiddleCenter;
        }

        protected override void OnMouseClick( MouseEventArgs e )
        {
            switch ( e.Button )
            {
                case MouseButtons.Left:
                    Process.Start( Link );
                    break;

                case MouseButtons.Right:
                    Clipboard.SetText( Link );
                    break;

                default:
                    // Do nothing.
                    break;
            }

            base.OnMouseClick( e );
        }
    }
}
