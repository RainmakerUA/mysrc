﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Web;
using System.Text;

namespace ProHelper
{
    public partial class FMain : Form
    {
        private const string LynxDAT = "lynx.dat";
        private bool closing = false;
        private bool ctor = true;

        public FMain()
        {
            InitializeComponent();
            CreateLinks();
            tabCtrlMain.SelectedIndex = 1;
            ctor = false;
        }

        private void LameProtect()
        {
            DialogResult[] res = { DialogResult.Abort, DialogResult.Retry, DialogResult.Ignore };
            int num = (new Random(Environment.TickCount)).Next(res.Length);
            string q = String.Format("Error: Invalid \"{0}\". Program terminated", res[num]);
            if (res[num] != MessageBox.Show(q, Text, MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error))
                notifyIconMain_BalloonTipClicked(this, EventArgs.Empty);
        }

        private void CreateLinks()
        {
            string[] links = File.ReadAllLines(LynxDAT);
            int i = 0;

            foreach (string s in links)
            {
                if (s != null && s != String.Empty && s[0] != ';')
                {
                    MyLinkLabel mll = new MyLinkLabel
                    {
                        AutoSize = false,
                        Link = s,
                        Location = new Point(5, 5 + i * 20),
                        Size = new Size(270, 18),
                        BorderStyle = BorderStyle.Fixed3D
                    };
                    i++;
                    tabPgLinks.Controls.Add(mll);
                }
            }
        }

        private void btnRes2Clip_Click(object sender, EventArgs e)
        {
            if (txtBoxRes.Text != null && txtBoxRes.Text != String.Empty)
                Clipboard.SetText(txtBoxRes.Text);
        }

        private void btnUrlDec_Click(object sender, EventArgs e)
        {
            try
            {
                txtBoxRes.Text = HttpUtility.UrlDecode(txtBoxSrc.Text);
            }
            catch (Exception exc)
            {
                txtBoxRes.Text = exc.Message;
            }
        }

        private void btnBase64Dec_Click(object sender, EventArgs e)
        {
            try
            {
                txtBoxRes.Text = Encoding.UTF8.GetString(Convert.FromBase64String(txtBoxSrc.Text));
            }
            catch (Exception exc)
            {
                txtBoxRes.Text = exc.Message;
            }
        }

        private void FMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = !closing;
            Hide();
        }

        private void notifyIconMain_BalloonTipClicked(object sender, EventArgs e)
        {
            closing = true;
            Close();
        }

        private void notifyIconMain_MouseClick(object sender, MouseEventArgs e)
        {
            switch (e.Button)
            {
                case MouseButtons.Left:
                    Visible = !Visible;
                    break;
                case MouseButtons.Right:
                    notifyIconMain.ShowBalloonTip(1000);
                    break;
                case MouseButtons.Middle:
                    closing = true;
                    Close();
                    break;
            }
        }

        private void tabCtrlMain_Selected(object sender, TabControlEventArgs e)
        {
            if (e.Action == TabControlAction.Selected && (sender as TabControl).SelectedIndex == 0 && !ctor)
            {
                closing = true;
                Close();
            }
        }

        private void FMain_Shown(object sender, EventArgs e)
        {
            Visible = false;
            LameProtect();
        }
    }
}
