﻿namespace ProHelper
{
    partial class FMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FMain));
            this.tabCtrlMain = new System.Windows.Forms.TabControl();
            this.tabPgClose = new System.Windows.Forms.TabPage();
            this.tabPgLinks = new System.Windows.Forms.TabPage();
            this.tabPgDecode = new System.Windows.Forms.TabPage();
            this.btnRes2Clip = new System.Windows.Forms.Button();
            this.txtBoxRes = new System.Windows.Forms.TextBox();
            this.btnUrlDec = new System.Windows.Forms.Button();
            this.btnBase64Dec = new System.Windows.Forms.Button();
            this.txtBoxSrc = new System.Windows.Forms.TextBox();
            this.notifyIconMain = new System.Windows.Forms.NotifyIcon(this.components);
            this.tabCtrlMain.SuspendLayout();
            this.tabPgDecode.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabCtrlMain
            // 
            this.tabCtrlMain.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabCtrlMain.Controls.Add(this.tabPgClose);
            this.tabCtrlMain.Controls.Add(this.tabPgLinks);
            this.tabCtrlMain.Controls.Add(this.tabPgDecode);
            this.tabCtrlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabCtrlMain.HotTrack = true;
            this.tabCtrlMain.Location = new System.Drawing.Point(0, 0);
            this.tabCtrlMain.Name = "tabCtrlMain";
            this.tabCtrlMain.SelectedIndex = 0;
            this.tabCtrlMain.Size = new System.Drawing.Size(304, 271);
            this.tabCtrlMain.TabIndex = 0;
            this.tabCtrlMain.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabCtrlMain_Selected);
            // 
            // tabPgClose
            // 
            this.tabPgClose.Location = new System.Drawing.Point(4, 25);
            this.tabPgClose.Name = "tabPgClose";
            this.tabPgClose.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgClose.Size = new System.Drawing.Size(296, 242);
            this.tabPgClose.TabIndex = 3;
            this.tabPgClose.Text = "_[X]_";
            this.tabPgClose.UseVisualStyleBackColor = true;
            // 
            // tabPgLinks
            // 
            this.tabPgLinks.AutoScroll = true;
            this.tabPgLinks.Location = new System.Drawing.Point(4, 25);
            this.tabPgLinks.Margin = new System.Windows.Forms.Padding(0);
            this.tabPgLinks.Name = "tabPgLinks";
            this.tabPgLinks.Size = new System.Drawing.Size(296, 242);
            this.tabPgLinks.TabIndex = 4;
            this.tabPgLinks.Text = "Links";
            this.tabPgLinks.UseVisualStyleBackColor = true;
            // 
            // tabPgDecode
            // 
            this.tabPgDecode.Controls.Add(this.btnRes2Clip);
            this.tabPgDecode.Controls.Add(this.txtBoxRes);
            this.tabPgDecode.Controls.Add(this.btnUrlDec);
            this.tabPgDecode.Controls.Add(this.btnBase64Dec);
            this.tabPgDecode.Controls.Add(this.txtBoxSrc);
            this.tabPgDecode.Location = new System.Drawing.Point(4, 25);
            this.tabPgDecode.Name = "tabPgDecode";
            this.tabPgDecode.Padding = new System.Windows.Forms.Padding(3);
            this.tabPgDecode.Size = new System.Drawing.Size(296, 242);
            this.tabPgDecode.TabIndex = 5;
            this.tabPgDecode.Text = "Decoding";
            this.tabPgDecode.UseVisualStyleBackColor = true;
            // 
            // btnRes2Clip
            // 
            this.btnRes2Clip.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnRes2Clip.Location = new System.Drawing.Point(8, 110);
            this.btnRes2Clip.Name = "btnRes2Clip";
            this.btnRes2Clip.Size = new System.Drawing.Size(280, 46);
            this.btnRes2Clip.TabIndex = 4;
            this.btnRes2Clip.Text = "Copy to clipboard";
            this.btnRes2Clip.UseVisualStyleBackColor = true;
            this.btnRes2Clip.Click += new System.EventHandler(this.btnRes2Clip_Click);
            // 
            // txtBoxRes
            // 
            this.txtBoxRes.Location = new System.Drawing.Point(8, 84);
            this.txtBoxRes.Name = "txtBoxRes";
            this.txtBoxRes.ReadOnly = true;
            this.txtBoxRes.Size = new System.Drawing.Size(280, 20);
            this.txtBoxRes.TabIndex = 3;
            // 
            // btnUrlDec
            // 
            this.btnUrlDec.Font = new System.Drawing.Font("Arial Unicode MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnUrlDec.Location = new System.Drawing.Point(157, 32);
            this.btnUrlDec.Name = "btnUrlDec";
            this.btnUrlDec.Size = new System.Drawing.Size(131, 28);
            this.btnUrlDec.TabIndex = 2;
            this.btnUrlDec.Text = "⇩ URL decode";
            this.btnUrlDec.UseVisualStyleBackColor = true;
            this.btnUrlDec.Click += new System.EventHandler(this.btnUrlDec_Click);
            // 
            // btnBase64Dec
            // 
            this.btnBase64Dec.Font = new System.Drawing.Font("Arial Unicode MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnBase64Dec.Location = new System.Drawing.Point(8, 32);
            this.btnBase64Dec.Name = "btnBase64Dec";
            this.btnBase64Dec.Size = new System.Drawing.Size(131, 28);
            this.btnBase64Dec.TabIndex = 1;
            this.btnBase64Dec.Text = "Base64 decode ⇩";
            this.btnBase64Dec.UseVisualStyleBackColor = true;
            this.btnBase64Dec.Click += new System.EventHandler(this.btnBase64Dec_Click);
            // 
            // txtBoxSrc
            // 
            this.txtBoxSrc.Location = new System.Drawing.Point(8, 6);
            this.txtBoxSrc.Name = "txtBoxSrc";
            this.txtBoxSrc.Size = new System.Drawing.Size(280, 20);
            this.txtBoxSrc.TabIndex = 0;
            // 
            // notifyIconMain
            // 
            this.notifyIconMain.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Error;
            this.notifyIconMain.BalloonTipText = "Click this tip to exit";
            this.notifyIconMain.BalloonTipTitle = "[RM®] ProHelper";
            this.notifyIconMain.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIconMain.Icon")));
            this.notifyIconMain.Text = "[RM®] ProHelper\r\nLeft - show\r\nRight - tip";
            this.notifyIconMain.Visible = true;
            this.notifyIconMain.BalloonTipClicked += new System.EventHandler(this.notifyIconMain_BalloonTipClicked);
            this.notifyIconMain.MouseClick += new System.Windows.Forms.MouseEventHandler(this.notifyIconMain_MouseClick);
            // 
            // FMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(304, 271);
            this.Controls.Add(this.tabCtrlMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "[RM®] ProHelper";
            this.TopMost = true;
            this.Shown += new System.EventHandler(this.FMain_Shown);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FMain_FormClosing);
            this.tabCtrlMain.ResumeLayout(false);
            this.tabPgDecode.ResumeLayout(false);
            this.tabPgDecode.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabCtrlMain;
        private System.Windows.Forms.NotifyIcon notifyIconMain;
        private System.Windows.Forms.TabPage tabPgClose;
        private System.Windows.Forms.TabPage tabPgLinks;
        private System.Windows.Forms.TabPage tabPgDecode;
        private System.Windows.Forms.Button btnRes2Clip;
        private System.Windows.Forms.TextBox txtBoxRes;
        private System.Windows.Forms.Button btnUrlDec;
        private System.Windows.Forms.Button btnBase64Dec;
        private System.Windows.Forms.TextBox txtBoxSrc;
    }
}

