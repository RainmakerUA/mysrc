﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BubbleSolver
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class WindowMain : Window
    {
        private struct Field
        {
            public int W;
            public int H;
            public int C;

            public int[ , ] F;
        }

        private const string INFOFMT = "Bubble @({0} , {1})/({2},{3}) :: {4}";

        private static readonly Color[] COLORS;

        private Field field;

        static WindowMain()
        {
            COLORS = new Color[]
            {
                Colors.Red,
                Colors.Yellow,
                Colors.Green,
                Colors.Pink,
                Colors.Blue,
                Colors.Black,
                Colors.DarkGray,
                Colors.Gray,
                Colors.Orange
            };
        }

        public WindowMain()
        {
            InitializeComponent();
        }

        private void FillField()
        {
            field.W = Convert.ToInt32( sliderWidth.Value );
            field.H = Convert.ToInt32( sliderHeight.Value );
            field.C = Convert.ToInt32( sliderColors.Value );
            Random rnd = new Random();

            field.F = new int[ field.W , field.H ];
            for ( int i = 0; i < field.W; i++ )
            {
                for ( int j = 0; j < field.H; j++ )
                {
                    field.F[ i , j ] = rnd.Next( 1 , field.C + 1 );
                }
            }
            DrawField();
        }

        private void DrawField()
        {
            double rw = canvasField.ActualWidth / field.W;
            double rh = canvasField.ActualHeight / field.H;
            double r = Math.Min( rw , rh );
            double x_off = ( canvasField.ActualWidth - r * field.W ) / 2;
            double y_off = ( canvasField.ActualHeight - r * field.H ) / 2;
            Func<int , int , Color , MouseEventHandler> EnterHandler = ( i , j , c ) =>
                {
                    return ( sender , e ) =>
                    {
                        Ellipse el = sender as Ellipse;
                        el.Stroke = new SolidColorBrush( Color.FromArgb( 0x40 , 0x40 , 0x40 , 0x40 ) );
                        labelInfo.Content = String.Format( INFOFMT , i , j , field.W - i , field.H - j , c );
                    };
                };
            Func<int , int , Color , MouseEventHandler> LeaveHandler = ( i , j , c ) =>
                {
                    return ( sender , e ) =>
                    {
                        Ellipse el = sender as Ellipse;
                        el.Stroke = Brushes.Transparent;
                        labelInfo.Content = String.Empty;
                    };
                };

            canvasField.Children.Clear();
            for ( int i = 0; i < field.W; i++ )
            {
                for ( int j = 0; j < field.H; j++ )
                {
                    double radius = r - 1;
                    Color color = COLORS[ field.F[ i , j ] - 1 ];
                    Color colorHL = Colors.White;
                    Point hlCenter = new Point( 0.3 , 0.3 );

                    Ellipse s = new Ellipse
                    {
                        Width = radius ,
                        Height = radius ,
                        Stroke = Brushes.Transparent ,
                        StrokeThickness = 1 ,
                        Fill = new RadialGradientBrush
                        {
                            Center = hlCenter ,
                            GradientOrigin = hlCenter ,
                            GradientStops = new GradientStopCollection
                            {
                                new GradientStop( color , 1 ) ,
                                new GradientStop( colorHL , 0 )
                            }
                        }
                    };
                    s.MouseEnter += EnterHandler( i , j , color );
                    s.MouseLeave += LeaveHandler( i , j , color );
                    canvasField.Children.Add( s );
                    Canvas.SetLeft( s , i * r + x_off );
                    Canvas.SetTop( s , j * r + y_off );
                }
            }
        }

        private void OnSliderValueChanged( object sender , RoutedPropertyChangedEventArgs<double> e )
        {
            Slider slider = sender as Slider;
            bool isWidth = slider == sliderWidth;

            if ( labelWidth != null && labelHeight != null )
            {
                ( isWidth ? labelWidth : labelHeight ).Content = String.Format( "{0}: {1}" , isWidth ? "Width" : "Height" , Convert.ToInt32( slider.Value ) );
            }
        }

        private void OnSliderColorsValueChanged( object sender , RoutedPropertyChangedEventArgs<double> e )
        {
            if ( labelColors != null )
            {
                labelColors.Content = Convert.ToInt32( ( sender as Slider ).Value );
            }
        }

        private void OnCheckBoxRandomChecked( object sender , RoutedEventArgs e )
        {
            if ( buttonManual != null )
            {
                buttonManual.IsEnabled = !checkBoxRandom.IsChecked.Value;
            }
        }

        private void OnButtonManualClick( object sender , RoutedEventArgs e )
        {
            MessageBox.Show( "Unimplemented! Use 'Random' instead!" , Title , MessageBoxButton.OK , MessageBoxImage.Exclamation );
            checkBoxRandom.IsChecked = true;
        }

        private void OnButtonExitClick( object sender , RoutedEventArgs e )
        {
            App.Current.Shutdown();
        }

        private void OnButtonGoClick( object sender , RoutedEventArgs e )
        {
            FillField();
        }
    }
}
