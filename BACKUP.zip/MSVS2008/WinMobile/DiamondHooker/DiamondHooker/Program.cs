﻿using System;
using System.Windows.Forms;
using RM.WinCE.DiamondHooker.Settings;
using System.Diagnostics;
using System.IO;
using OpenNETCF.Windows.Forms;

namespace RM.WinCE.DiamondHooker
{
    internal static class Program
    {
        public const string APPNAME = "[RM] DMND HOOKER";

        private static HKMessageWindow msgWnd;

        public static KeySettings KeySettings
        {
            get;
            private set;
        }


        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [MTAThread]
        private static void Main( string[] args )
        {
            KeySettings = KeySettings.Load();
            msgWnd = new HKMessageWindow { Text = APPNAME };
            HotKeys.RegisterHooks( msgWnd.Hwnd );

            ApplicationEx.Run();
        }
    }
}