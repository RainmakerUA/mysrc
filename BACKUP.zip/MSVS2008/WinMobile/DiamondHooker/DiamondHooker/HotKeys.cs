﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using RM.WinCE.DiamondHooker.Settings;
using Microsoft.WindowsCE.Forms;

namespace RM.WinCE.DiamondHooker
{
    internal static class HotKeys
    {
        public static void RegisterHooks( IntPtr hWnd )
        {
            DiamondHWKey hwkey;
            KeyModifiers mods;
            Dictionary<KeySettings.Key , KeyAction> settings;

            if ( Program.KeySettings != null && Program.KeySettings.Settings != null )
            {
                settings = Program.KeySettings.Settings;
                foreach ( var key in settings.Keys )
                {
                    switch ( key )
                    {
                        case KeySettings.Key.Back:
                            hwkey = DiamondHWKey.Backspace;
                            mods = KeyModifiers.Windows;
                            break;
                        /*
                    case KeySettings.SettingsKey.TakeCall:
                        break;

                    case KeySettings.SettingsKey.HangUpCall:
                        break;

                    case KeySettings.SettingsKey.VolumeDown:
                        break;

                    case KeySettings.SettingsKey.VolumeUp:
                        break;
                        */
                        default:
                            hwkey = DiamondHWKey.None;
                            mods = KeyModifiers.None;
                            break;
                    }
                    if ( hwkey != DiamondHWKey.None )
                    {
                        PInvoke.UnregisterFunc1( mods , hwkey );
                        PInvoke.RegisterHotKey( hWnd , (int) key , mods , hwkey );
                    }
                }
            }
        }

        public static void ProcessHotKeyMessage( ref Message m )
        {
            KeySettings.Key key;
            KeyAction action;

            key = (KeySettings.Key) m.WParam.ToInt32();
            action = Program.KeySettings.GetAction( key );

            if ( action != null )
            {
                ActionManager.PerformAction( action );
            }
        }
    }
}
