﻿using System;

namespace RM.WinCE.DiamondHooker
{
    /// <summary>
    /// Key modifiers.
    /// </summary>
    [Flags]
    internal enum KeyModifiers
    {
        None = 0 ,
        Alt = 1 ,
        Control = 2 ,
        Shift = 4 ,
        Windows = 8 ,
        ModKeyup = 0x1000
    }

    /// <summary>
    /// HW Keys from Touch Diamond.
    /// </summary>
    internal enum DiamondHWKey
    {
        /// <summary>
        /// Empty key.
        /// </summary>
        None = 0 ,

        /// <summary>
        /// Back key (used with KeyModifiers.Windows).
        /// </summary>
        Backspace = 0x5c ,

        /// <summary>
        /// Back key too (used with KeyModifiers.Windows).
        /// </summary>
        Backspace2 = 0x75 ,

        /// <summary>
        /// Green phone button.
        /// </summary>
        TakeCall = 0x72 ,
        
        /// <summary>
        /// Red phone button.
        /// </summary>
        HangUpCall = 0x73 ,

        /// <summary>
        /// Volume up button.
        /// </summary>
        VolumeUp = 0x75 ,

        /// <summary>
        /// Volume down button.
        /// </summary>
        VolumeDown = 0x76
    }
}
