﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace RM.WinCE.DiamondHooker
{
    internal class PInvoke
    {
        public const int WM_HOTKEY = 0x312;

        [DllImport( "coredll.dll" , SetLastError = true )]
        public static extern bool RegisterHotKey( IntPtr hWnd , int id , KeyModifiers Modifiers , DiamondHWKey key );

        [DllImport( "coredll.dll" )]
        public static extern bool UnregisterFunc1( KeyModifiers modifiers , DiamondHWKey key );
    }
}
