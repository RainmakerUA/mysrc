﻿using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using RM.WinCE.DiamondHooker.Settings;

namespace RM.WinCE.DiamondHooker
{
    internal static class ActionManager
    {
        private static bool PerformStartAction( string[] par )
        {
            string currentDir;
            string program;
            string @params;
            bool result;

            currentDir = Path.GetDirectoryName( System.Reflection.Assembly.GetExecutingAssembly().GetModules()[ 0 ].FullyQualifiedName );
            if ( par.Length > 0 )
            {
                try
                {
                    program = par[ 0 ].StartsWith( Path.PathSeparator.ToString() ) ? par[ 0 ] : Path.Combine( currentDir , par[ 0 ] );
                    @params = par.Length > 1 ? String.Join( "\x0020" , par , 1 , par.Length - 1 ) : String.Empty;
                    result = Process.Start( program , @params ) != null;
                }
                catch ( Exception e )
                {
                    result = false;
                }
            }
            else
            {
                result = false;
            }

            return result;
        }

        private static bool PerformDefaultAction( KeyAction action )
        {
            return MessageBox.Show(
                        String.Format( "{0}::\n{1}" , action.Type , String.Join( "; " , action.Parameters ) ) ,
                        "Diamond Hooker" ,
                        MessageBoxButtons.YesNo ,
                        MessageBoxIcon.Question ,
                        MessageBoxDefaultButton.Button1
                    ) == DialogResult.Yes;
        }

        public static bool PerformAction( KeyAction action )
        {
            bool result;

            switch ( action.Type )
            {
                case KeyAction.ActionType.Start:
                    result = PerformStartAction( action.Parameters );                    
                    break;

                default:
                    result = PerformDefaultAction( action );
                    break;
            }
            return result;
        }
    }
}
