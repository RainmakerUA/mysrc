﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using OpenNETCF.Windows.Forms;
using Microsoft.WindowsCE.Forms;

namespace RM.WinCE.DiamondHooker
{
    internal class HKMessageWindow : MessageWindow
    {
        private const int QUITMSG = 71;

        protected override void WndProc( ref Message m )
        {
           switch ( m.Msg )
            {
                case PInvoke.WM_HOTKEY:
                    HotKeys.ProcessHotKeyMessage( ref m );
                    break;

                case QUITMSG:
                    ApplicationEx.Exit();
                    break;
            }
            base.WndProc( ref m );
        }
    }

}
