#pragma once

#define WH_KEYBOARD_LL 20
#define HC_ACTION 0

typedef struct tagKBDLLHOOKSTRUCT {
    DWORD vkCode;
    DWORD scanCode;
    DWORD flags;
    DWORD time;
    ULONG_PTR dwExtraInfo;
} KBDLLHOOKSTRUCT, *PKBDLLHOOKSTRUCT;

typedef LRESULT (CALLBACK* HOOKPROC)( int code , WPARAM wParam , LPARAM lParam);

#ifdef __cplusplus
extern "C"
{
#endif //#ifdef __cplusplus

    //BOOL WINAPI UnregisterFunc1(UINT fsModifiers, UINT vk);
    HHOOK SetWindowsHookExW( int idHook , HOOKPROC lpfn , HINSTANCE hMod , DWORD dwThreadId );
    BOOL UnhookWindowsHookEx( HHOOK hhk );
    LRESULT CallNextHookEx( HHOOK hhk , int nCode , WPARAM wParam , LPARAM lParam );

#ifdef __cplusplus
}
#endif //#ifdef __cplusplus

#define SetWindowsHookEx SetWindowsHookExW