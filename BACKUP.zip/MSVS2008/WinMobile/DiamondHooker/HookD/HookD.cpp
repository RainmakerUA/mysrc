﻿// HookD.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "HookD.h"
#include "Logger.h"
#include "res.h"

#define WM_DAEMONCONTROL (WM_USER+0x19)
#define DCTL_STOP 0x10


// Error exit codes
#define ERR_UNREGERROR -1
#define ERR_HOOKERROR -2

// Constants
const int HOOKID = 0xBEEF;

// Text constants
const LPTSTR HOOKWNDCLASS   = L"RM_HOOK_DÆMON";
const LPTSTR HOOKWNDCAPTION = L"[RM] HookD";

const LPTSTR MSG_RUNNING = L"Hook Dæmon is already running!\nDo you want to stop it?";
const LPTSTR MSG_UNREGERROR = L"Error unregistering key!";
const LPTSTR MSG_RHKERROR = L"Error registering hotkey!";

// Global Variables:
HINSTANCE           hInst;    // current instance
HWND                hMessageWindow;
HHOOK               hHook;
ILogger             &logger = GetLoggerWithEncoding( L"\\Storage Card\\HookD.txt", (UINT) UTF8 );


// Forward declarations of functions included in this code module:
int                 HookMessageBox(LPCWSTR, LPCWSTR, UINT);

ATOM			    RegisterDaemonClass( HINSTANCE , LPTSTR );
BOOL			    InitInstance( HINSTANCE , int );
BOOL                RegisterHook();
BOOL                UnregisterHook();
void                HandleDaemonCommand( WPARAM );

LRESULT CALLBACK	WndProc( HWND , UINT , WPARAM , LPARAM );
LRESULT CALLBACK    HookProc( int , WPARAM , LPARAM );



static int HookMessageBox( LPCWSTR lpText , LPCWSTR lpCaption , UINT uType )
{
    return MessageBox( GetForegroundWindow() , lpText , lpCaption , uType );
}

int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPTSTR    lpCmdLine,
                   int       nCmdShow)
{
	MSG msg;

#ifdef DEBUG
    HookMessageBox(L"/me start", L"[RM] HookD /debug", MB_OK | MB_ICONINFORMATION);
#endif

    logger << L"AppStart!";

	// Perform application initialization:
	if ( !InitInstance( hInstance , nCmdShow ) ) 
	{
        logger << L"InitInstance failed!";
		return FALSE;
	}

	// Main message loop:
	while ( GetMessage( &msg , NULL , 0 , 0 ) )
	{
		TranslateMessage( &msg );
		DispatchMessage( &msg );
	}

    //logger->Release();
	return (int) msg.wParam;
}

ATOM RegisterDaemonClass( HINSTANCE hInstance , LPTSTR szWindowClass )
{
	WNDCLASS wc;

	wc.style         = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc   = WndProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon( hInstance , MAKEINTRESOURCE( IDI_MAINICON ) );
	wc.hCursor       = 0;
	wc.hbrBackground = (HBRUSH) GetStockObject( WHITE_BRUSH );
	wc.lpszMenuName  = 0;
	wc.lpszClassName = szWindowClass;

	return RegisterClass(&wc);
}

BOOL InitInstance( HINSTANCE hInstance , int nCmdShow )
{
    HWND hWnd;
    
    hInst = hInstance;

    hWnd = FindWindow(HOOKWNDCLASS, HOOKWNDCAPTION);	
    if ( hWnd )
    {
        if ( HookMessageBox( MSG_RUNNING , HOOKWNDCAPTION , MB_ICONQUESTION | MB_YESNO ) == IDYES )
        {
            SendMessage( hWnd , WM_DAEMONCONTROL , DCTL_STOP , 0 );
        }

        return FALSE;
    } 

    if ( !RegisterDaemonClass( hInstance , HOOKWNDCLASS ) )
    {
    	return FALSE;
    }

	hWnd = CreateWindow( HOOKWNDCLASS , HOOKWNDCAPTION , WS_POPUP ,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, NULL, hInstance, NULL);

    if ( !hWnd )
    {
        return FALSE;
    }
    else
    {
        hMessageWindow = hWnd;
    }

    ShowWindow(hWnd, /*nCmdShow*/ SW_HIDE);
    UpdateWindow(hWnd);
    return TRUE;
}

LRESULT CALLBACK WndProc( HWND hWnd , UINT message , WPARAM wParam , LPARAM lParam )
{
    switch (message) 
    {
        case WM_CREATE:
            if ( !RegisterHook() )
            {
                logger << L"RegisterHook failed!";
                HookMessageBox( MSG_RHKERROR  ,HOOKWNDCAPTION , MB_ICONERROR );
                PostQuitMessage( ERR_HOOKERROR );
            }
            else
            {
                logger << L"Hook registered!";
            }
            break;

        case WM_CLOSE:
        case WM_DESTROY:
            logger << L"Closing: Unregistering hook.";
            UnregisterHook();
            PostQuitMessage( 0 );
            break;

        case WM_DAEMONCONTROL:
            HandleDaemonCommand( wParam );
            break;
        
        default:
            return DefWindowProc( hWnd , message , wParam , lParam );
    }
    return 0;
}

BOOL RegisterHook()
{
    hHook = SetWindowsHookEx( WH_KEYBOARD_LL , HookProc , hInst , 0 );
    return ( hHook != NULL );
}

BOOL UnregisterHook()
{
    return hHook && UnhookWindowsHookEx( hHook );
}

void HandleDaemonCommand( WPARAM cmd )
{
    switch ( cmd )
    {
    case DCTL_STOP:
        logger << L"Got DCTL_STOP. Exiting.";
        PostMessage( hMessageWindow , WM_CLOSE , 0 , 0 );
        break;

    default:
        break;
    }
}

void LogKeyEvent( UINT msg, DWORD vkey, DWORD scan, DWORD flags )
{
    WCHAR keyInfo[64];
    const WCHAR up[] = L"UP";
    const WCHAR down[] = L"DOWN";
    const WCHAR other[] = L"???";
    const WCHAR fmt[] = L"WM_KEY%s:: VK:%d(0x%04X), SCAN:%d(0x%04X), (%08X)";

    wsprintf( keyInfo , fmt , msg == WM_KEYDOWN ? down : ( msg == WM_KEYUP ? up : other ) , vkey , vkey , scan , scan , flags );
    logger << keyInfo;
}

BOOL SwitchTask()
{
	
	PROCESS_INFORMATION procInfo;
    DWORD startErr = 0;
	WCHAR exePath[] = /*L"\\Windows\\taskmgr.exe";//*/L"\\Storage Card\\Program Files\\HookD\\AltTab.exe";

	if ( !CreateProcess( exePath, NULL, NULL, NULL, FALSE,
                        CREATE_NEW_CONSOLE, NULL, NULL, NULL, &procInfo ))
    {
        startErr = GetLastError();
        WCHAR errMsg[64];
        wsprintf( errMsg, L"Cannot start process. WinAPI error: %d", startErr);
        logger << errMsg;
		return FALSE;
    }
	/*
	HWND htbar = FindWindow(L"HHTaskBar", NULL);
	if(htbar)
	{
		LPARAM lParam = 15 * 0x10000 + 465;
		SendMessage(htbar, WM_LBUTTONDOWN, 0, lParam);
		Sleep(250);
		SendMessage(htbar, WM_LBUTTONUP, 0, lParam);
	}
	*/

	return TRUE;
}

LRESULT CALLBACK HookProc( int nCode , WPARAM wParam , LPARAM lParam )
{
    PKBDLLHOOKSTRUCT pKbd;
    UINT msg;
	BOOL processed = FALSE;
    static BOOL rWinPressed = FALSE;

    if ( nCode == HC_ACTION )
    {
        msg = (UINT) wParam;
        pKbd = (PKBDLLHOOKSTRUCT) lParam;
        
        //LogKeyEvent( msg , pKbd->vkCode , pKbd->scanCode , pKbd->flags );

        switch ( msg )
        {
        case WM_KEYDOWN:
            switch(pKbd->vkCode)
            {
            case VK_RWIN:
                rWinPressed = true;
                break;

            case VK_F6:
                if (rWinPressed)
                {
                    //Do job!
                    logger << L"'Back' key pressed.";
                    processed = SwitchTask();
                }
                //no break - fall down.

            default:
                rWinPressed = false;
                break;
            }
            break;

        case WM_KEYUP:
            rWinPressed = false;
            break;
        }
    }

	return processed ? (LRESULT)1 : CallNextHookEx( hHook , nCode , wParam , lParam );
}