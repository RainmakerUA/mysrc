#pragma once

class FileLogger
{
private:
    HANDLE file;

    static const WORD    WCHARSIZE;

    static const WCHAR*  NEWLINE;
    static const WORD    NEWLINELEN;

    static const WCHAR*  EMPTYRECORD;
    static const WORD    EMPTYRECLEN;

    static const size_t  TIMEMSGLEN;
    static const WCHAR*  TIME_FMT;

    static WCHAR *time_fmt( const LPSYSTEMTIME time )
    {
        WCHAR *out = new WCHAR[ TIMEMSGLEN ];
        wsprintf( out , TIME_FMT , time->wYear , time->wMonth , time->wDay ,
            time->wHour , time->wMinute , time->wSecond , time->wMilliseconds );
        out[ TIMEMSGLEN - 1 ] = L'\0';
        return out;
    }

    void logfile_init( const WCHAR *fname );

public:
    FileLogger( void );
    FileLogger( const WCHAR *file );
    ~FileLogger( void );

    void WriteLog( const WCHAR *message );
    void WriteLog( const WCHAR *message , BOOL addTime );
};
