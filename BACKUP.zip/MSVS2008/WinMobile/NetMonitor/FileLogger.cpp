#include "FileLogger.h"

const WCHAR* FileLogger::NEWLINE = L"\r\n";
const WORD   FileLogger::NEWLINELEN = lstrlen( FileLogger::NEWLINE );

const WCHAR* FileLogger::EMPTYRECORD = L"<no text written>";
const WORD   FileLogger::EMPTYRECLEN = lstrlen( FileLogger::EMPTYRECORD );

const size_t  FileLogger::TIMEMSGLEN = ( 4 + 1 + 2 + 1 + 2 + 1 + 2 + 1 + 2 + 1 + 2 + 1 + 3 + 1 ) + 1;
const WCHAR* FileLogger::TIME_FMT = L"%04d-%02d-%02d %02d:%02d:%02d.%03d ";

FileLogger::FileLogger()
{
    FileLogger::FileLogger( L"\\RM_FileLogger_file.log" );
}

FileLogger::FileLogger( const WCHAR *fname )
{
    HANDLE hf = CreateFile( fname , GENERIC_WRITE , FILE_SHARE_READ , NULL ,
            OPEN_ALWAYS , FILE_FLAG_WRITE_THROUGH , NULL );
    file = NULL;

    if ( hf != INVALID_HANDLE_VALUE )
    {
        file = hf;
        SetFilePointer( file , 0 , NULL , SEEK_END );
        WriteLog( L"Log file opened vvvvvvvvvv" );
    }
}

FileLogger::~FileLogger( void )
{
    if ( file )
    {
        WriteLog( L"Log file closed ^^^^^^^^^^" );
        CloseHandle( file );
    }
}

void FileLogger::WriteLog( const WCHAR *message )
{
    WriteLog( message , TRUE );
}

void FileLogger::WriteLog( const WCHAR *message , BOOL addTime )
{
    DWORD len;
    DWORD written_len;
    SYSTEMTIME now;

    len = (DWORD) lstrlen( message );
    if ( file )
    {
        if ( addTime )
        {
            GetLocalTime( &now );
            WriteFile( file , time_fmt( &now ), TIMEMSGLEN , &written_len , NULL );
        }

        if ( message && len > 0 )
        {
            WriteFile( file , message , len , &written_len , NULL );
        }
        else
        {
            WriteFile( file , EMPTYRECORD , EMPTYRECLEN , &written_len , NULL );
        }

        WriteFile( file , NEWLINE , len , &written_len , NULL );
    }
}
