#pragma once

#include <windows.h>

#include "ril.h"
#pragma comment(lib, "ril.lib")