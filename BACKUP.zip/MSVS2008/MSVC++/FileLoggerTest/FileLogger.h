#pragma once

enum StandardEncoding : UINT
{
    None = 0 ,
    UTF16LE ,
    UTF16BE ,
    ANSI ,
    UTF8
};

struct LogEncoding
{
    StandardEncoding standard;
    UINT encoding;

    LogEncoding()
    {
        standard = None;
        encoding = 0;
    }

    LogEncoding( StandardEncoding stdEnc )
    {
        standard = stdEnc;
        encoding = 0;
    }

    LogEncoding( UINT encNum )
    {
        standard = None;
        encoding = encNum;
    }
};

class FileLogger
{
private:
    HANDLE file;
    LogEncoding enc;

    static const WCHAR*  NEWLINE;
    static const WORD    NEWLINELEN;

    static const WCHAR*  EMPTYRECORD;
    static const WORD    EMPTYRECLEN;

    static const size_t  TIMEMSGLEN;
    static const WCHAR*  TIME_FMT;

    static WCHAR *time_fmt( const LPSYSTEMTIME time )
    {
        WCHAR *out = new WCHAR[ TIMEMSGLEN ];
        wsprintf( out , TIME_FMT , time->wYear , time->wMonth , time->wDay ,
            time->wHour , time->wMinute , time->wSecond , time->wMilliseconds );
        out[ TIMEMSGLEN - 1 ] = L'\0';
        return out;
    }

    void logfile_init( const WCHAR *fname , LogEncoding encoding );
    BOOL WriteTextToFile( const WCHAR * text ) const;
    BOOL WriteTextToFile( const WCHAR * text , DWORD len ) const;

public:
    FileLogger( const WCHAR *file );
    FileLogger( const WCHAR *file , LogEncoding encoding );
    ~FileLogger( void );

    void WriteLog( const WCHAR *message ) const;
    void WriteLog( const WCHAR *message , BOOL addTime ) const;

	const FileLogger& operator<<(const WCHAR*) const;
};
