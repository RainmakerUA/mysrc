
#include "stdafx.h"
#include "FileLogger.h"

#define WCHARSIZE sizeof( WCHAR )

const WCHAR* FileLogger::NEWLINE = L"\r\n";
const WORD   FileLogger::NEWLINELEN = lstrlen( FileLogger::NEWLINE );

const WCHAR* FileLogger::EMPTYRECORD = L"<no text written>";
const WORD   FileLogger::EMPTYRECLEN = lstrlen( FileLogger::EMPTYRECORD );

const size_t  FileLogger::TIMEMSGLEN = ( 4 + 1 + 2 + 1 + 2 + 1 + 2 + 1 + 2 + 1 + 2 + 1 + 3 + 1 ) + 1;
const WCHAR* FileLogger::TIME_FMT = L"%04d-%02d-%02d %02d:%02d:%02d.%03d ";

FileLogger::FileLogger( const WCHAR *filename )
{
    logfile_init( filename , LogEncoding( UTF16LE ) );
}

FileLogger::FileLogger( const WCHAR *filename , LogEncoding encoding )
{
    logfile_init( filename , encoding );
}

void FileLogger::logfile_init( const WCHAR *fname , LogEncoding encoding )
{
    enc = encoding;
    HANDLE hf = CreateFile( fname , GENERIC_WRITE , FILE_SHARE_READ , NULL ,
            OPEN_ALWAYS , FILE_FLAG_WRITE_THROUGH , NULL );
    file = NULL;

    if ( hf != INVALID_HANDLE_VALUE )
    {
        file = hf;
        SetFilePointer( file , 0 , NULL , FILE_END );
        WriteLog( L"Log file opened vvvvvvvvvv" );
    }
}

FileLogger::~FileLogger( void )
{
    if ( file )
    {
        WriteLog( L"Log file closed ^^^^^^^^^^" );
        CloseHandle( file );
    }
}

BOOL FileLogger::WriteTextToFile( const WCHAR *text ) const
{
    return WriteTextToFile( text , 0 );
}

BOOL FileLogger::WriteTextToFile( const WCHAR *text , DWORD len ) const
{
    void *resText = NULL;
    bool resTextAlloc = false;
    int length;
    int codepage;
    DWORD written_len;
    BOOL result;

    switch ( enc.standard )
    {
    case UTF16LE:
        resText = (void *) text;
        length = ( len > 0 ? len : wcslen( text ) ) * WCHARSIZE;
        codepage = -1;
        break;

    case UTF16BE:
        resText = L"{UTF-16BE not implemented!}";
        length = 27 * WCHARSIZE;
        codepage = -1;
        break;

    case ANSI:
        codepage = CP_ACP;
        break;

    case UTF8:
        codepage = CP_UTF8;
        break;

    default:
        if ( enc.encoding > 0 )
        {
            codepage = enc.encoding;
        }
        else
        {
            resText = L"{Encoding not implemented!}";
            length = 27 * WCHARSIZE;
            codepage = -1;
        }
        break;
    }

    if ( codepage > -1 )
    {
        length = WideCharToMultiByte( codepage , 0 , text , -1 , (LPSTR) resText , 0 , NULL , NULL );
        resText = new BYTE[ length ];
        resTextAlloc = true;
        WideCharToMultiByte( codepage , 0 , text , -1 , (LPSTR) resText , length , NULL , NULL );
        length--;
    }

    result = WriteFile( file , resText , length , &written_len , NULL ) && ( length == written_len ? TRUE : FALSE );
    
    if ( resTextAlloc )
    {
        delete[] resText;
    }

    return result;
}

void FileLogger::WriteLog( const WCHAR *message ) const
{
    WriteLog( message , TRUE );
}

void FileLogger::WriteLog( const WCHAR *message , BOOL addTime ) const
{
    SYSTEMTIME now;

    if ( file )
    {
        if ( addTime )
        {
            GetLocalTime( &now );
            WriteTextToFile( time_fmt( &now ), TIMEMSGLEN );
        }

        if ( message )
        {
            WriteTextToFile( message );
        }
        else
        {
            WriteTextToFile( EMPTYRECORD , EMPTYRECLEN );
        }

        WriteTextToFile( NEWLINE , NEWLINELEN );
    }
}

const FileLogger& FileLogger::operator<<(const WCHAR* message) const
{
	this->WriteLog(message);
	return *this;
}

